package OOPSConcepts;
class BankAccount
{
	int balance;
	
	BankAccount(int balance)
	{
		this.balance=balance;
	}

	public int getBalance() {
		return balance;
	}
	
	public int withdraw(int amount)
	{
		return 0;
	}
	
	public void deposit(int amount)
	{
		
	}
}
class SavingsAccount extends BankAccount
{
	
	public SavingsAccount(int balance) 
	{
		super(balance);
	}
	
	public int withdraw(int amount)
	{
		if(amount<=super.balance)
			super.balance=super.balance-amount;
		else
			System.out.println("insufficient funds");
		return super.balance;
	}
	public void deposit(int amount)
	{
		super.balance=super.balance+amount;
	}
	
	public int getBalance()
	{
		return super.balance;
	}
	
}
class CurrentAccount extends BankAccount
{
	
	public CurrentAccount(int balance) 
	{
		super(balance);
	}
	
	public int withdraw(int amount)
	{
		if(amount<=super.balance)
			super.balance=super.balance-amount;
		else
			System.out.println("insufficient funds");
		return super.balance;
	}
	public void deposit(int amount)
	{
		super.balance=super.balance+amount;
	}
	
	public int getBalance()
	{
		return super.balance;
	}
	
}
public class Bankapplication {

	public static void main(String[] args)
	{
		SavingsAccount sa=new SavingsAccount(20000);
		System.out.println(sa.getBalance());
		
		sa.deposit(5000);
		System.out.println(sa.getBalance());
		
		sa.withdraw(2000);
		System.out.println(sa.getBalance());
		
		sa.withdraw(30000);
		
		CurrentAccount ca=new CurrentAccount(10000);
		System.out.println(ca.getBalance());
		
		ca.deposit(5000);
		System.out.println(ca.getBalance());
		
		ca.withdraw(2000);
		System.out.println(ca.getBalance());
		
		ca.withdraw(30000);
		
		
	}

}
