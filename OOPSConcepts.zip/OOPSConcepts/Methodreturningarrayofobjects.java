package OOPSConcepts;
//method returning array of objects
class Employee10
{
	int empno;
	String name;
	String designation;
	float salary;
	
	Employee10(int empno,String name,String designation,float salary)
	{
		this.empno=empno;
		this.name=name;
		this.designation=designation;
		this.salary=salary;
	}
}
public class Methodreturningarrayofobjects {

	public static void main(String[] args) 
	{
		Methodreturningarrayofobjects mao=new Methodreturningarrayofobjects();
		Employee10 e1[]=mao.display();
		
		for(int i=0;i<e1.length;i++)
		{
			System.out.println(e1[i].empno+" "+e1[i].name+" "+e1[i].designation+" "+e1[i].salary);
		}
	}
	Employee10[] display()
	{
		Employee10 e[]=new Employee10[5];
		
		e[0]=new Employee10(101,"srujan","analyst",55000.0f);
		e[1]=new Employee10(102,"anand","tester",45000.0f);
		e[2]=new Employee10(103,"kapil","developer",65000.0f);
		e[3]=new Employee10(104,"dheeraj","programmer",35000.0f);
		e[4]=new Employee10(105,"bhanu","architect",95000.0f);
		
		return e;
		
	}
	

}
