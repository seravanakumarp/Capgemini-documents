/*
 * Throw:
 * ->It is used to create an exception object explicitly.
 * ->It is possible to have user defined exception class in java programming.
 * ->Whenever an predefined exception is raised, an exception object gets
 * created implicitly and it can thrown by an programmer by means of throws
 * keyword.
 * -> Similarly, we can handle user defined exception class explicitly by
 * creating an object and throwing them by means of keyword called throw.
 * 
 * Syntax: class MyException extends RunTimeException
 * 			{
 * 			}
 * 			class MyException extends Exception
 * 			{
 * 			}
 * Syntax of throwing the exception object:
 * 			throw <throwable_object>;
 * 
 */
package OOPSConcepts;
class MyException extends Exception
{
	String name;
	MyException(String name)
	{
		this.name=name;
	}
	public String getErrorMessage()
	{
		return this.name;
	}
}
public class Throwdemo {

	public static void main(String[] args) 
	{
		try
		{
			MyException obj=new MyException("error message");
			throw obj;
		}
		catch(MyException me)
		{
			System.out.println(me.getErrorMessage());
		}
	}

}
