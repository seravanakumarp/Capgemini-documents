/*
 * Exception Handling:
 * 
 * When a program is compiled and executed, the following possible errors
 * do occur:
 * 1. Compile Error.
 * 2. Logical Error.
 * 3. Runtime Error.
 * 
 * Causes:
 * 1. Abnormal termination of program.
 * 2. Informal information to the end user.
 * 3. Improper shutdown of resources.
 * 
 * A programmer can able to analyze the error but he cannot handle that
 * during application development.
 * 
 * Ex: Entering ATM pin in ATM Machine.
 *     Watching videos in systems.
 *     
 * What happens when an exception is raised?
 * -> In general, exceptions occurs or takes place in block or a method.
 * -> When an exception is raised, the block or a method will create
 * an exception object which contains the following information:
 * 
 * 		-> name of the exception
 * 		-> type of the exception
 * 		-> state of an exception
 * 
 * -> This exception object which got been raised has been routed to the
 * JVM and JVM will hand over it to the defaultexceptionhandler.
 * 
 * -> Before it is routed to the JVM, we being an programmer need to handle
 * the exception instead routing to the JVM and allowing the remaining 
 * statements to get executed without abnormal termination.
 * 
 * 
 * Different possible types of exceptions:
 * 1. Arithmetic Exception
 * 2. ArrayIndexOutOfBoundsException
 * 3. NullPointer Exception
 * 4. NumberFormat Exception
 * 5. ClassCast Exception
 * 6. If you are trying to access the content of a file where the file i
 * is not available causes an exception called FileNotFound Exception
 * 7. If you are trying to connect to a database, where it not ready
 * causes SQL Exception
 * 8. Trying to fetch the IP Address of a system, where the LAN is not
 * connected causes UnknownHostException
 * 
 * 
 * 
 */
package OOPSConcepts;
import java.util.*;
public class Exceptionhandling 
{
	public void display()
	{
		
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		//Compile time error
		//static int a;
		
		//logical error
		
	/*	int a=10,b=20;
		float c=a/b;
		System.out.println(c);
	*/
		//Runtime Error
		
	/*int d[]=new int[5];
		d[7]=30;
		
		System.out.println(d[7]);
	*/
		
		//Arithmetic Exception
		
		/*int a=10/0;
		System.out.println(a);
		*/
		//ArrayIndexOutOfBounds Exception
		
		/*int a[]=new int[5];
		
		for(int i=0;i<=a.length;i++)
			System.out.print(a[i]+" ");
		*/
		
		//NullPointer Exception
		/*int a[]=null;
		System.out.println(a.length);
		*/
		
		/*Exceptionhandling eh=null;
		eh.display();
		*/
		//NumberFormat Exception
		
		String s="rahul";
		Integer i=Integer.parseInt(s);
		System.out.println(i);
	}

}
