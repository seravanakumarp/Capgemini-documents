package OOPSConcepts;
class Employee11
{
	String name;
	String role;
	
	Employee11(String name,String role)
	{
		this.name=name;
		this.role=role;
	}

	public String getName() {
		return name;
	}

	public String getRole() {
		return role;
	}
	
	public double calculateSalary()
	{
		return 0.0;
	}
}
class Manager11 extends Employee11
{
	double salary;
	double bonus;
	
	Manager11(String name,String role,double salary,double bonus)
	{
		super(name,role);
		this.salary=salary;
		this.bonus=bonus;
	}
	
	public double calculateSalary()
	{
		return this.salary+this.bonus;
	}
}
class Programmer11 extends Employee11
{
	double salary;
	double overtimepay;
	
	Programmer11(String name,String role,double salary,double overtimepay)
	{
		super(name,role);
		this.salary=salary;
		this.overtimepay=overtimepay;
	}
	
	public double calculateSalary()
	{
		return salary+overtimepay;
	}
}
public class Exercise {

	public static void main(String[] args) 
	{
		Manager11 m=new Manager11("satish","architect",75000 ,10000);
		double salary=m.calculateSalary();
		System.out.println("Salary of manager="+salary);
		
		Programmer11 p=new Programmer11("Rahul","developer",55000,5000);
		double salary1=p.calculateSalary();
		System.out.println("Salary of programmer="+salary1);
		
	}

}
