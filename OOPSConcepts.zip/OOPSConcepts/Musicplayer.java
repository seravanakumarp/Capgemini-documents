package OOPSConcepts;

public class Musicplayer 
{
	String name;
	String format;
	float price;
	
	public Musicplayer(String name, String format, float price) 
	{
		
		this.name = name;
		this.format = format;
		this.price = price;
	}

	
	@Override
	public String toString() {
		return "Musicplayer [name=" + name + ", format=" + format + ", price=" + price + "]";
	}
	
	
	
}
