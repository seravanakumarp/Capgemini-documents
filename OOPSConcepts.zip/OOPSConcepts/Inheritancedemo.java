/*
 * Inheritance:
 * 1. It is a process of accessing the members of one class by an
 * another class.
 * 
 * Advantages of Inheritance:
 * 1. Reusability.
 * 2. Reduction in line of code.
 * 3. Reduces the development time of an application
 * 
 * Types of Inheritance:
 * 1. Single level Inheritance
 * 2. Multi level Inheritance
 * 3. Hierarchial Inheritance
 * 
 * Not Supported by the Java:
 * 4. Multiple Inheritance
 * 5. Hybrid Inheritance
 * 
 * Single level Inheritance:
 * 
 * If the inheritance concept contains one parent class and one child class,
 * then it is treated as Single level Inheritance.
 * 
 * Multi level Inheritance:
 * If the inheritance concept contains one parent class, one child class
 * and one or more intermediate classes, then it treated as Multi level
 * inheritance.
 * 
 * Hierarchial Inheritance:
 * A parent class containing two or more child classes, they are called 
 * as Hierarchial inheritance.
 * 
 * 
 * Terminologies used in inheritance concept:
 * 
 * 1. Parent class/Super class/Base class: A class which provides members
 * to another class is called parent class/super class/base class.
 * 
 * 2. Child class/Sub class/Derived class: A class which receives members
 * from an another class is called child class/sub class/derived class.
 * 
 * 
 * Why Multiple Inheritance is not supported by Java?
 * -> If both the parent classes contains same members, then the child class
 * will be in an ambiguous state in terms of accessing either first parent
 * class or the second parent class. Due to this reason, multiple
 * inheritance is not supported by java.
 * 
 * But the multiple inheritance can be achieved by means of Interface.
 * 
 * Inheritance facilitates IS-A Relationship between the classes.
 * 
 *               Example: Dog is a animal.
 *                        Computer is a electronic device.
 *                        Shyam is a software professional.
 * When we create an object for a parent class, we can access only the parent
 * class members.
 * 
 * If we create an object for a child class, we can access both the parent
 * class members as well as child class members.
 * 
 * Whether it is a parent class or child class, all the classes are sub classes
 * of Object class.An Object class is a super class for the classes in 
 * java.
 * 
 */
package OOPSConcepts;
class Cone
{
	Cone()
	{
		System.out.println("Cone class constructor");
	}
}
class Ctwo extends Cone
{
	Ctwo()
	{
		System.out.println("Ctwo class constructor");
	}
}
class Cthree extends Ctwo
{
	Cthree()
	{
		System.out.println("Cthree class constructor");
	}
}
public class Inheritancedemo {

	public static void main(String[] args) 
	{
			Cthree c3=new Cthree();
	}

}
