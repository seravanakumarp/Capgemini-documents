package OOPSConcepts;

public class Pipedemo {

	public static void main(String[] args) 
	{
		try
		{
			int a[]=new int[10];
			a[10]=10/0;
		}
		catch(ArithmeticException|ArrayIndexOutOfBoundsException ae)
		{
			System.out.println(ae.getMessage());
		}
	}
/*NOTE: catch(IOException|FileNotFoundException f)
 * 		{
 * 			f.printStackTrace();
 * 		}
 * If we are defining multiple exception classes separated by pipe,make
 * sure that they are not in IS-A Relationship.
 * 
 * 
 */
}
