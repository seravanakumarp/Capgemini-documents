package OOPSConcepts;

public class Engine 
{
	private String stroke;

	public String getStroke() {
		return stroke;
	}

	public void setStroke(String stroke) {
		this.stroke = stroke;
	}
	
	
}
