package OOPSConcepts;
class Shape
{
	public static double area()
	{
		return 0.0;
	}
}
class Rectangle11 extends Shape
{
	static float length,breadth;
	
	Rectangle11(float length,float breadth)
	{
		Rectangle11.length=length;
		Rectangle11.breadth=breadth;
	}
	public static double area()
	{
		return (double)(length*breadth);
	}

}
public class Methodoverhiding {

	public static void main(String[] args) 
	{
		Rectangle11 r=new Rectangle11(4.5f, 5.5f);
		double area=Rectangle11.area();
		
		System.out.println("area of rectangle="+area);
	}

}
