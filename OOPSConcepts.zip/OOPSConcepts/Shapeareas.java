package OOPSConcepts;
interface Shape02
{
	public float getArea(); //abstract method
}
class Rectangle02 implements Shape02
{
	float length,breadth;
	Rectangle02(float length,float breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	
	public float getArea()
	{
		return length*breadth;
	}
}
class Triangle02 implements Shape02
{
	float base,height;
	Triangle02(float base,float height)
	{
		this.base=base;
		this.height=height;
	}
	public float getArea()
	{
		return 0.5f*base*height;
	}
}
class Circle02 implements Shape02
{
	float radius;
	Circle02(float radius)
	{
		this.radius=radius;
	}
	public float getArea()
	{
		return 3.142f*radius*radius;
	}
}
public class Shapeareas {

	public static void main(String[] args) 
	{
		Rectangle02 r=new Rectangle02(40, 50);
		float rec_area=r.getArea();
		System.out.println("area of rectangle="+rec_area);
		
		Triangle02 t=new Triangle02(20,40);
		float tri_area=t.getArea();
		System.out.println("area of triangle="+tri_area);
		
		Circle02 c=new Circle02(4.5f);
		float cir_area=c.getArea();
		System.out.println("area of circle="+cir_area);
	}

}
