/*
 * Anonymous Array:
 * An array without any name is called anonymous array.
 * An anonymous array is used only one time during method invocation.
 * 
 */
package OOPSConcepts;

public class Anonymousarray
{
	
	public static void main(String[] args) 
	{
		
		
		int b[]=sort(new int[] {21,43,10,56,12,67,90});
		for(int i=0;i<b.length;i++)
			System.out.print(b[i]+" ");

	}
	public static int[] sort(int a[])
	{
		int i,j,temp;
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a;
	}

}
