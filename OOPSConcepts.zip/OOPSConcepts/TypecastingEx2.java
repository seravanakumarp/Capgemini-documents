package OOPSConcepts;
//Superclass Shape
class Shape1 {
 void draw() {
     System.out.println("Drawing a generic shape");
 }
}

//Subclass Circle
class Circle1 extends Shape1 {
 void draw() {
     System.out.println("Drawing a Circle");
 }
 
 void calculateArea() {
     System.out.println("Calculating area of Circle");
 }
}

//Subclass Rectangle
class Rectangle1 extends Shape1 {
 void draw() {
     System.out.println("Drawing a Rectangle");
 }
 
 void calculateArea() {
     System.out.println("Calculating area of Rectangle");
 }
}

public class TypecastingEx2 {

	public static void main(String[] args) 
	{
		 //upcasting
        Shape1 shape1 = new Circle1();     // Upcast Circle to Shape
        Shape1 shape2 = new Rectangle1();  // Upcast Rectangle to Shape

        shape1.draw();  
        shape2.draw();  

        // downcasting
        Circle1 circle = (Circle1) shape1;  // Downcasting from Shape to Circle
            circle.calculateArea(); // Calls Circle's specific method
        
	}

}
