/*
 * Relationship between the classes:
 * 
 * 1. IS-A Relationship
 * 2. Has-A Relationship
 * 
 * IS-A Relationship
 * -> IS-A Relationship is achieved by means of Inheritance
 * -> This is implemented by using the extends keyword.
 * 
 * HAS-A Relationship.
 * 
 * -> HAS-A Relationship is also treated as Association.
 * 
 * -> Association defines the relationship between the objects.
 * 
 *                  Ex: Car has a Music player
 *                  	Jeep has a Engine
 *                  
 *-> Association is further classified into two categories:
 *   -> Aggregation
 *   -> Composition
 *-> Association is achieved by means of instance variable
 *
 *Aggregation:
 *
 *-> Aggregation defines the weak relationship between the objects.
 *-> One class in not dependent on another class.
 *
 *					Ex: Car has a Music player
 *
 *Composition:
 *-> Composition defines the strong relationship between the objects
 *-> One class is dependent on another class.
 *
 *					Ex: Jeep has a engine
 *
 *
 *
 *
 *
 *
 *
 *   
 * 
 *   
 *                  
 *                  
 * 
 */
package OOPSConcepts;

public class Relationshipbetweenclasses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
