package OOPSConcepts;
interface Test001
{
	int x=10;
	public void message();
}
interface Sample001
{
	int y=20;
	public void message();
}

public class MultipleInheritancedemo implements Test001,Sample001
{
	public void message()
	{
		System.out.println("happy coding in java");
	}
	public static void main(String[] args) 
	{
		System.out.println(x+" "+y);
		
		MultipleInheritancedemo mid=new MultipleInheritancedemo();
		mid.message();
		
		Test001 t1=new MultipleInheritancedemo();
		t1.message();
		
		Sample001 s1=new MultipleInheritancedemo();
		s1.message();
	}

}
