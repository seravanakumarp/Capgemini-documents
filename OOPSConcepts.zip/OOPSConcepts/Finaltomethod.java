/*
 * final method:
 * 
 * A final to a method cannot be overridden.
 * A final method can be inherited.
 */
package OOPSConcepts;

class Shapes1
{
	public final float computeArea()
	{
		return 0;
	}
}
class Triangle extends Shapes1
{
	public float computeArea() //cannot be overridden 
	{
		float area,base=4,height=5;
		area=0.5f*base*height;
		return area;
		
	}
}
public class Finaltomethod {

	public static void main(String[] args) {
		
		Triangle t=new Triangle();
		float result=t.computeArea();
		System.out.println("area of triangle="+result);
	}

}
