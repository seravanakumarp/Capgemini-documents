/*
 * Private Constructor:
 * 1. A class which contains private constructor does not allow the object
 * to be created in another class.
 * 2. It allows the object to be created within the class.
 * 
 * Advantage:
 * 1. Implementation of Singleton class.
 * 2. A class which can contain only one object is called Singleton class.
 * 
 */
package OOPSConcepts;
class Test1
{
	int x;
	int y;
	
	private Test1(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	void display()
	{
		System.out.println(x+" "+y);
	}

}
public class Privateconstructor
{
	int rollno;
	String name;
	float marks;
	
	private Privateconstructor(int rollno,String name,float marks)
	{
		this.rollno=rollno;
		this.name=name;
		this.marks=marks;
	}
	void display()
	{
		System.out.println(rollno+" "+name+" "+marks);
	}
	public static void main(String[] args) 
	{
			//Test1 t=new Test1(10,20);
			//t.display();
			
			Privateconstructor pc=new Privateconstructor(123,"raju",456);
			pc.display();
	}

}
