package OOPSConcepts;
//A final method can be inherited.
class Circle
{
	public final float area()
	{
		float radius=5.0f;
		return 3.142f*radius*radius;
	}
}
public class Finalmethod2 extends Circle
{
 	public static void main(String[] args)
	{
 		Circle c=new Circle();
 		float area=c.area();
 		System.out.println("area of circle="+area);
	}

}
