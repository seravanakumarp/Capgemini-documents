package OOPSConcepts;
class Bank
{
	float savingsroi;
	float fdroi;
	float creditroi;
	
	Bank(float savingsroi,float fdroi,float creditroi)
	{
		this.savingsroi=savingsroi;
		this.fdroi=fdroi;
		this.creditroi=creditroi;
	}
}
class ICICI_Bank extends BankInfo
{
	String IFSCcode;
	String address;
	
	ICICI_Bank(float savingsroi,float fdroi,float creditroi,String IFSCcode,String address)
	{
		super(savingsroi,fdroi,creditroi);
		this.IFSCcode=IFSCcode;
		this.address=address;
	}
	public void get_i_details()
	{
		System.out.println(super.savingsroi+" "+super.fdroi+" "+" "+super.creditroi+this.IFSCcode+" "+this.address);
	}
	
}
class SBI_Bank extends BankInfo
{
	String IFSCcode;
	String address;
	
	SBI_Bank(float savingsroi,float fdroi,float creditroi,String IFSCcode,String address)
	{
		super(savingsroi,fdroi,creditroi);
		this.IFSCcode=IFSCcode;
		this.address=address;
	}
	public void get_s_details()
	{
		System.out.println(super.savingsroi+" "+super.fdroi+" "+" "+super.creditroi+this.IFSCcode+" "+this.address);
	}
	
}
public class SinglelevelInheritance2 {

	public static void main(String[] args) 
	{
		System.out.println("*********ICICI Bank details **********");
		ICICI_Bank i=new ICICI_Bank(4.5f,5.5f,6.5f,"ICIC00119","JUBILEEHILLS");
		i.get_i_details();
		
		System.out.println("**********SBI Bank details***********");
		
		SBI_Bank s=new SBI_Bank(5.5f,6.5f,7.5f,"SBI00022","MADHAPUR");
		s.get_s_details();
	}

}
