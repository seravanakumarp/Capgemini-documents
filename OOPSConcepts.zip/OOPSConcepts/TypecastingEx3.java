package OOPSConcepts;
class Employee1 {
    String name;
    int id;

    Employee1(String name, int id) {
        this.name = name;
        this.id = id;
    }

    void work() {
        System.out.println(name + " is working as an employee.");
    }
}

// Subclass: Manager
class Manager01 extends Employee1 {
    String department;

    Manager01(String name, int id, String department) {
        super(name, id); // Call the superclass (Employee) constructor
        this.department = department;
    }

    @Override
    void work() {
        System.out.println(name + " is managing the " + department + " department.");
    }

    // Manager-specific method
    void conductMeeting() {
        System.out.println(name + " is conducting a meeting.");
    }
}

// Subclass: Developer
class Developer1 extends Employee1 {
    String programmingLanguage;

    Developer1(String name, int id, String programmingLanguage) {
        super(name, id); // Call the superclass (Employee) constructor
        this.programmingLanguage = programmingLanguage;
    }

    @Override
    void work() {
        System.out.println(name + " is writing code in " + programmingLanguage + ".");
    }

    // Developer-specific method
    void writeCode() {
        System.out.println(name + " is writing code in " + programmingLanguage + ".");
    }
}

public class TypecastingEx3 {

	public static void main(String[] args)
	{
        // Upcasting: Treating Manager and Developer as Employees
        Employee1 employee1 = new Manager01("Raju", 101, "Sales"); // Upcast Manager to Employee
        Employee1 employee2 = new Developer1("Kapil", 102, "Java"); // Upcast Developer to Employee

        
        employee1.work();  // Calls Manager's work() method
        employee2.work();  // Calls Developer's work() method

        
        // Downcasting from Employee to Manager
            Manager01 manager = (Manager01) employee1; // Downcast Employee to Manager
            manager.conductMeeting(); // Access Manager-specific method
        

	}

}
