package OOPSConcepts;
//zero parameterized and parameterized constructor
class Test
{
	int x;
	float y;
	Test()
	{
		x=20;
		y=30;
	}
	Test(int x,int y)
	{
		this.x=x;
		this.y=y;
		System.out.println(this.x+" "+this.y);
	}
	public void display()
	{
		System.out.println(x+" "+y);
	}
}
public class Constructordemo 
{
	public static void main(String[] args)
	{
		Test100 t=new Test100();
		t.display();
		Test100 t1=new Test100(24,34);
		
		
	}

}
