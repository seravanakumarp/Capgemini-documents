/*
 * Reference variable:
 * -> A variable which is referring or pointing to an object is called
 * reference variable.
 * 
 * -> A reference variable of any class can refer to its object or objects
 * of same class.
 * 
 * -> A final to reference variable prevents from referring to the other
 * objects of a class but we can modify the contents of an object.
 * 
 * 
 */
package OOPSConcepts;

public class Finaltoreferencevariable 
{
	int x=10;
	int y=20;
	public static void main(String[] args) 
	{
		final Finaltoreferencevariable fto=new Finaltoreferencevariable();
		
		System.out.println("value of x="+fto.x);
		System.out.println("value of y="+fto.y);
		
		fto.x=33;
		fto.y=44;
		
		System.out.println("value of x="+fto.x);
		System.out.println("value of y="+fto.y);
		
		fto=new Finaltoreferencevariable();
		
	}

}
