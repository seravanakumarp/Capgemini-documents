package OOPSConcepts;
class Employee112
{
	private String name;
	private String address;
	private double salary;
	private String jobtitle;
	
	
	
	public Employee112(String name, String address, double salary, String jobtitle) {
		
		this.name = name;
		this.address = address;
		this.salary = salary;
		this.jobtitle = jobtitle;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	
	public double getBonus()
	{
		return 0.0;
		
	}
	public String getPerformanceReport()
	{
		return "no performance report";
	}
	
	public String getManagingprojects()
	{
		return "no assigned projects";
	}
}
class Manager1 extends Employee112
{
	int noofsuborrdinates;
	
	Manager1(String name,String address,double salary,String jobtitle,int noofsubordinates)
	{
		super(name,address,salary,jobtitle);
		this.noofsuborrdinates=noofsubordinates;
	}
	
	public double getBonus()
	{
		return getSalary()*0.20;
	}
	
	public String getPerformanceReport()
	{
		return "Excellent";
	}
	
	public String getManagingProjects()
	{
		return "handling multiple projects";
	}
	

}
class Developer extends Employee112
{
	String programminglanguage;
	
	Developer(String name,String address,double salary,String jobtitle,String programminglanguage)
	{
		super(name,address,salary,jobtitle);
		this.programminglanguage=programminglanguage;
	}
	
	public double getBonus()
	{
		return getSalary()*0.15;
	}
	
	public String getPerformanceReport()
	{
		return "Very good";
	}
	public String getManagingProjects()
	{
		return "Single Project";
	}
	
}
class Programmer extends Employee112
{
	String programminglanguage;
	Programmer(String name,String address,double salary,String jobtitle,String programminglanguage)
	{
		super(name,address,salary,jobtitle);
		this.programminglanguage=programminglanguage;
	}
	
	public double getBonus()
	{
		return getSalary()*0.10;
		
	}
	public String getPerformaceReport()
	{
		return "good";
	}
	public String getManagingProjects()
	{
		return "no project assigned";
	}
}
public class Inheritancehierarchy {

	public static void main(String[] args) 
	{
		
	}

}
