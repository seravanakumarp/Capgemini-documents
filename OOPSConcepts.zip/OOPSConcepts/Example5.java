package OOPSConcepts;

public class Example5 
{
	int x=10;
	static int y=20;
	
	static String s=new String("qedge");
	
	String s2=new String("ameerpet");
	
	public static void main(String[] args)
	{
		int z=30;
		
		String s1=new String("tech");
		
		Example5 e5=new Example5();
	}

}
