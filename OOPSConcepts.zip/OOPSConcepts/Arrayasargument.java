package OOPSConcepts;
//Passing array as an argument inside a method
public class Arrayasargument {

	public static void main(String[] args) 
	{
		int a[]=new int[]{10,20,30,40,50};
		
		show(a);
		
	}
	public static void show(int x[])
	{
		int i;
		
		for(i=0;i<x.length;i++)
			System.out.print(x[i]+" ");
	}

}
