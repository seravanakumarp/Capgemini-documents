package OOPSConcepts;
import java.io.*;
public class Throwsdemo1 
{
	public void Z() throws IOException
	{
		throw new IOException("error message");
	}
	public void Y() throws IOException
	{
		Z();
	}
	
	public void X() throws IOException
	{
		try
		{
			Y();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("exception handled");
		}
	}
	public static void main(String[] args) throws Exception
	{
		Throwsdemo1 td=new Throwsdemo1();
		td.X();
	}

}
