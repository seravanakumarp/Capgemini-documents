package OOPSConcepts;
abstract class GeometricalShape
{
	abstract double area();
	abstract double perimeter();
}
class Triangle1 extends GeometricalShape
{
	double a,b,c;

	
	Triangle1(double a,double b,double c)
	{
		this.a=a;
		this.b=b;
		this.c=c;
	}
	
	double area()
	{
		double side=(a+b+c)/2;
		double area_of_triangle=Math.sqrt(side*(side-a)*(side-b)*(side-c));
		return area_of_triangle;
	}
	double perimeter()
	{
		double perimeter_of_triangle=(a+b+c);
		return perimeter_of_triangle;
	}
	
}
class Square extends GeometricalShape
{
	double side;
	
	Square(double side)
	{
		this.side=side;
	}
	double area()
	{
		double area_of_square=side*side;
		return area_of_square;
	}
	double perimeter()
	{
		double perimeter_of_square=4*side;
		return perimeter_of_square;
	}
}
public class Abstractclassdemo3 {

	public static void main(String[] args) 
	{
		Triangle1 t1=new Triangle1(3.0, 4.0, 5.0);
		double area=t1.area();
		double perimeter=t1.perimeter();
		System.out.println("area of triangle="+area);
		System.out.println("perimeter of triangle="+perimeter);
		
		Square s1=new Square(5);
		double area2=s1.area();
		double perimeter2=s1.perimeter();
		System.out.println("area of square="+area2);
		System.out.println("perimeter of square="+perimeter2);
		
		
	}

}
