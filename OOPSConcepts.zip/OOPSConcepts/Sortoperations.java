package OOPSConcepts;
interface Sortable
{
	public void sort(int a[]); //abstract method
}
class Bubblesort implements Sortable
{
	public void sort(int a[])
	{
		int i,j,temp;
		
		for(i=0;i<a.length-1;i++)
		{
			for(j=0;j<a.length-1-i;j++)
			{
				if(a[j]>a[j+1])
				{
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
	}
}
class Selectionsort implements Sortable
{
	public void sort(int a[])
	{
		int i,j,min,pos=0;
		
		for(i=0;i<a.length;i++)
		{
			min=a[i];
			pos=i;
			
			for(j=i+1;j<a.length;j++)
			{
				if(a[j]<min)
				{
					min=a[j];
					pos=j;
				}
			}
			a[pos]=a[i];
			a[i]=min;
		}
	}
}
public class Sortoperations
{
	public static void main(String[] args)
	{
		int a[]= {24,12,33,5,67,44,55,2,90};
		Bubblesort bs=new Bubblesort();
		bs.sort(a);
		for(int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");
		System.out.println("");
		
		Selectionsort ss=new Selectionsort();
		ss.sort(a);
		for(int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");
		System.out.println("");
		
		
	}

}
