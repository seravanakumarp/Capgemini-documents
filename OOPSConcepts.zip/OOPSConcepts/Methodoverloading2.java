package OOPSConcepts;
class Shapes
{
	public float area(float radius)
	{
		return 3.142f*radius*radius;
	}
	public double area(double side)
	{
		return side*side;
	}
	public float area(float length,float breadth)
	{
		return length*breadth;
	}
	public double area(double base,double height)
	{
		return 0.5f*base*height;
	}
}
public class Methodoverloading2 {

	public static void main(String[] args) 
	{
		Shapes s=new Shapes();
	
		float result=s.area(4.5f);
		System.out.println("area of circle="+result);
		
		double result2=s.area(5.5);
		System.out.println("area of square="+result2);
		
		float result3=s.area(6.5f,7.5f);
		System.out.println("area of rectangle="+result3);
		
		double result4=s.area(4.56, 7.56);
		System.out.println("area of triangle="+result4);
		
		
	}

}
