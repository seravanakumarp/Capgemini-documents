/*
 * Throws:
 * -> When a method is not able to handle an exception, it can throw that
 * exception by means of throws keyword.
 * -> Generally throws is used for checked exceptions.
 * -> If a method is throwing an exception, the concerned method call
 * need to handle the exception.
 * -> In a hierarchy, if none of the method calls are not handling the
 * exception, the JVM will route the exception object to the default
 * exception handler.
 * -> Default exception handler will display the relevant information
 * to the user.
 * 
 * 
 */
package OOPSConcepts;
import java.io.*;
public class Throwsdemo {

	public static void main(String[] args) throws Exception
	{
		FileInputStream fis=new FileInputStream("D:/sample123.java");
		System.out.println("file opened successfully");
		fis.close();
		System.out.println("file closed successfully");
	}

}
