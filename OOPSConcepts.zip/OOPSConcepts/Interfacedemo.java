/*
 * Interface:
 * -> An interface is a collection of abstract methods only.
 * -> With the help of an interface we can make an agreement or contract
 * for implementing a project or software.
 * 
 * Syntax: 
 *        interface interfacename
 *        {
 *        	variables;
 *        	abstract methods;
 *        }
 * Example: interface Sample
 * 			{
 * 				int x=10;
 * 				void message();
 * 			}
 * -> All the variables inside of an interface are public static final 
 * whether we specify or not.
 * -> All the methods inside of an interface are public and abstract
 * whether we specify or not.
 * 
 * -> A public to a variable and method in an interface can be accessed
 * from anywhere from any location.
 * 
 * -> A static to a variable in an interface can be used to directly 
 * access the members with the interface name.
 * 
 * -> A final to a variable in an interface does not allow to modify
 * the value of a variable.
 * 
 * -> An abstract to a method in an interface defines that method does
 * not contain method definition.
 * 
 * -> An interface is considered as 100% abstraction and hence an interface
 * cannot be instantiated.If we want to access the members of an interface
 * a class must inherit the abstract class by implementing the methods
 * using implements keyword.
 * 
 * interface interfacename
 * {
 * }
 * class classname implements interfacename
 * {
 * }
 * -> A class which implements an interface must provide implementation 
 * to all the methods of interface.
 * -> A class which does not provide implementation to atleast one of 
 * the abstract method of an interface, then treat that class as abstract 
 * class.
 * -> A class which provides implementation to all the methods of an
 * interface, then that class is treated as implementation class.
 * -> An interface can contains many implementation class.
 * -> All the variables of an interface must be initialized by means of
 * interface name.
 * -> An interface cannot be instantiated but it can contain reference variable.
 * -> The reference variable of an interface can refer to the object
 * of implementation class.
 * -> In java, multiple inheritance is not supported, but it can be
 * achieved by means of interfaces.
 * 
 * -> A class can extend atmost one class.
 * -> A class can implement multiple interfaces.
 * -> An interface can extend any number of interfaces.
 * -> A class can extend a class and implement an interface at a time.
 * 
 * Marked Interface or Tagged Interface:
 * -> An interface is said to be marked if it is empty.
 * -> A marked interface will not contain any members in it.
 * -> The purpose of marked interface is to allow the user to add 
 * special instructions to the JVM to carryout a task.
 * 
 * 		Example: Cloneable, Serializable, RandomAccess
 * 
 * 
 * 
 * 
 */
package OOPSConcepts;
interface Animal001
{
	public void makesSound(); //abstract method
}
class Cat001 implements Animal001
{
	public void makesSound()
	{
		System.out.println("MEOW MEOW");
	}
}
class Dog001 implements Animal001
{
	public void makesSound()
	{
		System.out.println("BOW BOW");
	}
}

public class Interfacedemo
{
	public static void main(String[] args) 
	{
		Cat001 c=new Cat001();
		c.makesSound();
		
		Dog001 d=new Dog001();
		d.makesSound();
	}

}
