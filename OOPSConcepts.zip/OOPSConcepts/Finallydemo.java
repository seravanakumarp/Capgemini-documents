/*
 * finally:
 * -> It is block of statements.
 * -> It is meant for releasing the resources connected to an program.
 * -> It is used for checked exceptions.
 * -> finally block gets executed, even there is no exception raised in 
 * try-catch block.
 * -> finally block gets executed even in abnormal termination of a 
 * program.
 * 
 * -> There is no try block present without catch and finally.
 * -If a try catch are present, finally can be optional.
 * - If a try finally are present, catch can be optional.
 * - Sequence: try - catch - finally.
 * -> There cannot be a statement between try, catch and finally.
 * 
 * 
 * 
 * 
 */
package OOPSConcepts;
import java.io.*;
public class Finallydemo {

	public static void main(String[] args) throws Exception
	{
		/*try
		{
			int a[]= {10,20,30,40,50};
			
			for(int i=0;i<=a.length;i++)
				System.out.println(a[i]);
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			aie.printStackTrace();
		}
		finally
		{
			System.out.println("close the program");
		}
		*/
		
		FileInputStream fis=null;
		try
		{
			fis=new FileInputStream("D:/sample123.java");
			int ch;
			while((ch=fis.read())!=-1)
			{
				System.out.print((char)ch);
			}
			
		}
		catch(FileNotFoundException fe)
		{
			System.out.println(fe.toString());
		}
		finally
		{
			try
			{
			if(fis!=null)
				fis.close();
			}
			catch(IOException i)
			{
				System.out.println("io error");
			}
			catch(NullPointerException ne)
			{
				System.out.println("file cannot be closed");
			}
			System.out.println("file does not exist");
		}
	}

}
