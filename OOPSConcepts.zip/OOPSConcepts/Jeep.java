package OOPSConcepts;

public class Jeep 
{
	private String name;
	private String model;
	private float price;
	
	private Engine engine;
	
	Jeep(String name,String model,float price,String stroke)
	{
		this.name=name;
		this.model=model;
		this.price=price;
		this.engine=new Engine();
		engine.setStroke(stroke);
	}
	
	
	public String getName() {
		return name;
	}


	public String getModel() {
		return model;
	}


	public float getPrice() {
		return price;
	}


	public Engine getEngine() {
		return engine;
	}

	public static void main(String[] args) 
	{
		Jeep j=new Jeep("Mahindra","Thunder",1200000,"four");
		Engine e=j.engine;
		//Engine e=null;
		System.out.println(e.getStroke());
		
		System.out.println(j.getName()+" "+j.getModel()+" "+j.getPrice()+" "+e.getStroke());
				
		
	}

}
