/*
 * final class:
 * A final to a class cannot be inherited.
 * 
 */
package OOPSConcepts;
final class Test01
{
	public void display()
	{
		System.out.println("display method");
	}
	public void show()
	{
		System.out.println("show method");
	}
}
class Test2 extends Test01 //(error)cannot be inherited
{
	public void print()
	{
		System.out.println("print method");
	}
}
public class Finaltoclass {

	public static void main(String[] args) 
	{
		Test2 t=new Test2();
		t.display();
		t.show();
		t.print();
	}

}
