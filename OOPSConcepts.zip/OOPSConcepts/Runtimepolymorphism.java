/*
 * Runtime Polymorphism: 
 * -> If the polymorphic nature of an entity decided by an JVM during the
 * run time, then it is called Runtime polymorphism.
 * -> This Runtime polymorphism can be achieved by the help of method
 * overriding.
 * 
 * Method overriding:
 * -> the process of specifying two methods with same signature and same
 * return type defined in two different class having a IS-A relationship,
 * then it is called as method overiding.
 * 
 * -> When a method is invoked, the JVM will decide which method is to be
 * executed at run time, hence it is treated as run time polymorphism.
 * 
 * -> When a method is invoked, the JVM will link or bind the method
 * invocation with the method definition based on the object. 
 * 
 * -> Since the binding is done based on the type of object, it is
 * treated as dynamic binding.
 * 
 * -> Since the binding takes place after the beginning of execution of
 * a program and creation of an object it is called as late binding.
 * 
 * Why method overriding is required?
 * -> If the child class does not want the parent class method implementation
 * it can override with its own implementation.
 * 
 * Method overriding do takes place with respect to the instance methods
 * as well as static methods.
 * 
 * Method overriding with respect to the static methods we call it as
 * method overhiding.
 * 
 * Method overriding or method overhiding is possible only when the methods of
 * two classes are in IS-A relationship.
 * 
 * 
 */
package OOPSConcepts;
class Parent
{
	public void message()
	{
		System.out.println("good morning");
	}
}
class Child extends Parent
{
	public void message()
	{
		System.out.println("good evening");
	}
}
public class Runtimepolymorphism {

	public static void main(String[] args) 
	{
		Parent p=new Parent();
		p.message();
		
		Child c=new Child();
		c.message();
		
		Parent p1=new Child();
		p1.message();
		
		
/*NOTE: Any parent class reference variable can point to the object of any
child class.
	
				Ex: Object o=new Object();
				    Object o=new Employee();
				    Object o=new Student();
				    Object o=new String();
			
*/
	}

}
