/*
 * Constructor:

 * 1. It is used to instantiate the instance variables.
 * 2. Constructor will have the same name as that of class.
 * 3. Constructor is a special type of a method which does not return 
 * any value including void.
 * 4. Constructor are invoked as and when an object is created.
 * 5. Constructor supports of access specifiers such as public,
 * private,default and protected.
 * 6. Constructor does not support static,abstract and synchronized.
 * 
 * Types of Constructors:
 * 1. Default constructor
 * 2. Zero parameterized constructor
 * 3. Parameterized constructor
 * 4. Copy constructor(not supported by java).
 * 5. Private Constructor.
 * 6. Constructor chaining
 * 
 * Default constructor:
 * A default constructor is generated automatically by an compiler as and
 * when an object is created.
 * 
 * Zero parameterized constructor:
 * A constructor which does not contains any parameter is called 
 * zero parameterized constructor.
 * 
 * 				Syntax: Sample()
 * 						{
 * 						}
 * Parameterized constructor:
 * A constructor which can contain any number of parameters is called
 * parameterized constructor.
 * 
 * 			Syntax:  Sample(int x,int y,int z)
 * 					 {
 * 					 }
 * 
 * 
 * 
 * 
 */
package OOPSConcepts;

public class Constructor 
{
	int x;
	int y;
	Constructor() //zero parameterized constructor
	{
		x=10;
		y=20;
	}
	Constructor(int a,int b) //parameterized constructor
	{
	    x=a;
	    y=b;
	    System.out.println(x+" "+y);
	
	}
	void display()
	{
		System.out.println(x+" "+y);
	}
	public static void main(String[] args) 
	{
		Constructor c=new Constructor();
		c.display();
		
		Constructor c1=new Constructor(15,25);
	
	}

}
