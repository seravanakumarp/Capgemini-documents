/*
 * Abstract class:
 * 
 * concrete method:
 * A method which contains both the method declaration as well as method
 * definition is called as concrete method.
 * 
 * concrete class:
 * A class which contains concrete methods is called as concrete class.
 * 
 * abstract method:
 * A method which contains only method declaration without a method
 * definition is called abstract method.
 * 
 * Every abstract method must start with a keyword called abstract and
 * ends with a semicolon.
 * 
 * 		Syntax: abstract returntype methodname(parameter list);
 * 
 * abstract class:
 * A class which contains some abstract abstract methods is called as
 * abstract class.
 * 
 *      Syntax: abstract class classname
 *      		{
 *      			statements;
 *      		}
 *An abstract class contains both the concrete methods as well as 
 *abstract methods.
 *
 *An abstract class can contains zero or more abstract methods.
 *
 *If a class does not contain at least one abstract method, declaring them
 *as abstract class is optional.
 *
 *If a class contains at least one abstract method, declaring them as 
 *abstract class is mandatory.
 *
 *We cannot instantiate an abstract class,therefore, we cannot create an
 *object of abstract class and we cannot invoke any of abstract method.
 *
 *In order to invoke a  method of abstract class, we must inherit the 
 *abstract class by another class by overriding the methods in the abstract
 *class.
 *
 *If the subclass does not override atleast one of the abstract methods
 *of abstract class, it must be declared as abstract class.
 *
 *Why an abstract class cannot be instantiated?
 *Suppose let us assume that we have created an object of abstract class,
 *this object will invoke the concrete method and concrete method contains
 *method definition and gets executed. But if the same object invokes an
 *abstract method, it becomes an unsafe operation due to non availability
 *of method definition. In order to avoid this, we dont instantiate the 
 *abstract class.
 *
 *Why a method need to be declared as abstract?
 *If a method is declared as abstract, we can have method implementation
 *by different programmers with their own logic.
 *
 *
 *Why a class need to be declared as abstract though it does not contains
 *atleast one abstract method?
 *If a programmer does not want to create an object to a class, he can
 *make that particular class as abstract though it does not contain atleast
 *one abstract method.
 *
 *Can we have abstract to main class?
 *Yes we can apply abstract keyword to a main class.
 *
 *If a class whether is predefined or user defined, concrete or abstract 
 *class they are all subclass of super class called Object class.
 *
 *A class can be either abstract or concrete it will contains constructor
 *whether we specify or not.
 *
 *A constructor in an abstract class cannot be executed directly,but it 
 *get executed in its implementing subclass by creating an object.
 *
 *An abstract class reference variable can be used to refer the object
 *of implementing class.
 *
 *Modifiers: These are the keywords used to change the meaning of
 *declaration.
 *- A static modifier can be applied to variables,methods and classes.
 *- A final modifier can be applied to variables, methods and classes.
 *- An abstract modifier can be applied to methods and classes.
 *
 *Illegal combination of abstract methods.
 *-> An abstract method cannot have abstract and final.
 *-> An abstract method cannot have abstract and static.
 *
 *Illegal combination of abstract classes:
 * An abstract class cannot be abstract and final.
 *
 * 
 */
package OOPSConcepts;
abstract class Operation
{
	public void message()
	{
		System.out.println("happy coding in java");
	}
	abstract public void twice(int a);
}
class Programmer1 extends Operation
{
	public void twice(int x)
	{
		System.out.println(x*x);
	}
}
class Programmer2 extends Operation
{
	public void twice(int y)
	{
		System.out.println(2*y);
	}
}
class Programmer3 extends Operation
{
	public void twice(int z)
	{
		System.out.println(z<<1);
	}
}
public class Abstractclassdemo {

	public static void main(String[] args) 
	{
		Programmer1 p1=new Programmer1();
		p1.message();
		p1.twice(10);
		
		Programmer2 p2=new Programmer2();
		p2.twice(20);
		
		Programmer3 p3=new Programmer3();
		p3.twice(10);
		
		
	}

}
