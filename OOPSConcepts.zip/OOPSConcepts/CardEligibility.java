package OOPSConcepts;
class SmallAgeException extends Exception
{
	public SmallAgeException()
	{
		
	}
	SmallAgeException(String s)
	{
		super(s);
	}
}
class BigAgeException extends Exception
{
	public BigAgeException()
	{
		
	}
	BigAgeException(String s)
	{
		super(s);
	}
}
public class CardEligibility {

	public static void main(String[] args)
	{
		int age=Integer.parseInt(args[0]);
		
		try
		{
			if(age<20)
			{
				throw new SmallAgeException("Age is less than 20");
			}
			else if(age>30)
			{
				throw new BigAgeException("Age is greater than 30");
			}
			else
			{
				System.out.println("eligible for applying credit card");
			}
		}
		catch(SmallAgeException sae)
		{
			sae.printStackTrace();
		}
		catch(BigAgeException bae)
		{
			bae.printStackTrace();
		}
	}

}
