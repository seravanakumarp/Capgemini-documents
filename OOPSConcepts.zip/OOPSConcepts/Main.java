package OOPSConcepts;
import java.util.*;
public class Main 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		Student s=new Student();
		
		System.out.println("Enter the student rollno");
		int rollno=sc.nextInt();
		
		System.out.println("Enter the student name");
		String name=sc.next();
		
		System.out.println("Enter the student branch");
		String branch=sc.next();
		
		System.out.println("Enter the student marks");
		float marks=sc.nextFloat();
		
		s.setRollno(rollno);
		s.setName(name);
		s.setBranch(branch);
		s.setMarks(marks);
		
		System.out.println(s.getRollno()+" "+s.getName()+" "+s.getBranch()+" "+s.getMarks());
		
		
		

	}

}
