/*
 * Rules for accessing instance members and static members:
 * 
 * 1. Instance-Instance combination: An instance method can access the
 * instance members directly within a class,otherwise they are accessed 
 * by means of reference(object) only.
 * 
 * 2. Instance-static combination:An instance method can access the static
 * members directly within a class, otherwise they are accessed by
 * means of class name or reference(Object).
 * 
 * 3.Static-static combination: A static method can able to access the
 * static members directly within a class, otherwise they are accessed
 * by means of class name or reference(object).
 * 
 * 4. Static-instance combination: A static method can able to access
 * the instance members only by means of reference(object) whether it
 * is within the class or outside.
 * 
 * 
 * 
 */
package OOPSConcepts;

public class AccessRules1
{
	int x=11;
	static int y=22;
	
	void m1() //instance method
	{
		System.out.println("instance method m1");
	}
	void m2() //instance method
	{
		System.out.println(x); //rule1
		m1();  //rule1
		System.out.println(y); //rule2
		m3(); //rule2
		System.out.println("instance method m2");
		
	}
	static void m3()
	{
		System.out.println("instance method m3");
	}
	public static void main(String[] args) 
	{
		System.out.println(y); //rule3
		m3();  //rule3
		AccessRules1 ar1=new AccessRules1();
		System.out.println(ar1.x); //rule4
		ar1.m2(); //rule4
	}

}
