package Methodcalling;
import java.util.*;
public class Type3methodcalling {

	public static void main(String[] args)
	{
		int result;
		result=sum_of_digits();
		
		System.out.println("sum of individual digits of a number="+result);
	}
	public static int sum_of_digits()
	{
		Scanner sc=new Scanner(System.in);
		
		int n,sum=0,rem;
		
		System.out.println("enter the value of n");
		n=sc.nextInt();
		
		while(n!=0)
		{
			rem=n%10;
			sum=sum+rem;
			n=n/10;
		}
		
		return sum;
		
	}

}
