package OOPSConcepts;
abstract class Shape001
{
	double dim1,dim2;
	Shape001(double dim1,double dim2)
	{
		this.dim1=dim1;
		this.dim2=dim2;
	}
	abstract double area();
}
class Rectangle001 extends Shape001
{
	double length,breath;
	Rectangle001(double length,double breadth)
	{
		super(length,breadth);
	}
	double area()
	{
		return dim1*dim2;
	}
}
class Triangle001 extends Shape001
{
	double base,height;
	public Triangle001(double base,double height) 
	{
		super(base,height);
	}
	public double area()
	{
		return 0.5*dim1*dim2;
	}
}
public class Abstractclassdemo2 
{

	public static void main(String[] args) 
	{
		Shape001 s1=new Rectangle001(10.0,20.0);
		double area=s1.area();
		System.out.println("area of rectangle="+area);
		
		Shape001 s2=new Triangle001(10.0,20.0);
		double area2=s2.area();
		System.out.println("area of triangle="+area2);
	}

}
