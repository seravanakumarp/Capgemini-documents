/*
 * Constructor chaining:

 * ->It is a process of invoking a constructor by an another constructor.
 * -> this() is used to implement this constructor chaining.
 * 
 * Use of Constructor chaining:
 * -> We can implement constructor overloading.
 * 
 */
package OOPSConcepts;
class Test10 
{
	Test10()
	{
		this(20);
		System.out.println("parent constructor");
	}
	Test10(int x)
	{
		System.out.println("value of x="+x);
	}
}
class Sample extends Test10
{
	Sample()
	{
		this(10);
		System.out.println("default constructor");
	}
	Sample(int x)
	{
		this(10,20);
		System.out.println("value of x="+x);
	}
	Sample(int x,int y)
	{
		this("sachin");
		System.out.println("value of x="+x+"value of y="+y);
	}
	Sample(String s)
	{
		super();
		System.out.println(s);
	}
}

public class Constructorchaining {

	public static void main(String[] args) 
	{
		Sample s=new Sample();
	}

}
