/*
 * Java API do comes with five keywords which we can use it
 * for exception handling:
 * 1. try
 * 2. catch
 * 3. finally
 * 4. throw
 * 5. throws
 * 
 * try:
 * 1. It is a keyword in java.
 * 2. It is a block of statements.
 * 3. It contains doubtful code which may cause an exception.
 * 4. Once the exception is raised, an exception object gets created
 * and routed to the catch block instead of JVM.
 * 
 * catch:
 * 1. It is a block of statements.
 * 2. It contains the exception handling code which handles the
 * exception being raised in the try block.
 * 
 * 			Syntax: try
 * 					{
 * 						//doubtful code
 * 						//related info
 * 					}
 * 					catch(Exception_name variable)
 * 					{
 * 						//exception handling code
 * 					}
 * 					variable- is a reference variable which 
 * 					refers to the exception object.
 * 
 * Different ways of displaying the information about an exception:
 * 1. printStackTrace():
 * It is used to display the detailed information about an exception.
 * The detailed information includes exception name, reason for 
 * occurrence of an exception, method name,class name and the line number
 * where the exception has raised.
 * 
 * 2. toString():
 * it is used to display the exception name and reason for occurrence 
 * of an exception in a program.
 * 
 * 3. getMessage():
 * it is used to display only the reason for occurrence of exception in 
 * a program.
 * 
 * Note:
 * Once an exception is raised in try block, the control will shift
 * automatically to catch block.
 * Once the catch block is executed, it will not come back to the
 * try block.
 * If there is no exception raised in try block, catch block will never
 * gets executed.
 * 
 * try with multiple catch blocks:
 * 
 * A try is a set of instructions which could cause an exception.
 * It is possible to have more than one instructions which may cause
 * an exception. 
 * It is possible to handle only one exception at time,among 
 *  multiple catch blocks.
 *  
 * NOTE: We cannot handle same exception more than one time, in a
 * given single try block.
 * 
 * 
 * 
 */
package OOPSConcepts;
import java.util.*;
public class Exceptionhandlingdemo {

	public static void main(String[] args) 
	{
		/*try
		{
			int a=10,b=0,c;
			c=a/b;
			System.out.println(c);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("denominator cannot be zero");
		}*/
		
		/*try
		{
			Scanner sc=new Scanner(System.in);
			int a[]=new int[10];
			int i,n;
			
			System.out.println("enter the size of an array a");
			n=sc.nextInt();
			
			System.out.println("enter the array a elements are");
			for(i=0;i<n;i++)
				a[i]=sc.nextInt();
			
			System.out.println("array a elements are.....");
			for(i=0;i<n;i++)
				System.out.println(a[i]);
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			//aie.printStackTrace();
			//System.out.println(aie.toString());
			System.out.println(aie.getMessage());
		}
		*/
		
		/*try
		{
			Scanner sc=new Scanner(System.in);
			String s[]=new String[5];
			int n;
			System.out.println("enter the number of strings to be stored");
			n=sc.nextInt();
			
			System.out.println("Enter the string");
			for(int i=0;i<n;i++)
				s[i]=sc.next();
			for(int i=0;i<n;i++)
				System.out.println(s[i]);
			
			String s1="1244";
			int i=Integer.parseInt(s1);
			System.out.println("value of i="+i);
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("more inputs beyond the size,task failed");
		}
		catch(NumberFormatException nfe)
		{
			System.out.println("invalid input,task failed");
		}*/
		
		try
		{
			int a=10,b=0,c;
			
			c=a/b;
			System.out.println(c);
			
			int x=20,y=0,z;
			z=x/y;
			System.out.println(z);
		}
		catch(ArithmeticException ae1)
		{
			ae1.printStackTrace();
		}
		catch(ArithmeticException ae1) //error: unreachable code. already handled
		{
			ae1.printStackTrace();
		}
		
		
	}

}
