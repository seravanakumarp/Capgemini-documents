/*
 * Constructor Overloading:
 * -> The process of specifying multiple constructors with same name
 *  with different method signature is called constructor overloading.
 * 
 * Why do we need constructor overloading?
 * -> It provides flexibility to the user in terms of creating different
 * object with respective to their type based on the requirement.
 * 
 * NOTE: Constructor overloading is possible only within the class.
 * It is not possible to have constructor overloading between two classes
 * though there are in IS-A Relationship.
 * 
 */
package OOPSConcepts;
class Rectangle
{
	int length,breadth;
	
	Rectangle()
	{
		length=breadth=4;
	}
	Rectangle(int n)
	{
		length=breadth=n;
	}
	Rectangle(int length,int breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	public void area()
	{
		System.out.println("area of rectangle="+(length*breadth));
	}
}
public class Constructoroverloading {

	public static void main(String[] args) 
	{
		Rectangle r=new Rectangle();
		r.area();
		Rectangle r1=new Rectangle(4, 5);
		r1.area();
		Rectangle r2=new Rectangle(10);
		r2.area();
		
	}

}
