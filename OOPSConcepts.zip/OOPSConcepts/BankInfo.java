package OOPSConcepts;
class InsufficientFundsException extends Exception
{
	int needs;
	public InsufficientFundsException(int needs) 
	{
		this.needs=needs;
	}
	public int getNeeds()
	{
		return this.needs;
	}
}
class Account
{
	int balance;
	Account(int amount)
	{
		this.balance=amount;
	}
	int getBalance()
	{
		return this.balance;
	}
	void withdraw(int amount) throws InsufficientFundsException
	{
		if(amount<=this.balance)
		{
			this.balance=this.balance-amount;
		}
		else
		{
			int needs=amount-this.balance;
			throw new InsufficientFundsException(needs);
		}
	}
}
public class BankInfo {

	public static void main(String[] args) 
	{
		Account acc=new Account(5000);
		try
		{
			acc.withdraw(4000);
			System.out.println(acc.getBalance());
			acc.withdraw(3000);
			System.out.println(acc.getBalance());
		}
		catch(InsufficientFundsException ife)
		{
			System.out.println("needs="+ife.getNeeds());
		}
	}

}
