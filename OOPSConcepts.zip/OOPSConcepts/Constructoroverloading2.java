package OOPSConcepts;
class Shapes11
{
	Shapes11(float radius)
	{
		float area;
		area=3.142f*radius*radius;
		System.out.println("area of circle="+area);
	}
	Shapes11(double side)
	{
		double area;
		area=side*side;
		System.out.println("area of square="+area);
	}
	Shapes11(float length,float breadth)
	{
		float area;
		area=length*breadth;
		System.out.println("area of rectangle="+area);
	}
	Shapes11(double base,double height)
	{
		double area;
		area=0.5f*base*height;
		System.out.println("area of triangle="+area);
	}
}
public class Constructoroverloading2 {

	public static void main(String[] args) 
	{
		Shapes11 s=new Shapes11(4.5f);
		Shapes11 s1=new Shapes11(5.5);
		Shapes11 s2=new Shapes11(3.5f, 4.5f);
		Shapes11 s3=new Shapes11(5.5, 6.5);
		
	}

}
