package OOPSConcepts;

public class Methodreturningstringarray {

			public static void main(String[] args) 
			{
				Methodreturningstringarray mrsa=new Methodreturningstringarray();
				
				String str[]=mrsa.show();
				
				for(int i=0;i<str.length;i++)
					System.out.print(str[i]+" ");
			}
			String[] show()
			{
				String s[]= {"venkat","raju","dheeraj","kapil","anand"};
				return s;
			}
}
