package OOPSConcepts;

public class Copyconstructor 
{
	int empno;
	String name;
	float salary;
	
	Copyconstructor(int empno,String name,float salary)
	{
		this.empno=empno;
		this.name=name;
		this.salary=salary;
		
		System.out.println(this.empno+"  "+this.name+" "+this.salary);
	}
	
	Copyconstructor(Copyconstructor cc)
	{
		empno=cc.empno;
		name=cc.name;
		salary=cc.salary;
	}
	public static void main(String[] args)
	{
		Copyconstructor cc=new Copyconstructor(123,"sachin", 55000);
		
		Copyconstructor cc1=new Copyconstructor(cc);
		
		System.out.println(cc1.empno+" "+cc1.name+" "+cc1.salary);
		
	}

}
