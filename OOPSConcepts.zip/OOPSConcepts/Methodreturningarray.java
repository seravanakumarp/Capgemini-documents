package OOPSConcepts;

public class Methodreturningarray {

	public static void main(String[] args)
	{
		Methodreturningarray mra=new Methodreturningarray();
		
		int y[]=mra.display();
		
		for(int i=0;i<y.length;i++)
			System.out.print(y[i]+" ");
	}

	int[] display()
	{
		int a[]= {1,2,3,4,5};
		return a;
	}
}
