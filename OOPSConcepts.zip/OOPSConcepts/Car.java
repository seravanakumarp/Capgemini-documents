package OOPSConcepts;

public class Car 
{
	private String name;
	private String model;
	private float price;
	
	private Musicplayer mp;
	
	public Car(String name, String model, float price, Musicplayer mp) 
	{
		
		this.name = name;
		this.model = model;
		this.price = price;
		this.mp = mp;
	}
	
	@Override
	public String toString() {
		return "Car [name=" + name + ", model=" + model + ", price=" + price + ", mp=" + mp + "]";
	}

	public static void main(String[] args)
	{
		//Musicplayer mp=new Musicplayer("Sony","mp4", 35000.0f);
		
		Musicplayer mp=null;
		
		Car c=new Car("Hyundai","i20", 1000000, mp);
		
		System.out.println(c);
		
	}

}
