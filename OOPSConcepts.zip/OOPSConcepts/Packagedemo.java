/*
 * Package:
 * A package is a collection of related classes and interfaces.
 * The main purpose of packages in java is to improve the performance
 * and define the accessibility.
 * 
 * The other key purpose of packages is avoid the naming collisions
 * between the classes.
 * 
 * These are packages are classified into two categories:
 * 1. Predefined packages
 * 2. User defined packages
 * 
 * Predefined packages: A package which is provided by an software company
 * such as SunMicrsystem are called as Predefined packages.
 * 
 * 1. core packages: A package which is provided by SunMicrosystem and 
 * starts with name called 'java' are called as core packages.
 * 
 * 2. Extended packages: A package which is provided by SunMicrosystem
 * and starts with name called 'javax' are called as extended packages.
 * 
 * 3. Third party packages/Vendor packages:
 * A package which is provided by another organization or a company
 * are called as vendor or third party packages. These packages can 
 * start with any name.
 * 
 * Some of predefined packages in java:
 * 1. java.lang: it is a package meant for basic programming.
 * 2. java.io: it is a package meant for reading and writing operations.
 * 3. java.util: it is a package meant for Date,Time and Collections.
 * 4. java.net: it is a package meant for designing network based
 * applications.
 * 5. java.text: it is a package meant for formatting text, numbers,
 *  dates and currency. It is basically meant for achieving internationalization
 * 6. java.awt: it is a package meant for designing GUI applications.
 * 7. javax.swings: it is an extended package meant for designing better
 * GUI applications than awt.
 * 8. java.applets: it is a package meant for designing Distributed GUI
 * base applications.
 * 
 * Creation of user defined packages:
 * 
 * 
 * 
 * 
 * 
 */
package OOPSConcepts;

public class Packagedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
