package com.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "features",glue = "com.stepdef",
plugin = {"pretty:target/pretty.txt",
		"json:target/cucumber.json",
		"junit:target/cucumber.xml",
		"usage:target/usage.json",
		"html:target/index.html"},
dryRun = false,
monochrome = true,
tags = "@positive or @login")
public class TestRunner {

}
