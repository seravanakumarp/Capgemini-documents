package com.stepdef;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class RegisterStepDef {
WebDriver driver;
@Given("User should be on the registration page")
public void user_should_be_on_the_registration_page() {
   WebDriverManager.chromedriver().setup();
   driver = new ChromeDriver();
   driver.get("https://demo.automationtesting.in/Register.html");
   driver.manage().window().maximize();
}

@When("User need to enter the following details")
public void user_need_to_enter_the_following_details(io.cucumber.datatable.DataTable dataTable) {
   Map<String,String> fields=dataTable.asMap(String.class,String.class);
   String firstname = fields.get("firstname");
   String lastname = fields.get("lastname");
   String address = fields.get("address");
   String email = fields.get("email");
   String phone = fields.get("phone");
   
   driver.findElement(By.xpath("//input[contains(@class,'form-control ng-pristine')]")).sendKeys(firstname);
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[2]/input")).sendKeys(lastname);
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[2]/div/textarea")).sendKeys(address);
	driver.findElement(By.xpath("//*[@id=\"eid\"]/input")).sendKeys(email);
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[4]/div/input")).sendKeys(phone);
}

@When("User clicks on submit button on registration page")
public void user_clicks_on_submit_button_on_registration_page() {
	System.out.println("User clicks on submit");
   
}
@Then("User gets email for successful registration")
public void user_gets_email_for_successful_registration() {
    System.out.println("User gets email");
}



}
