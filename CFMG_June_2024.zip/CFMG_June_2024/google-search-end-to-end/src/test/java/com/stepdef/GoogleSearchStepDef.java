package com.stepdef;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.pages.HomePage;
import com.pages.SearchResultPage;
import com.parameter.ExcelReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;


public class GoogleSearchStepDef {
	WebDriver driver;
	HomePage homePage;
	SearchResultPage searchResultPage;
	
	@Before
	public void init()
	{
		
		/*
		 * 
		 * start-maximized: Opens Chrome in maximize mode
incognito: Opens Chrome in incognito mode
headless: Opens Chrome in headless mode
disable-extensions: Disables existing extensions on Chrome browser
disable-popup-blocking: Disables pop-ups displayed on Chrome browser
make-default-browser: Makes Chrome default browser
version: Prints chrome browser version
disable-infobars: Prevents Chrome from displaying the notification ‘Chrome is being controlled by automated software
		 */
		
		WebDriverManager.chromedriver().setup(); //move it to another class
		ChromeOptions options = new ChromeOptions();
		//options.addArguments("start-maximized");
		//options.addArguments("incognito");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-notifications");
		
	    driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		
	}
	//--------------------------------------------------------Scenario 1----------------------------------------//
    /*
     * Created By: Medha Joshi
     * Reviewed By: Giri Joshi
     * Motive: user should enter all the detail and click on search btn
     */

@Given("User is on the google homepage")
public void user_is_on_the_google_homepage() {
	Properties properties=new Properties();
	try {
		properties.load(new FileInputStream("src/test/resources/config.properties"));
		String url=properties.getProperty("url");
		driver.get(url);
		homePage=new HomePage(driver);
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	
  
}
@When("User inputs search text")
public void user_inputs_search_text() {
   homePage.searchText("Capgemini India");
}
@When("User hits enter key")
public void user_hits_enter_key() {
	searchResultPage=homePage.searchTextSubmit();
   
}
@Then("User is on the search result page")
public void user_is_on_the_search_result_page() {
 System.out.println("Validate result Page");
}
@Then("User validates the result page")
public void user_validates_the_result_page() {
	 System.out.println("Validate result Page2");
	 
}

//--------------------------------------------------------Scenario 2----------------------------------------//
/*
 * Created By: Medha Joshi
 * Reviewed By: Giri Joshi
 * Motive: user should enter all the detail and click on search btn
 */

@When("User inputs search text as {string}")
public void user_inputs_search_text_as(String textVal) {
	   homePage.searchText(textVal);
}


//--------------------------------------------------------Scenario 3----------------------------------------//
/*
* Created By: Medha Joshi
* Reviewed By: Giri Joshi
* Motive: user should enter all the detail and click on search btn taking data from Excel sheet
*/



@When("User inputs search text from {int} and {int}")
public void user_inputs_search_text_from_and(Integer sheetno, Integer rowno) {
  ExcelReader excelReader=new ExcelReader();
  String textVal = excelReader.getSearchTextFromExcel(sheetno, rowno);
  homePage.searchText(textVal);
}



@After
public void tearDown()
{
	try {
		searchResultPage.tearDown();
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
}

}
