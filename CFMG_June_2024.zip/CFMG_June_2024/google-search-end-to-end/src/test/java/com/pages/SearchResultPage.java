package com.pages;

import org.openqa.selenium.WebDriver;

public class SearchResultPage  extends BasePage{

	public SearchResultPage(WebDriver driver) {
		super(driver);
		
	}

}
