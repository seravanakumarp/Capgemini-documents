package com.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

	//Object Repo-- 
	@FindBy(name="q")
	WebElement searchELe;
	
	Properties properties;
	
	//Ctor
	public HomePage(WebDriver driver) {
		super(driver);
		properties=new Properties();
		try {
			properties.load(new FileInputStream("src/test/resources/objectrepo.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	// Methods
	
	public void searchText(String text)
	{
		//searchELe.sendKeys(text);
		driver.findElement(By.xpath(properties.getProperty("searchTextAreaXpath"))).sendKeys(text);
		
		
	}
	
	public SearchResultPage searchTextSubmit()
	{
		SearchResultPage searchResultPage = new SearchResultPage(driver);
		searchELe.submit();
		return searchResultPage;
		
	}
	
	
	

}
