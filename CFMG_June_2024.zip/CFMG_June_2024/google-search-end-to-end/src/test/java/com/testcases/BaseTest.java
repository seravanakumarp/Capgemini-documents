package com.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.pages.HomePage;
import com.pages.SearchResultPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {
protected WebDriver driver;
HomePage homePage;
SearchResultPage searchResultPage;

@BeforeMethod
public void initT()
{
	//Read browser and url from properties file
	WebDriverManager.chromedriver().setup();
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.google.com/");
	homePage=new HomePage(driver);
}

@AfterMethod
public void tearDown()
{
	try {
		Thread.sleep(3000);
		driver.quit();
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	
	
}

}
