package com.testcases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class UsabilityTest extends BaseTest {
	@Test(dataProvider = "textvalDP")
	@Parameters({"textval"})
	public void searchTest(String textval)
	{
		homePage.searchText(textval);
		homePage.searchTextSubmit();
		tearDown();//of BaseTest
	}
	
	@DataProvider(name="textvalDP")
	public Object[] dataProviderSearch()
	{
		Object[] obj= {"C","CPP","Fortran"};
		return obj;
	}
	
	
}
