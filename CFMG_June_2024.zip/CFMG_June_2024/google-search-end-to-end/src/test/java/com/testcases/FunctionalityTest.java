package com.testcases;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class FunctionalityTest extends BaseTest{

	@Test
	@Parameters({"textval"})
	public void searchTest(@Optional("Pascal")  String textval)
	{
		homePage.searchText(textval);
		homePage.searchTextSubmit();
		tearDown();//of BaseTest
	}
}
