package com.parameter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	public String getSearchTextFromExcel(int sheetno,int rowno)
	{
		try {
			FileInputStream fis=new FileInputStream("src/test/resources/searchtextfile.xlsx");
			XSSFWorkbook workBook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workBook.getSheetAt(sheetno); 
			XSSFRow row=sheet.getRow(rowno);
			XSSFCell cell=row.getCell(0);
			String data=cell.getStringCellValue();
			return data;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
