package com.registrationpage;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RegistrationPageDemo {
WebDriver driver;
public RegistrationPageDemo()
{
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
}

public void loadUrl()
{
	driver.get("https://demo.automationtesting.in/Register.html");
	driver.manage().window().maximize();
}

public void personalInfo() throws InterruptedException
{
	Thread.sleep(20000);
	driver.findElement(By.xpath("//*[@class='form-control ng-pristine ng-invalid ng-invalid-required ng-touched']")).sendKeys("Raj");
	driver.findElement(By.xpath("//input[@class='form-control ng-pristine ng-invalid ng-invalid-required ng-touched'][@placeholder='Last Name']")).sendKeys("Sharma");
	driver.findElement(By.xpath("//textarea[@class='form-control ng-pristine ng-valid ng-touched']")).sendKeys("Jayanagar Banglore");
	driver.findElement(By.xpath("//input[@class='form-control ng-pristine ng-valid-email ng-invalid ng-invalid-required ng-touched']")).sendKeys("raj.sharma@gmail.com");
	driver.findElement(By.xpath("//input[@class='form-control ng-pristine ng-invalid ng-invalid-required ng-valid-pattern ng-touched']")).sendKeys("1234567890");
}


public void  genderManage(String genValue) throws InterruptedException
{
	Thread.sleep(2000);
	List<WebElement> elements = driver.findElements(By.xpath("//input[@name='radiooptions']"));
	Iterator<WebElement> itr = elements.iterator();
	while(itr.hasNext())
	{
		WebElement temp = itr.next();
		if(temp.getAttribute("value").equals(genValue))
		{
			temp.click();
			break;
		}
		
	}
}

public void  hobbyManage() throws InterruptedException
{
	Thread.sleep(2000);
	List<WebElement> elements = driver.findElements(By.xpath("//input[@type='checkbox']"));
	Iterator<WebElement> itr = elements.iterator();
	while(itr.hasNext())
	{
		WebElement temp = itr.next();
		if(temp.getAttribute("value").equals("Cricket"))
		{
			temp.click();
		}
		if(temp.getAttribute("value").equals("Movies"))
		{
			temp.click();
		}
		
	}
}


public void languages()
{
	JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("window.scrollTo(0,180)");
	
	driver.findElement(By.id("msdd")).click();  // input dropdown
	
	driver.findElement(By.linkText("Danish")).click();
	driver.findElement(By.linkText("Dutch")).click();
	driver.findElement(By.linkText("German")).click();
}

public void skills()
{
	WebElement element = driver.findElement(By.id("Skills"));
	
	Select sel = new Select(element);
	sel.selectByValue("Android");
	//sel.selectByIndex(2);
	//sel.deselectByIndex(0);

	
}


public void country()
{
	WebElement element = driver.findElement(By.id("countries"));
	
	Select sel = new Select(element);
	//sel.selectByValue("Android");
	sel.selectByIndex(0);
	//sel.deselectByIndex(0);
	
	
	
 element = driver.findElement(By.id("country"));
	
	sel = new Select(element);
	sel.selectByValue("India");
	

}


public void dateOfBirth()
{
	//Year
	WebElement element = driver.findElement(By.id("yearbox"));
	Select sel = new Select(element);
	sel.selectByValue("1999");

	
	//Mon
		element = driver.findElement(By.xpath("//select[@placeholder='Month']"));
		sel = new Select(element);
		sel.selectByValue("May");

		

		//Day
			element = driver.findElement(By.id("daybox"));
			sel = new Select(element);
			sel.selectByValue("10");

	
}


public void password()
{
	
	driver.findElement(By.id("firstpassword")).sendKeys("rajsharma");
	
	driver.findElement(By.id("secondpassword")).sendKeys("rajsharma");
	
	
}

public void submitRefresh()
{
	driver.findElement(By.id("submitbtn")).click();
	driver.findElement(By.id("Button1")).click();
}




public void tearDown() throws InterruptedException
{
	Thread.sleep(4000);
	driver.quit();
}


public void fileUpload()
{
	WebElement element = driver.findElement(By.id("imagesrc"));
	element.sendKeys("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\regPage.txt");
	
}
}
