package com.registrationpage;

public class TestRegistrationPage {

	public static void main(String[] args) throws InterruptedException {
		RegistrationPageDemo rp = new RegistrationPageDemo();
		rp.loadUrl();
		rp.personalInfo();
		rp.genderManage("Male");
		rp.hobbyManage();
		
		rp.languages();
		rp.skills();
		rp.country();
		rp.dateOfBirth();
		rp.password();
		rp.fileUpload();
		rp.submitRefresh();
		
		
		
		
		
		
		rp.tearDown();

	}

}
