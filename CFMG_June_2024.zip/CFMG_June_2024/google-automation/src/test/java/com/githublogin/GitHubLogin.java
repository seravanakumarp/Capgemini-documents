package com.githublogin;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GitHubLogin {
WebDriver driver;

public GitHubLogin()
{
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
}

public void loadUrl()
{
	driver.manage().window().maximize();
	
	driver.get("https://github.com/");
	System.out.println(driver.getTitle());
//	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//	wait.until(ExpectedConditions.titleContains("git"));
	
}

public void signIn()
{
	WebElement signIn = driver.findElement(By.linkText("Sign in"));
	signIn.click();
}
	
public void login() throws InterruptedException
{
	//Thread.sleep(3000);
	//.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	//WebElement uname = driver.findElement(By.cssSelector("input[name='login']"));
	
	By obj = By.cssSelector("input[name='login']");
//	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//	WebElement uname = wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
	
	//parent
	FluentWait wait = new FluentWait(driver);
	wait.withTimeout(Duration.ofSeconds(10));
	wait.pollingEvery(Duration.ofSeconds(1));
	wait.ignoring(NoSuchElementException.class);
	WebElement uname = (WebElement) wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
	
	//child
//	WebDriverWait
	uname.sendKeys("MedhaJoshi");
	
	
	//Thread.sleep(3000);
	WebElement pwd = driver.findElement(By.xpath("//input[@name='password']"));
	pwd.sendKeys("Medha@123");
	
	//.sleep(3000);
	WebElement signinButton = driver.findElement(By.name("commit"));
	signinButton.click();
	
	

	WebElement text = driver.findElement(By.className("js-flash-alert"));
	System.out.println(text.getText());
	
} 

public void tearDown() throws InterruptedException
{
	Thread.sleep(4000);
	driver.quit();
}


}
