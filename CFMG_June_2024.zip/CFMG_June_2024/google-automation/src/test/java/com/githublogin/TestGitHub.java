package com.githublogin;

public class TestGitHub {

	public static void main(String[] args) throws InterruptedException {
//		GitHubLogin gl = new GitHubLogin();
//		gl.loadUrl();
//		gl.signIn();
//		gl.login();
//		//gl.tearDown();
		
		String day = "22";
		//Dynamic xpath
		String xpath_ex = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[4]/td/a[contains(text(),\"22\")]"
		
//		String org = "CG";
//		String city = "Pune";
//		String last = "I am Raj working in "+org+" at "+city;
//		
 
	}

}
