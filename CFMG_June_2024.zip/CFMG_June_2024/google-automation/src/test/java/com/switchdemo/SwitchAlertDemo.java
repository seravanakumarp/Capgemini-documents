package com.switchdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SwitchAlertDemo 
{
	WebDriver driver;


public SwitchAlertDemo()
{
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
}

public void loadUrl()
{
	driver.get("https://demo.automationtesting.in/Alerts.html");
	driver.manage().window().maximize();
}


public void alertOK() throws InterruptedException
{
	driver.findElement(By.linkText("Alert with OK")).click();
	driver.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();
	
	//driver.switchTo().alert();
	Thread.sleep(3000);
	String str = driver.switchTo().alert().getText();
	System.out.println(str);
	driver.switchTo().alert().accept();
	
}



public void alertOK_CANCEL() throws InterruptedException
{
	driver.findElement(By.linkText("Alert with OK & Cancel")).click();
	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	
	Thread.sleep(3000);
	String str = driver.switchTo().alert().getText();
	System.out.println(str);
	driver.switchTo().alert().dismiss();
	
	String text = driver.findElement(By.id("demo")).getText();
	System.out.println(text);
	
	
}


public void alertInput() throws InterruptedException
{
	driver.findElement(By.linkText("Alert with Textbox")).click();
	driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
	
	Thread.sleep(3000);
	String str = driver.switchTo().alert().getText();
	System.out.println(str);
	driver.switchTo().alert().sendKeys("Raj");
	driver.switchTo().alert().accept();
	
	String text = driver.findElement(By.id("demo1")).getText();
	System.out.println(text);
	
}

public void tearDown() throws InterruptedException
{
	Thread.sleep(4000);
	driver.quit();
}
}
