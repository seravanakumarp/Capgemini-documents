package com.switchdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SwitchFrameDemo {
WebDriver driver;


public SwitchFrameDemo()
{
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
}

public void loadUrl()
{
	driver.get("https://demo.guru99.com/selenium/deprecated.html");
	driver.manage().window().maximize();
}

public void depricatedDisp()
{
	driver.switchTo().frame("classFrame");
	driver.findElement(By.linkText("Deprecated")).click();
	System.out.println("---------------");
	
	driver.switchTo().defaultContent();
	//driver.switchTo().parentFrame();
	System.out.println("Frame count="+driver.findElements(By.tagName("frame")).size());
	driver.switchTo().frame("packageListFrame");
	driver.findElement(By.linkText("com.thoughtworks.selenium")).click();
	
	driver.switchTo().parentFrame();
	driver.switchTo().frame("packageFrame");
	driver.findElement(By.linkText("CommandProcessor")).click();
}

public void tearDown() throws InterruptedException
{
	Thread.sleep(4000);
	driver.quit();
}
}
