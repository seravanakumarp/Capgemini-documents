package com.switchdemo;

public class TestWindow {

	public static void main(String[] args) throws InterruptedException {
		SwitchWindowDemo sw = new SwitchWindowDemo();
		sw.loadUrl();
		sw.windowSwitch();
		
		
		sw.tearDown();
	}

}
