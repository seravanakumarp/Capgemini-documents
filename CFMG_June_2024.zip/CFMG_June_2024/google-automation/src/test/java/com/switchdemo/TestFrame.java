package com.switchdemo;

public class TestFrame {

	public static void main(String[] args) throws InterruptedException {
	SwitchFrameDemo sf = new SwitchFrameDemo();
	sf.loadUrl();

	 sf.depricatedDisp();            
	
	sf.tearDown();
	}

}
