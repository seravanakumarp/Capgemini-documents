package com.switchdemo;

public class TestAlert {

	public static void main(String[] args) throws InterruptedException {
		SwitchAlertDemo sa = new SwitchAlertDemo();
		sa.loadUrl();
		//sa.alertOK();
		//sa.alertOK_CANCEL();
		sa.alertInput();
		sa.tearDown();

	}

}
