package com.googledemo;

public class TestGoogle {

	public static void main(String[] args) throws InterruptedException {
		GoogleAuto ga = new GoogleAuto();
		
		ga.loadPage();
		ga.dispAnchorTags();
		//ga.getAll();
		//ga.search();
		ga.tearDown();
	} 

}
//open browser window, loaded web page,maximised windo,teardown