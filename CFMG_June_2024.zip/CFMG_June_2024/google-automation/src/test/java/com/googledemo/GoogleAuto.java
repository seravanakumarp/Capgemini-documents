package com.googledemo;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleAuto {
WebDriver driver;

public GoogleAuto()
{
	WebDriverManager.chromedriver().setup();//find version ,download, set,maintenance
	driver=new ChromeDriver();// opening the browser window
	
	
//	WebDriverManager.edgedriver().setup();//find version ,download, set,maintenance
//	driver=new EdgeDriver();
}

public void loadPage() {
	driver.manage().window().maximize();
	driver.get("https://www.google.com/");
}


public void search()
{
	WebElement element = driver.findElement(By.name("q"));
	element.sendKeys("Capgemini");
	element.submit();
}
 
public void getAll()
{
	System.out.println(driver.getTitle());
	
	String expTitle = "Google";
	String actTitle = driver.getTitle();
	if(expTitle.equals(actTitle))
	{
		System.out.println("On the Google page");
	}
	else
	{
		System.out.println("Incorrect webpage");
	}
	
	
	WebElement imag = driver.findElement(By.id("hplogo"));
	if(imag.isDisplayed())
	{
		System.out.println("On the Google page--image displayed");
	}
	else
	{
		System.out.println("Incorrect webpage");
	}
	
	System.out.println(driver.getCurrentUrl());
	System.out.println(driver.getPageSource());
}

public void dispAnchorTags()
{
	//Thread.sleep(3000);
	List<WebElement> elements = driver.findElements(By.tagName("a"));
	Iterator<WebElement> itr = elements.iterator();
	while(itr.hasNext())
	{
		WebElement temp = itr.next();
		System.out.println(temp.getText());
	}
}

public void tearDown() throws InterruptedException
{
	Thread.sleep(5000);
	driver.quit();
}
}
