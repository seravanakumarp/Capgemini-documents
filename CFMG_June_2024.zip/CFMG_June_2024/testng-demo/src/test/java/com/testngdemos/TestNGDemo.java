package com.testngdemos;

import org.testng.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class TestNGDemo {

	
//	@Test(dependsOnMethods ="agithubTest" ,    priority = 4)
//	public void googleTest()
//	{
//		System.out.println("Google Page");
//	}
	
	@Test(dependsOnGroups = "sanity" ,    priority = 4)
	public void googleTest()
	{
		System.out.println("Google Page");
	}
	
	
	//@Test(enabled = false,groups = "smoke")
	public void agithubTest()
	{
		System.out.println("aGitHub Page");
	} 
	
	
	@Test(priority = 2,groups="smoke")
	public void githubTest()
	{
		System.out.println("GitHub Page");
		
	}
	
	@Test(priority = 1,groups="sanity")
	public void yatraTest()
	{
		System.out.println("Yatra Page");
		Assert.assertTrue(false);
	}
	
}
