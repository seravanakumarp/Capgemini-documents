package com.testngdemos;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNGDataProvider {
	
	
	@Test(dataProvider = "unameDP")
	public void gitHubLogin(String uname)
	{
		System.out.println(uname);
	}
	
	// Dataprovide SD Object Array
	@DataProvider(name="unameDP")
	public Object[] uname_dataprovider()
	{
		Object[] data=new Object[3];
		data[0]="Raj";
		data[1]="Giri";
		data[2]="Hari";
		return data;
	}
	
	
	//=======================  Dataprovider with 2D Object Array
	// Github uname password
	//raj      raj@123
	//giri   giri@123
	//hari   hari@123
	
	@Test(dataProvider = "credDP")
	public void gitHubUnamePassword(String uname,String password)
	{
		System.out.println(uname+"   "+password);
	}
	
	
	
	@DataProvider(name="credDP")
	public Object[][] gitHubCredentialsDataProvider()
	{
		Object[][] obj=new Object[3][];
		//Object[][]obj={{"raj","raj@123"},{"giri","giri@123"},{"hari","hari@123"}};
		obj[0]=new Object[2];
		obj[1]=new Object[2];
		obj[2]=new Object[2];
		
		obj[0][0]="raj";
		obj[0][1]="raj123";
		
		obj[1][0]="giri";
		obj[1][1]="giri@123";
		
		obj[2][0]="hari";
		obj[2][1]="hari@123";
		return obj;
		
		
	}
	
	//====  Getting from Excel to Data provider
	@Test(dataProvider = "credExcelDP")
	public void gitHubUnamePasswordExcel(String uname,String password)
	{
		System.out.println(uname+"   "+password);
	}
	
	
	
	@DataProvider(name="credExcelDP")
	public Object[][] gitHubCredentialsDataProviderExcel() throws IOException
	{
		FileInputStream fis = new FileInputStream("src/test/resources/mycredentials.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheetAt(0);
		
		int rowCount=sheet.getPhysicalNumberOfRows();
		Object[][] data=new Object[rowCount][];
		
		for(int i=0;i<rowCount;i++)
		{
			XSSFRow row=sheet.getRow(i);
			int colCount=row.getPhysicalNumberOfCells();
			data[i]=new Object[colCount];
			
			for(int j=0;j<colCount;j++)
			{
				XSSFCell cell=row.getCell(j);
				String val=cell.getStringCellValue();
				
//				DataFormatter df=new DataFormatter();
//				String val=df.formatCellValue(cell);
				data[i][j]=val;
				
			}
		}
		return data;
		
	}
	
	

}
