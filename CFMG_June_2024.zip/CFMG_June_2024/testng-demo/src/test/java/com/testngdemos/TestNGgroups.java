package com.testngdemos;

import org.testng.annotations.Test;

public class TestNGgroups {
	
	@Test(groups="smoke")
	public void googleTest()
	{
		System.out.println("Google Test");
	}
	
	@Test(groups={"functionality","smoke"})
	public void gitTest()
	{
		System.out.println("Git Test");
	}
	
	@Test(groups = "sanity")
	public void yatraTest()
	{
		System.out.println("Yatra Test");
	}

	
	@Test(groups = {"functionality","sanity"})
	public void redBusTest()
	{
		System.out.println("RedBus Test");
	}
}
