package com.testngdemos;

import org.testng.annotations.Test;

public class TestInvocationCount {

	@Test(invocationCount = 5,invocationTimeOut = 1)
	public void googleTest()
	{
		System.out.println("Google Page");
	}
	
	@Test() 
	public void gitTest()
	{
		System.out.println("Google Page");
	}
	
}
