package com.testngdemos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNgparameters {
	WebDriver driver;
	
	@Test
	@Parameters(value={"url","browser"})
	public void googlePage(@Optional("https://github.com/") String urlVal,@Optional("chrome") String browserName)
	{
		switch(browserName.toLowerCase())
		{
		case "chrome":
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
			break;
		
		}
		driver.manage().window().maximize();
		driver.get(urlVal);
		System.out.println("Google Page loaded");
		
		try {
			Thread.sleep(3000);
			driver.quit();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
	

}
