package com.testngdemos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNGParallelDmo {
WebDriver driver;
	
@Test
	public void googleTest() throws InterruptedException
	{
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		System.out.println("Google Page loaded");
		
		Thread.sleep(3000);
		driver.quit();
	
	}

@Test
public void gitTest() throws InterruptedException
{
	WebDriverManager.edgedriver().setup();
	driver=new EdgeDriver();
	driver.manage().window().maximize();
	driver.get("https://github.com/");
	System.out.println("Git Page loaded");
	
	Thread.sleep(3000);
	driver.quit();

}
@Test
public void yatraTest() throws InterruptedException
{
	WebDriverManager.edgedriver().setup();
	driver=new EdgeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.yatra.com/");
	System.out.println("Yatra Page loaded");
	
	Thread.sleep(3000);
	driver.quit();

}
}
