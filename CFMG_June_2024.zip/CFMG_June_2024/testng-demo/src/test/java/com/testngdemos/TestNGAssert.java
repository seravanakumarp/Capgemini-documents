package com.testngdemos;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestNGAssert {
	@Test
public void mytests()
{
	System.out.println("Java1");
	//Assert.assertTrue(false,"Assert Demo Failed"); //Hard Assert
	SoftAssert soft=new SoftAssert(); //Soft Assert
	soft.assertTrue(false,"Soft Assert Failed");
	System.out.println("Java2");
	soft.assertAll();
	
	
}
	@Test
	public void mytests2()
	{
		System.out.println("Python");
		Assert.assertTrue(true,"Assert Demo Failed");
		
		
	}
}
