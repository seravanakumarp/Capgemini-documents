package com.searching;

import java.util.Arrays;

import com.sorting.SortingDemo;

public class SearchingDemo {
	private int[] a;
	private int n;
	
	public SearchingDemo(int[] a)
	{
		this.a=a;
		this.n=a.length;
	}
	
	public void display()
	{
		for(int i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println("\n");
	}
	//Time complexity -  O(n)
	public  int linearSearch(int searchElement)
	{
		for(int i=0;i<n;i++)
		{
			if(a[i]==searchElement)
				return i;
		}
		return -1;//-1 indicates element not found
	}
	
	//Time complexity -  O(logn)
	public  int binarySearch(int searchElement)
	{
		int beg=0;
		int end=n-1;
		
		while(beg<=end)
		{
			int mid=(beg+end)/2;
			if(a[mid]==searchElement)
			{
				return mid;
			}
			else if(searchElement>a[mid])
			{
				beg=mid+1;
			}
			else
			{
				end=mid-1;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		int[] a= {7,5,3,9,1,8};
		Arrays.sort(a);
		SearchingDemo sd = new SearchingDemo(a);
		sd.display();
		int searchElement=9;
		//int res=sd.linearSearch(searchElement);
		int res=sd.binarySearch(searchElement);
		if(res==-1)
		{
			System.out.println("Element not found");
		}
		else
		{
			System.out.println(searchElement+" Element found at index: "+(res));
		}
		

	}

}
