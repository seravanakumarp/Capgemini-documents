package com.recursion;

public class RecursionDemo {
	
	public static int factorial(int n) {
		if (n == 0)
			return 1;
		return n * factorial(n - 1);
	}
	
	public static boolean happyNumber(int n)
	{
		int sum = 0;
		while (n > 0) {
			int rem = n % 10;
			sum += rem * rem;
			n = n / 10;
		}
		if (sum == 1)
			return true;
		else if (sum > 9)
			return happyNumber(sum);
		return false;
	
	}

	public static void main(String[] args) {
		System.out.println(factorial(4));
		System.out.println(happyNumber(100));

	}

}
