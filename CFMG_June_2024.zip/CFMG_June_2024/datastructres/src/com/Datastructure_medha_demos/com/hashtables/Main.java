package com.hashtables;

public class Main {

	public static void main(String[] args) {
	HashTables ht = new HashTables();
	Employee giri = new Employee(100,"Giri","Kulkarni");
	Employee hari = new Employee(101,"hari","Joshi");
	Employee sam = new Employee(102,"Sam","Joseph");
	Employee joey = new Employee(103,"Joey","Sampson");
	Employee jog = new Employee(104,"Jyoti","Jog");
	Employee harita = new Employee(105,"harita","Joshi");
	Employee kavya = new Employee(106,"Kavya","Joshi");
	Employee kruti = new Employee(107,"Kruti","Jois");
	Employee radha = new Employee(108,"Radha","Jogut");
	Employee chinnu = new Employee(109,"Chinnu","Deshpande");
	Employee chotu = new Employee(110,"Chotu","Jeet");
	System.out.println("==============");
	
	ht.put("Kulkarni",giri);
	ht.put("Joshi",hari);
	ht.put("Joseph",sam);
	ht.put("Sampson",joey);
	ht.put("Jog", jog);
	ht.put("Joshis", kavya);
	ht.put("Jois", kruti);
	ht.put("Jogut", radha);
	ht.put("Joshisss", harita);
	ht.put("Deshpande", chinnu);
	ht.put("Jeet", chotu);
	ht.display();
	
	System.out.println("==============");
	System.out.println("Employee at \"Jog:\""+ht.get("Jog"));

	}

}
