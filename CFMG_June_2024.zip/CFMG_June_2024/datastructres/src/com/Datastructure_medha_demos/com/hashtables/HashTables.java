package com.hashtables;

public class HashTables {
private Employee[] hashTable;

public HashTables()
{
	hashTable=new Employee[10];
}

public int hashKey(String key)
{
	return (int)key.charAt(0)%10;
}

public boolean occupied(int intKey)
{
	return hashTable[intKey]!=null; //returns true if occupied
}

public void put(String key,Employee employee)
{
	int intKey=hashKey(key);
	System.out.println("intkey="+intKey);
	if(occupied(intKey))
	{
		int stopIndex=intKey;
		
		if(intKey==hashTable.length-1) //wrap the table
		{
			intKey=0;
		}
		else
		{
			intKey++;
		}
	
	
		while(occupied(intKey) && intKey !=stopIndex)
		{
			System.out.println("Stop index="+stopIndex);
			intKey++;
			if(intKey==hashTable.length-1) //wrap the table
			{
				intKey=0;
			}
			
		}
	
	}
	
	if(occupied(intKey))
	{
		System.out.println("Oh!This position is already occupied");
	}
	else
	{
		hashTable[intKey]=employee;
	}
}



public Employee get(String key)
{
	int intKey=hashKey(key);
	
	
	while(intKey<hashTable.length)
	{
		Employee e =hashTable[intKey];
		if(e.getLastName().equals(key))
		{
			return e;
		}
		else
			if(intKey==hashTable.length-1)
				intKey=0;
			else
				intKey++;
		
	}
	
	return null;
}

public void display()
{
	
	for(int i=0;i<hashTable.length;i++)
	{
		if(hashTable[i]!=null)
			System.out.println(i+"-----"+hashTable[i]+"---"+(int)(hashTable[i].getLastName().charAt(0)));
	}
}
}
