package com.search;

import java.util.Arrays;

public class BinarySearchAlgo {
private int[] arr = {9,4,2,7,5,4,6,5,3,2,1};

//O(logn)  Complexity    n/2^k
public BinarySearchAlgo()
{
	Arrays.sort(arr);
	
}
public int binarySearch(int searchEle,int beg,int last)
{
	while(beg < last)
	{
		int mid  = (beg+last)/2;
		if(searchEle == arr[mid])
			return mid;
		else
			if(searchEle < arr[mid])
			{
				last = mid-1;
				binarySearch(searchEle,beg,last);
			}
			else
			{
				beg = mid + 1;
				binarySearch(searchEle,beg,last);
			}
	}
	return -1;
}

public static void main(String[] args) {
	int serachEle = 40;
	BinarySearchAlgo bs = new BinarySearchAlgo();
	int res = bs.binarySearch(serachEle, 0,bs.arr.length-1);
	if(res == -1)
		System.out.println("Element NOT founsd");
	else
		System.out.println("Element found at index:"+res);
}
	
	
}
