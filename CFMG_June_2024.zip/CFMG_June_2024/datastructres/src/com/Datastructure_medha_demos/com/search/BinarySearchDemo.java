package com.search;

import java.util.Arrays;

public class BinarySearchDemo {
	int  a[];
	int sele;
	BinarySearchDemo(int[] a,int sele)
	{
		this.a=a;
		this.sele=sele;
		Arrays.sort(a);
	}

	public static int binarySearch(int []a,int beg,int last,int sele)
	{
		while(beg<last)
		{
			int mid = (beg+last)/2;
			if(a[mid]==sele)
			{
				return mid; //found the ele
			}
			else if(sele <a[mid])
			{
				last=mid-1;
				binarySearch(a,beg,last,sele);
			}
			else
			{
				beg=mid+1;
				binarySearch(a,beg,last,sele);
			}
		}
		return -1; //Not found
	

		
	}
	public static void main(String[] args) {
	  int a[] = {8,5,7,3,5,4,6,7,2,3,5,3,4};
	  Arrays.sort(a);
	  int sele = 7;
	  for(int i=0;i<a.length;i++)
	  {
		  System.out.print(a[i]+" ");
	  }
	  BinarySearchDemo bs = new BinarySearchDemo(a,sele);
			  
	 int res =  bs.binarySearch(a, 0,a.length-1,sele);
	 if(res==-1)
	 {
		 System.out.println("Element NOT found");
	 }
	 else
	 {
		 System.out.println("Element found at index:"+res);
	 }
	 }
		 
	

}
