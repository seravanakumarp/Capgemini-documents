package com.intlinklist;

public class Main {

	public static void main(String[] args) {
		MyLinkList mll = new MyLinkList();
		
		mll.addFront(10);
		mll.addFront(20);
		mll.addFront(30);
		mll.display();
		mll.addEnd(5);
		mll.display();
		mll.removeFront();
		mll.display();
		mll.removeEnd();
		mll.display();
		
	}

}
