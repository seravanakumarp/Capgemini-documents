package com.queue;

public class TestCircularQueue {

	public static void main(String[] args) {
		CircularQueue cq=new CircularQueue(4);
		try {
			cq.enQueue(10);
			cq.enQueue(20);
			cq.enQueue(30);
			cq.enQueue(40);
			cq.display();
			cq.deQueue();
			cq.display();

			cq.enQueue(50);
			System.out.println(cq.front+"  "+cq.rear);
			cq.display();
			cq.deQueue();
			cq.display();
			cq.deQueue();
			cq.display();
			cq.deQueue();
			cq.display();
			System.out.println(cq.front+"  "+cq.rear);
			//cq.deQueue();
			//cq.display();
			
			
		} catch (QueueOverflowException e) {
			System.out.println("queue full");
		} catch (EmptyQueueException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		}
	

}
