package com.intDoublylinklist;

public class MyDoublyLinkList {

private Node head;
private Node tail;

public MyDoublyLinkList() {
	this.head=null;
	this.tail=null;
}

public void addFront(int data)
{
	Node newNode=new Node(data);
	if(head==null)
	{
		head=newNode;
		tail=newNode;
	}
	else
	{
		newNode.setNext(head);
		head=newNode;
		
	}
}

public void removeFront()
{
	Node temp=head;
	head=head.getNext();
	head.setPrev(null);
	temp.setNext(null);
	
}


public void addRear(int data)
{
	Node newNode=new Node(data);
	if(head==null)
	{
		head=newNode;
		tail=newNode;
	}
	else
	{
		tail.setNext(newNode);
		newNode.setPrev(tail);
		tail=newNode;
	}
}

public void removeRear()
{

	Node last=tail;
	Node temp=tail.getPrev();
	temp.setNext(null);
	last.setPrev(null);
	tail=temp;
	
}
public void display()
{
	Node temp=head;
	System.out.print("head <==>");
	while(temp!=null)
	{
		System.out.print(temp.getData()+" <==> ");
		temp=temp.getNext();
	}
	System.out.print(" end\n");
}

}
