package com.lists;

import java.util.Objects;

public class Employee3 {
	private String firstName;
	private String lastName;
	private double Salary;
	
	public Employee3()
	{
		
	}

	@Override
	public int hashCode() {
		return Objects.hash(Salary, firstName, lastName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee3 other = (Employee3) obj;
		return Double.doubleToLongBits(Salary) == Double.doubleToLongBits(other.Salary)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName);
	}

	public Employee3(String firstName, String lastName, double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		Salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", Salary=" + Salary + "]";
	}
	
	


}
