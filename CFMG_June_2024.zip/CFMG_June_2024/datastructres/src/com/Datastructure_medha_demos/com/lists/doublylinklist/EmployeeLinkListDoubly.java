package com.lists.doublylinklist;

public class EmployeeLinkListDoubly {
private EmployeeNode head;
private EmployeeNode tail;

public void addToFront(Employee4 employee)
{
		EmployeeNode newnode = new EmployeeNode(employee);
		newnode.setNext(head);
		
		if(head == null) //If linklist empty-- set tail to the newnode
		{
			tail = newnode;
		}
		else
			head.setPrev(newnode);
		
		head = newnode;
	
}

public void addRear(Employee4 employee)
{
	EmployeeNode newnode = new EmployeeNode(employee);
	if(head == null)
	{
		head = newnode;
		tail = newnode;
	}
	else
	{
		tail.setNext(newnode);
		newnode.setPrev(tail);
		tail = newnode;
		
	}
}

public EmployeeNode removeFront() {
	if(head != null)
	{
		if(head.getNext() == null) //only node in the linklist
		{
			tail = null;
			head = null;
			System.out.println("Node removed");
		}
		else
		{
			EmployeeNode temp = head;
			head = head.getNext();
			head.setPrev(null);
			System.out.println("Node removed");
			temp.setNext(null);
			return temp;
		}
	}
	return null; 
}

public EmployeeNode removeRear() {
	if(head != null) //If linklist not empty
	{
		if(tail.getPrev() == null) //Only node in the linklist
		{
			head = null;
			tail = null;
			System.out.println("Node removed");
		}
		else
		{
			EmployeeNode temp = tail;
			tail = tail.getPrev();
			tail.setNext(null);
			temp.setPrev(null);
			System.out.println("Node removed");
			
			return temp;
		}
	}
	return null; 
}

public void display()
{
	EmployeeNode temp = head;
	System.out.println("Head<=>");
	while(temp != null)
	{
		System.out.println(temp.getEmployee());
		temp = temp.getNext();
	}
	System.out.println("<=> null");
}

}
