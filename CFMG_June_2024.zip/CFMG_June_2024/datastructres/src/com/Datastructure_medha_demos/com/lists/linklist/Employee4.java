package com.lists.linklist;

public class Employee4 {
	private String firstName;
	private String lastName;
	private double Salary;
	
	public Employee4()
	{
		
	}

	public Employee4(String firstName, String lastName, double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		Salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", Salary=" + Salary + "]";
	}
	
	
}
