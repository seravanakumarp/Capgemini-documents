package com.lists.linklist;

public class EmployeeNode {
private Employee4 employee;
private EmployeeNode next;  //self referential object

public EmployeeNode(Employee4 employee) {
	super();
	this.employee = employee;

}
@Override
public String toString() {
	return employee.toString();
}
public Employee4 getEmployee() {
	return employee;
}
public void setEmployee(Employee4 employee) {
	this.employee = employee;
}
public EmployeeNode getNext() {
	return next;
}
public void setNext(EmployeeNode next) {
	this.next = next;
}


}
