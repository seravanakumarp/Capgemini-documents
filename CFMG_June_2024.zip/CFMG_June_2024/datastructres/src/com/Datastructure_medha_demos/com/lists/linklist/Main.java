package com.lists.linklist;

import com.lists.Employee3;

public class Main {
public static void main(String[] args) {
//	Employee4 e1 = new Employee4("Raj","Sharma",5000);
//	Employee4 e2 = new Employee4("Ravi","Bose",6000);
//	Employee4 e3 = new Employee4("Ram","Patil",4000);
//	Employee4 e4 = new Employee4("Hari","Kulkarni",5000);
//	
//	EmployeeLinkListSingly ell = new EmployeeLinkListSingly();
//	ell.addToFront(e1);
//	ell.addToFront(e2);
//	ell.addToFront(e3);
//	ell.addToFront(e4);
//	ell.display();
//	ell.removeFront();
//	ell.display();
	
	String x[]=new String[3];
	x[0]="10";
	System.out.println(x.getClass());
	int xx[]=new int[3];
	xx[0]=10;
	System.out.println(xx.getClass());
}
}
