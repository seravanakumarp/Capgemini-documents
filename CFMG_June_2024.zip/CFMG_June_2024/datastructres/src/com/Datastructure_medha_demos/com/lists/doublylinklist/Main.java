package com.lists.doublylinklist;

import com.lists.Employee3;

public class Main {
public static void main(String[] args) {
	Employee4 e1 = new Employee4("Rajesh","Sharma",5000);
//	Employee4 e2 = new Employee4("Ravindra","Bose",6000);
//	Employee4 e3 = new Employee4("Ramesh","Patil",4000);
//	Employee4 e4 = new Employee4("Harish","Kulkarni",5000);
	
	EmployeeLinkListDoubly ell = new EmployeeLinkListDoubly();
	ell.addToFront(e1);
//	ell.addToFront(e2);
//	ell.addToFront(e3);
//	ell.addToFront(e4);
	ell.display();
//	Employee4 e5 = new Employee4("Kavish","Kulkarni",6000);
//	ell.addRear(e5);
	ell.display();
	ell.removeFront();
	ell.display();
	ell.removeRear();
	ell.display();
}
}
