package com.lists.linklist;

public class EmployeeLinkListSingly {
private EmployeeNode head;

public void addToFront(Employee4 employee)
{
	EmployeeNode newnode = new EmployeeNode(employee);
	newnode.setNext(head);
	head = newnode;
	
}

public EmployeeNode removeFront() {
	if(head != null)
	{
	EmployeeNode temp = head;
	head = head.getNext();
	System.out.println("Node removed");
	temp.setNext(null);
	return temp;
	}
	return null; 
}

public void display()
{
	EmployeeNode temp = head;
	System.out.println("Head ->");
	while(temp != null)
	{
		System.out.println(temp.getEmployee());
		temp = temp.getNext();
	}
	System.out.println("-> null");
}

}
