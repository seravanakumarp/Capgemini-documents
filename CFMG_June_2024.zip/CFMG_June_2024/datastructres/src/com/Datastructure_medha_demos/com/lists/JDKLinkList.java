package com.lists;

import java.util.Iterator;
import java.util.LinkedList;

import com.lists.doublylinklist.Employee4;

public class JDKLinkList {
public static void main(String[] args) {
	
	Employee4 e1 = new Employee4("Rajesh","Sharma",5000);
	Employee4 e2 = new Employee4("Ravindra","Bose",6000);
	Employee4 e3 = new Employee4("Ramesh","Patil",4000);
	Employee4 e4 = new Employee4("Harish","Kulkarni",5000);
	
	
	LinkedList<Employee4> ll = new LinkedList();
	ll.addFirst(e1);
	ll.addFirst(e2);
	ll.addLast(e3);
	Iterator<Employee4> itr = ll.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	
	
}
}
