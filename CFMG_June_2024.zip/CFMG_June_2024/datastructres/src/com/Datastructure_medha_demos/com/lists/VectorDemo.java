package com.lists;

import java.util.List;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		//ArrayList -- Not good for insertion in between
		List<Employee3> emp = new Vector<>();
		emp.add(new Employee3("Raj","Sharma",5000));
		emp.add(new Employee3("Ravi","Bose",5000));
		emp.add(new Employee3("Ram","Patil",5000));
		emp.add(new Employee3("Hari","Kulkarni",5000));
		emp.forEach(employee -> System.out.println(employee));
//		System.out.println(emp.get(1));
//		System.out.println(emp.isEmpty());
		emp.set(0, new Employee3("Hari","Kulkarni",5000));
		emp.forEach(employee -> System.out.println(employee));
		System.out.println(emp.size());
		
		//converting to array
		System.out.println("=====================");
		Employee3[] empArr = emp.toArray(new Employee3[emp.size()]);
		for(Employee3 e:empArr)
			System.out.println(e);
		
		//contains --override equals() and hashcode() in Employee3 class
		System.out.println(emp.contains(new Employee3("Hari","Kulkarni",5000)));
		System.out.println(emp.lastIndexOf(new Employee3("Hari","Kulkarni",5000)));
		System.out.println("*******************");
		emp.remove(0);
		emp.remove(new Employee3("Hari","Kulkarni",5000));
		emp.forEach(employee -> System.out.println(employee));
	}
}
