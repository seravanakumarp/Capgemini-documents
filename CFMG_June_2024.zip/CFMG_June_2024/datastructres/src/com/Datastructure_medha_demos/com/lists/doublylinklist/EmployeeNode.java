package com.lists.doublylinklist;

public class EmployeeNode {
private Employee4 employee;
private EmployeeNode next;  //self referential object
private EmployeeNode prev;


public EmployeeNode getPrev() {
	return prev;
}
public void setPrev(EmployeeNode prev) {
	this.prev = prev;
}
public EmployeeNode(Employee4 employee) {
	super();
	this.employee = employee;

}
@Override
public String toString() {
	return employee.toString();
}
public Employee4 getEmployee() {
	return employee;
}
public void setEmployee(Employee4 employee) {
	this.employee = employee;
}
public EmployeeNode getNext() {
	return next;
}
public void setNext(EmployeeNode next) {
	this.next = next;
}


}
