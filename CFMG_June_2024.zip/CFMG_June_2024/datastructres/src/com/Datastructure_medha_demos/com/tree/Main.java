package com.tree;

public class Main {

	public static void main(String[] args) {
	Tree tree = new Tree();
	tree.insert(10);
	tree.insert(5);
	tree.insert(15);
	tree.insert(8);
	tree.insert(12);
	tree.traverseInorder();
	System.out.println(tree.get(12).getData());
	System.out.println("Min:"+tree.min());
	System.out.println("Max:"+tree.max());
	
	System.out.println("=============================");
	//tree.delete(5);
	tree.traverseInorder();
	System.out.println("=============================");
	tree.traversePreorder();
	System.out.println("=============================");
	tree.traversePostorder();
	tree.delete(8);
	System.out.println("=============================");
	tree.traverseInorder();
	}

}
