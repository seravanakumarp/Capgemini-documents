package com.tree;

public class TreeNode {
private int data;
private TreeNode leftChild;
private TreeNode rightChild;

public TreeNode get(int value)
{
	if(value == this.data)
	{
		return this;
	}
	if(value < data)
	{
		if(leftChild != null)
		{
			return leftChild.get(value);
		}
	}
	else
	{
		if(rightChild != null)
		{
			return rightChild.get(value);
		}
	}
		
	return null;
}


public int min()
{
	if(leftChild == null)
		return data;
	else
		return leftChild.min();
}

public int max()
{
	if(rightChild == null)
		return data;
	else
		return rightChild.max();
}

public void traverseInnode()
{
	if(leftChild != null)
	{
		leftChild.traverseInnode();
	}
	System.out.println("Data="+data+",");
	if(rightChild != null)
	{
		rightChild.traverseInnode();
	}
}

public void traversePrenode()
{
	System.out.println("Data="+data+",");
	if(leftChild != null)
	{
		leftChild.traversePrenode();
	}
	
	if(rightChild != null)
	{
		rightChild.traversePrenode();
	}
}


public void traversePostnode()
{
	
	if(leftChild != null)
	{
		leftChild.traversePostnode();
	}
	
	if(rightChild != null)
	{
		rightChild.traversePostnode();
	}
	System.out.println("Data="+data+",");
}

public void insert(int value)
{
	if(value == this.data)
		return;
	if(value < data)
	{
		if(leftChild == null)
		{
			leftChild = new TreeNode(value); //place for insertion
		}
		else
			leftChild.insert(value);
	}
	else
	{
		if(rightChild == null)
		{
			rightChild = new TreeNode(value);//place for insertion
		}
		else
			rightChild.insert(value);
	}
}

public int getData() {
	return data;
}


public void setData(int data) {
	this.data = data;
}


public TreeNode getLeftChild() {
	return leftChild;
}


public void setLeftChild(TreeNode leftChild) {
	this.leftChild = leftChild;
}


public TreeNode getRightChild() {
	return rightChild;
}


public void setRightChild(TreeNode rightChild) {
	this.rightChild = rightChild;
}


public TreeNode(int data) {
	super();
	this.data = data;
}


@Override
public String toString() {
	return "TreeNode [data=" + data + ", leftChild=" + leftChild + ", rightChild=" + rightChild + "]";
}

//case3
public TreeNode delete(TreeNode subTreeRoot,int value)
{
	if(subTreeRoot == null)
	{
		return subTreeRoot;
	}
	if(value < subTreeRoot.getData())
	{
		subTreeRoot.setLeftChild(delete(subTreeRoot.getLeftChild(),value));
	}
	else
		if(value > subTreeRoot.getData()) {
			subTreeRoot.setRightChild(delete(subTreeRoot.getRightChild(),value));
		}
		else
		{
			if(subTreeRoot.getLeftChild() == null)
			{
				return subTreeRoot.getRightChild();
			}
			else
				if(subTreeRoot.getRightChild() == null)
				{
					return subTreeRoot.getLeftChild();
				}
		}
	return subTreeRoot;
}

}


