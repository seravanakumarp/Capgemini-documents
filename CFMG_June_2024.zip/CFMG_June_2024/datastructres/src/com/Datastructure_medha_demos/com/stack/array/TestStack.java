package com.stack.array;

public class TestStack {
public static void main(String[] args) {
	ArrayStack stack = new ArrayStack(3);
	System.out.println("Array size initial:"+stack.stack.length);
	stack.push(new Employee("Raj","Sharma",5000));
	stack.push(new Employee("Ravi","Verma",5000));
	stack.push(new Employee("Giri","Bose",5000));
//	stack.push(new Employee("Hari","Verma",5000));
//	stack.push(new Employee("John","Bose",5000));
	stack.display();
	System.out.println("Popped Employee:"+stack.pop());
	stack.display();
	System.out.println("Peek Employee:"+stack.peek());
	stack.display();
	stack.push(new Employee("Hari","Verma",5000));
	stack.display();
	stack.push(new Employee("John","Bose",5000));
	stack.display();
}
	
	
//	public static void main(String[] args) {
//		LinkedStack stack = new LinkedStack();
//		stack.push(new Employee("Raj","Sharma",5000));
//		stack.push(new Employee("Ravi","Verma",5000));
//		stack.push(new Employee("Giri","Bose",5000));
//		stack.push(new Employee("Hari","Verma",5000));
//		stack.push(new Employee("John","Bose",5000));
//		stack.display();
//		System.out.println("Popped Employee:"+stack.pop());
//		stack.display();
//		System.out.println("Peek Employee:"+stack.peek());
//		stack.display();
//		System.out.println("================");
//		stack.push(new Employee("Hari","Verma",5000));
//		stack.display();
////		stack.push(new Employee("John","Bose",5000));
////		stack.display();
//	}
}
