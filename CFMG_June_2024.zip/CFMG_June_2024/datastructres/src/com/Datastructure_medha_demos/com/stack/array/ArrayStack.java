package com.stack.array;

import java.util.EmptyStackException;

public class ArrayStack {
private int top;
public Employee[] stack;


public ArrayStack(int size) {
	stack = new Employee[size];
	top = -1;
}

//O(n)   -- becasue of resizing of array
public void push(Employee employee)
{
	if(top == stack.length-1)  //Array resized if full
	{
		Employee[] newArray = new Employee[2 * stack.length];
		System.arraycopy(stack,0, newArray, 0, stack.length);
		stack = newArray;
	}
	stack[++top] = employee;
}

//O(1)   always
public Employee pop()
{
	if(top==-1)
		throw new EmptyStackException();
	Employee employee = stack[top--];
	return employee;
	
	
}

//O(1)   always
public Employee peek()
{
	if(top==-1)
		throw new EmptyStackException();
	Employee employee = stack[top];
	return employee;
	
	
}

public void display()
{
	System.out.println(stack[top]+"<<=====Top");
	for(int i=top-1;i>=0;i--)
		System.out.println(stack[i]);
	
}



}
