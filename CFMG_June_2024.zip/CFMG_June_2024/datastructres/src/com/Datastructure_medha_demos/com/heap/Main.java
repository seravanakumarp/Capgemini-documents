package com.heap;

public class Main {

	public static void main(String[] args) {
		Heap h=new Heap(10);
		h.insert(8);
		h.insert(1);
		h.insert(6);
		h.insert(4);
		h.insert(5);
		h.insert(9);
		h.insert(3);
		h.display();
		h.delete(6);
		
		h.display();
		/*
		 * 9  5  8  1  4  6  3  
9  5  8  1  4  6 
		 * 
		 */

	}

	
	//21+1 left      2i-1  right    (i-1)/2
}
