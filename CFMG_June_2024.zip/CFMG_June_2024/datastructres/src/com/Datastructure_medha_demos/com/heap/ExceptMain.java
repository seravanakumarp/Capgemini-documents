package com.heap;

import java.io.FileNotFoundException;

public class ExceptMain {

	
	public void meth1() throws Exception
	{
		System.out.println("File not found exception");
	}
	
	public void meth2() throws Throwable//FileNotFoundException
	{
		meth1();
		System.out.println("Exception");
	}
	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		new ExceptMain().meth2();
	}

}
