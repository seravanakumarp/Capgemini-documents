package com.tree2;

public class Main {

	public static void main(String[] args) {
	Tree tree=new Tree();
	tree.insert(5);
	tree.insert(8);
	tree.insert(7);
	tree.insert(4);
	tree.insert(9);
	tree.insert(12);
	tree.insert(11);
	tree.insert(10);
	tree.insert(3);
	tree.traverseInOrder();
	System.out.println(); 
	tree.traversePreOrder();
	System.out.println();
	tree.traversePostOrder();
	
	System.out.println();
	System.out.println("Min="+tree.min());
	System.out.println("Max="+tree.max());
	TreeNode tn = tree.get(12);
	if(tn!=null)
	{
		System.out.println("Get="+tn.getData());
	}
	
	
	tree.traverseInOrder();
	tree.delete(11);
	tree.delete(3);
	
	System.out.println();
	tree.traverseInOrder();
	}
}
