package com.tree2;

public class TreeNode {
int data;
TreeNode leftChild;
TreeNode rightChild;

public TreeNode(int data)
{
	this.data=data;
	leftChild=null;
	rightChild=null;
}

public void insert(int value)
{
	if(this.data==value) //duplicate
		return;
	else
		if(value<this.data)
		{
			if(leftChild==null) //found place for insertion
			{
				leftChild=new TreeNode(value);
			}
			else
			{
				leftChild.insert(value);
			}
		}
		else
		{
			if(rightChild==null)
			{
				rightChild=new TreeNode(value);//found place for insertion
			}
			else
			{
				rightChild.insert(value);
			}
		}
}


public TreeNode get(int value)
{
	if(this.data==value)
		return this;
	else
	{
		if(value<this.data) {
			if(leftChild!=null)
			{
				return leftChild.get(value);
			}
		}
		else
		{
			if(rightChild!=null)
			{
				return rightChild.get(value);
			}
		}
	}
	return null;
}

public void traverseInNode()
{
	if(leftChild!=null)
	{
		leftChild.traverseInNode();
	}
	System.out.print(" "+this.data+" ");
	
	if(rightChild!=null)
	{
		rightChild.traverseInNode();
	}
}


public void traversePreNode()
{
	System.out.print(" "+this.data+" ");
	if(leftChild!=null)
	{
		leftChild.traversePreNode();
	}
	
	if(rightChild!=null)
	{
		rightChild.traversePreNode();
	}
}

public void traversePostNode()
{
	
	if(leftChild!=null)
	{
		leftChild.traversePostNode();
	}
	
	if(rightChild!=null)
	{
		rightChild.traversePostNode();
	}
	System.out.print(" "+this.data+" ");
}


public int min()
{
	if(leftChild==null)
	{
		return data;
	}
	else
	{ 
		return leftChild.min();
	}
}

public int max()
{
	if(rightChild==null)
	{
		return data;
	}
	else
	{
		return rightChild.max();
	}
}

public int getData() {
	return data;
}

public void setData(int data) {
	this.data = data;
}

public TreeNode getLeftChild() {
	return leftChild;
}

public void setLeftChild(TreeNode leftChild) {
	this.leftChild = leftChild;
}

public TreeNode getRightChild() {
	return rightChild;
}

public void setRightChild(TreeNode rightChild) {
	this.rightChild = rightChild;
}


}
