package com.arrays;

public class SortTest {
	public static long fact(int n)
	{
		if(n==1)
		{
			return 1;
		}
		return n*fact(n-1);
	}
public static void main(String[] args) {
	int n= 8;
	int[] arr= new int[n];
	arr[0] = 20;
	arr[1] = 35;
	arr[2] = -15;
	arr[3] = 7;
	arr[4] =55;
	arr[5] = 1;
	arr[6] = 22;
	arr[7]=8;
//	int ind = -1;
//	int [] arr= {8,5,3,7,2,4,1};
	//int[] arr= {6,1,2};
	System.out.print("\nArray Before Sort: ");
	for(int i=0;i<arr.length;i++)
	{
		System.out.print(arr[i]+" ");
	}
	SortDemo bs = new SortDemo();
	//bs.bubbleSort(arr,n );
	//bs.selectionSort(arr, n);
	//bs.insertionSort(arr, n);
	//bs.shellSort(arr, n);
	//bs.quickSort(arr, 0, n-1);	
	bs.mergesort(arr, 0, arr.length-1);
	//bs.shellsorting(arr);
	
	System.out.print("\nArray After Sort: ");
	for(int i=0;i<arr.length;i++)
	{
		System.out.print(arr[i]+" ");
	}
	
	//System.out.println("\n\nfact="+fact(5));
}
}
// 4  K  6  7    3  2

// 4  2  6  7  3  K
