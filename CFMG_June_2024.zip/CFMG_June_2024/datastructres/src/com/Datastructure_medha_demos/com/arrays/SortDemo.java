package com.arrays;

public class SortDemo {
public void bubbleSort(int[] a,int n)
{
	//ascending
	//O(n2)   nsquare
	for(int i=0;i<n-1;i++) //iteartions
	{
		for(int j=0;j<n-i-1;j++) //comparisions
		{
			if(a[j] > a[j+1])  //stable algorithm
			{
				int temp = a[j];
				a[j] = a[j+1];
				a[j+1]=temp;
			}
		}
		System.out.print("\nIteration "+i+": ");
		for(int k=0;k<n;k++)
			System.out.print(a[k]+" ");
	}
}


public void selectionSort(int[]a ,int n)
{
	//ascending
	//O(n2)   nsquare
	for(int i=0;i<n-1;i++)
	{
		int min = a[i];
		int ind = i;
		for(int j=i+1;j<n;j++)
		{
			if(a[j] < min)
			{
				min = a[j];
				ind = j;
			}
		}
		int temp = a[ind];
		a[ind] = a[i];
		a[i] = temp;
		System.out.print("\nIteration "+i+": ");
		for(int k=0;k<n;k++)
			System.out.print(a[k]+" ");
	}
}


public void insertionSort(int[] a,int n)
{
	//ascending
	//O(n2)   nsquare
	for(int i=1;i<n;i++)
	{
		int j = i-1;
		int min = a[i];
		
		while(j >= 0 && min < a[j])
		{
			a[j+1] = a[j];
			j--;
		}
		j++;
		a[j] = min;
	
		System.out.print("\nIteration "+i+": ");
		for(int k=0;k<n;k++)
			System.out.print(a[k]+" ");
		System.out.println("\n==========================");
	}
	
}


//	public void shellSort(int array[], int n) 
//	{
//		  for (int interval = n / 2; interval > 0; interval /= 2) 
//		  {
//		    for (int i = interval; i < n; i += 1) 
//		    {
//			    int temp = array[i];
//			    int j;
//			    for (j = i; j >= interval && array[j - interval] > temp; j -= interval)
//			    {
//			      array[j] = array[j - interval];
//			    }
//			    array[j] = temp;
//		    }
//		  }
//	}
	
	
	// Java implementation of ShellSort 
	
	  
	    /* function to sort arr using shellSort */
	    int shellsorting(int arr[]) 
	    { 
	        int n = arr.length; 
	  
	        // Start with a big gap, then reduce the gap 
	        for (int gap = n/2; gap > 0; gap /= 2) 
	        { 
	            // Do a gapped insertion sort for this gap size. 
	            // The first gap elements a[0..gap-1] are already 
	            // in gapped order keep adding one more element 
	            // until the entire array is gap sorted 
	            for (int i = gap; i < n; i += 1) 
	            { 
	                // add a[i] to the elements that have been gap 
	                // sorted save a[i] in temp and make a hole at 
	                // position i 
	                int min = arr[i]; 
	  
	                // shift earlier gap-sorted elements up until 
	                // the correct location for a[i] is found 
	                int j; 
	                j=i; ///******************** j=i-gap
	                while(j >= gap &&  min<arr[j-gap] )
	                {
	                   arr[j]=arr[j-gap];
	                    j -= gap;
	                }
	  
	                // put min (the original a[i]) in its correct 
	                // location 
	        
	                arr[j] = min; 
	            } 
	        } 
	        return 0; 
	    } 
	    
	    
	    
	    
	    
	//quicksort
	//in-place algo
	//Onlogn
	
	int partition(int arr[],int low,int high)
	{
	  //choose the pivot
	   
	  int pivot=arr[high];
	  //Index of smaller element and Indicate
	  //the right position of pivot found so far
	  int i=(low-1);
	   
	  for(int j=low;j<=high;j++)
	  {
	    //If current element is smaller than the pivot
	    if(arr[j]<pivot)
	    {
	      //Increment index of smaller element
	      i++;
	      int temp =arr[i];
	      arr[i] = arr[j];
	      arr[j] = temp;
	    }
	  }

	  int temp =arr[i+1];
      arr[i+1] = arr[high];
      arr[high] = temp;
	  return (i+1); //index of the pivot 's resting index
	}
	 
	

	// The Quicksort function Implement
	            
	void quickSort(int arr[],int low,int high)
	{
	  // when low is less than high
	  if(low<high)
	  {
	    // pi is the partition() return index of pivot
	     
	    int pi=partition(arr,low,high);
	     
	    //Recursion Call
	    //smaller element than pivot goes left and
	    //higher element goes right
	    quickSort(arr,low,pi-1);
	    quickSort(arr,pi+1,high);
	  }
	}
	
	
	// Merge sort concepts starts here
	//divide-and-conquer strategy.
	//splitting
	
//O(Nlog(N))
	//Not in-place: Uses temp memory
	//large datasets
	void mergesort(int a[], int low, int high)
	{
	    int mid;
	    if (low < high)  //base case --  when one ele in array stops
	    {
	       // mid=low+(high-low)/2;
	    	mid=(high+low)/2;
	        mergesort(a,low,mid);
	        mergesort(a,mid+1,high);
	        merge(a,low,high,mid);
	    }
	    return;
	}
	
	void merge(int []a, int low, int high, int mid)
	{
	    int i, j, k;
	   
	    // Find sizes of two subarrays to be merged
        int n1 = mid - low + 1;
        int n2 = high - mid;
	    
	    // Create temp arrays
        int L[] = new int[n1];
        int R[] = new int[n2];
 
        // Copy data to temp arrays
        for ( i = 0; i < n1; ++i)
            L[i] = a[low + i];
        
        for ( j = 0; j < n2; ++j)
            R[j] = a[mid + 1 + j];
        
	    i = 0;
	    k = low;//0
	    j = 0;
	   
	    while (i <n1 && j <n2)//stop cond
	    {
	        if (L[i] < R[j])
	        {
	            a[k] = L[i];
	            k++;
	            i++;
	        }
	        else
	        {
	            a[k] = R[j];
	            k++;
	            j++;
	        }
	    }
	    while (i <n1)
	    {
	        a[k] = L[i];
	        k++;
	        i++;
	    }
	    while (j <n2)
	    {
	        a[k] = R[j];
	        k++;
	        j++;
	    }
    
	    }
	
	
	
	
}
