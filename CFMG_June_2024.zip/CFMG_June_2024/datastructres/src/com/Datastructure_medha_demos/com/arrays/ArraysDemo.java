package com.arrays;


public class ArraysDemo {
	public static void main(String[] args) {
		int[] arr= new int[7];
		arr[0] = 20;
		arr[1] = 35;
		arr[2] = -15;
		arr[3] = 7;
		arr[4] =55;
		arr[5] = 1;
		arr[6] = 22;
		int ind = -1;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i] == 7)
			{
				ind = i;
				break;
			}
			
		}
		System.out.println(ind+"   "+arr[ind]);
		
		//O(1)====  if you are searching the element with known index--constant time
		//O(n)====  if you are searching the element with UNKNOWN index --Linear Time
	}
}
