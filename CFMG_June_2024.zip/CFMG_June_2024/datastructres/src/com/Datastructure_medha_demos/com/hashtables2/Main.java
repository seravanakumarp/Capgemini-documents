package com.hashtables2;



public class Main {
	public static void main(String[] args) {
		
HashTables ht = new HashTables();

Employee e1=new Employee(100,"Sam","Sharma"); // 83---3
Employee e2=new Employee(101,"Sari","Kulkarni"); //83--4
Employee e3=new Employee(102,"Siri","Joshi");//83--5
Employee e4=new Employee(103,"Harini","Kamat");
Employee e5=new Employee(105,"Himani","Kamat");

Employee kavya = new Employee(106,"Kavya","Joshis");
Employee kruti = new Employee(107,"Kruti","Jois");
Employee radha = new Employee(108,"Radha","Jogut");
Employee chinnu = new Employee(109,"Chinnu","Deshpande");
Employee chotu = new Employee(110,"Chotu","Jeet");
ht.put("Sam", e1);
ht.put("Hari", e2);
ht.put("Giri", e3);
ht.put("Harini", e4);
ht.put("Himani", e5);
ht.put("Joshis", kavya);
ht.put("Jois", kruti);
ht.put("Jogut", radha);
ht.put("Deshpande", chinnu);
ht.put("Jeet", chotu);
ht.display();
System.out.println("Employee at \"Siri\":"+ht.get("Siri"));

	}

}
