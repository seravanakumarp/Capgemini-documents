package com.hashtables2;

public class HashTables {
private Employee[] hashTable;

public HashTables()
{
	hashTable=new Employee[10];
}

public int getHashKey(String key)  //raw key
{
	return ((int)key.charAt(0))%10; //First letter ASCII val%10 Ex:A---65%10=5
}

public boolean occupied(int hashKey)
{
	return hashTable[hashKey]!=null; //if occupied return true
}
//Linear probing
public void put(String key,Employee val)
{
	int hashKey= getHashKey(key);
	if(occupied(hashKey))
	{
		int stopIndex=hashKey;
		//
		if(hashKey==hashTable.length-1)
		{
			hashKey=0;
		}
		else
		{
			hashKey++;
		}
		
		while(occupied(hashKey) && hashKey != stopIndex  )
		{
			hashKey++;
			if(hashKey==hashTable.length-1)
			{
				hashKey=0;
			}
			
		}
	}
	if(occupied(hashKey))
	{
	System.out.println("Oops! This position is already occupied!");
	}
	else 
	{
	System.out.println("haskKey="+hashKey);
	hashTable[hashKey]=val;
	}
}

public Employee get(String key)
{
	int hashKey= getHashKey(key);  //3
	
	int stopIndex=hashKey;
	
	while(hashKey < hashTable.length )
	{	
		Employee e=hashTable[hashKey];
		if(e!=null)
		{
			if(e.getFirstName().equals(key))
			{
				return e;
			}
		}
		if(hashKey==hashTable.length-1)//wrap up
		{
			hashKey=0;
		}
		else
		{
			hashKey++;
			if(hashKey==stopIndex)
				return null;
		}
	}
	
	return null;
}


public void display()
{
	for(int i=0;i<hashTable.length;i++)
	{
		if(hashTable[i]!=null)
			System.out.println(i+" "+hashTable[i]+"....."+"---"+(int)(hashTable[i].getFirstName().charAt(0)));
	}
}
}





//public void put(String key,Employee val)
//{
//	int hashKey= getHashKey(key);
//	System.out.println("haskKey="+hashKey);
//	hashTable[hashKey]=val;
//}
//
//public Employee get(String key)
//{
//	int hashKey= getHashKey(key);
//	return hashTable[hashKey];
//}
