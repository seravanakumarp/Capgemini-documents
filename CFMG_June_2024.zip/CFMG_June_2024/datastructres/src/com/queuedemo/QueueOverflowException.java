package com.queuedemo;

public class QueueOverflowException extends Exception {

public QueueOverflowException()
{
	super();
}

public QueueOverflowException(String msg)
{
	super(msg);
}
}