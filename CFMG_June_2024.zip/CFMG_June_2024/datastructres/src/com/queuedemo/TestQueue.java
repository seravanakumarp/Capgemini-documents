package com.queuedemo;

public class TestQueue {

	public static void main(String[] args) {
		QueueDemo qd = new QueueDemo(3);
		try {
			qd.enQueue(10);
			qd.enQueue(20);
			qd.enQueue(30);
			qd.display();
			System.out.println("ele removed:"+qd.deQueue());
			System.out.println("ele removed:"+qd.deQueue());
		//	System.out.println("ele removed:"+qd.deQueue());
			System.out.println("ele view:"+qd.peek());
		} catch (QueueOverflowException e) {
			System.out.println(e.getMessage());
		} catch (QueueUnderflowException e) {
			System.out.println(e.getMessage());		}
		

	}

}
