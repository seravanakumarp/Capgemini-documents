package com.queuedemo;




public class QueueUnderflowException extends Exception {

public QueueUnderflowException()
{
	super();
}

public QueueUnderflowException(String msg)
{
	super(msg);
}
}