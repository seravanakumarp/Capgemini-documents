package com.sorting;


//Sorting
/*
 Bubble sort
 selection
 insertion
 quick
 merge
 shell
 heap
 bucket........
 */

/* linear search
 * binary search
 */
public class SortingDemo {
	private int[] a;
	private int n;
	
	public SortingDemo(int[] a)
	{
		this.a=a;
		this.n=a.length;
	}
	
	public void display()
	{
		for(int i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println("\n");
	}
	//Ascending
	//Time complexity-- 
	//(n-1) * (n-1-i)
	//n * n
	//O(n^2) -worstcase
	public void bubblesort()
	{
		for(int i=0;i<n-1;i++)// number of passes=  n-1
		{
			for(int j=0;j<n-1-i;j++) //number of comparisions
			{
				if(a[j]>a[j+1]) //comparision 
				{
					int temp;
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
			System.out.print("Pass:"+(i+1)+": ");
			display();
			
		}
	}
	
	
	//Ascending
	//Time complexity
	//n-1 * n-i)
	//n * n
	//O(n^2)
	public void selectionSort()
	{
		for(int i=0;i<n-1;i++)//passess
		{
			int min=a[i];//assumed min
			int pos=i;
			for(int j=i+1;j<n;j++) //finding the min in the remaining array
			{
				if(a[j]<min)
				{
					min=a[j];
					pos=j;
				}
			}
			//swap new min with ith ele
			int temp=a[i];
			a[i]=a[pos];
			a[pos]=temp;
			System.out.print("Pass:"+(i+1)+": ");
			display();
		}
	}
	
	//Ascenending
	//Time complexity
	//n-1 * i -->(n-1)
	//n * (n-1)
	//O(n^2)
	public void insertionSort()
	{
		for(int i=1;i<n;i++)
		{
			int j=i-1;
			int min=a[i];
			while(j>=0 && a[j] > min) //stopping condition for comparing and moving down
			{
				a[j+1]=a[j]; //moving down
				j--;
			}
			j++;
			a[j]=min;
			System.out.print("Pass:"+(i+1)+": ");
			display();
		}
	}
	
	public static void main(String[] args) {
	
		int[] a= {7,5,3,9,1,8};
		SortingDemo sd = new SortingDemo(a);
		System.out.println("Before sorting:");
		sd.display();
		//sd.bubblesort();
		//sd.selectionSort();
		sd.insertionSort();
		System.out.println("After sorting:");
		sd.display();
	}

}
