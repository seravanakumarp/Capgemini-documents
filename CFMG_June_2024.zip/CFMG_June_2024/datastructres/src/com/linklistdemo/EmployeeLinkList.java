package com.linklistdemo;

public class EmployeeLinkList {

	Employee head;
	
	public EmployeeLinkList() //initially empty  LL- so head=null
	{
		head=null;
	}
	
	public void insertFront(Employee newNode)
	{
		if(head==null) //LL empty
		{
			head=newNode;
		}
		else
		{
			newNode.setNext(head);
			head=newNode; 
			
		}
	}
	
	public void insertLast(Employee newNode)
	{
		Employee last=head;
		while(last.getNext()!=null)
		{
			last=last.getNext();
		}
		last.setNext(newNode);
		
	}
	
	public void insertInbetween(Employee newNode,int id)
	{ 
		Employee temp=head;
		while(temp.getId()!=id)
		{
			temp=temp.getNext();
			
		}
		Employee nextnode=temp.getNext();
		newNode.setNext(nextnode);
		temp.setNext(newNode);
	
	}
	public void removeFirst()
	{
		Employee temp;
		temp=head;
		head=head.getNext();
		temp.setNext(null);
	}
	
	
	public void removeLast()
	{
		Employee last;
		last=head;
		while(last.getNext().getNext()!=null)
		{
			last=last.getNext();
		}
		last.setNext(null);
	}
	
	public void display()
	{
		Employee temp=head;
		System.out.print("start->");
		while(temp!=null)
		{
			System.out.print(temp+ " -> ");
			temp=temp.getNext();
		}
		System.out.print(" ->end\n");
	}
}
