package com.maxheap;

public class TestHeap {

	public static void main(String[] args) {
		HeapDemo hd = new HeapDemo(10);
		hd.insert(9);
		hd.insert(11);
		hd.insert(13);
		hd.insert(3);
		hd.insert(8);
		hd.insert(5);
		hd.insert(17);
		hd.insert(12);
		hd.insert(18);
		hd.insert(6);
		hd.display();

	}

}
