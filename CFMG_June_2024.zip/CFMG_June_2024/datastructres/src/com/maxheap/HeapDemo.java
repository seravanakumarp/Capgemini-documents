package com.maxheap;
//heap implementation as an array
public class HeapDemo {
private int[] heap;
private int size; //actual number of ele in heap

public HeapDemo(int capacity)
{
	this.heap=new int[capacity]; //created an heap(array)
	this.size=0;
}

public boolean isFull()
{
	return heap.length==size;
}

public int getParentIndex(int index)
{
	return (index-1)/2; //int div
}

public void insert(int newValue)
{
	if(isFull())
	{
		throw new ArrayIndexOutOfBoundsException("Heap is full!");
	}
	heap[size]=newValue; //binary tree-- needs heapify process
	heapify(size);
	size++;
}

public void heapify(int size) //max heap- parent should be more than child ele
{
	int newValue = heap[size]; //value of the newly inserted ele
	int index=size;
	while(index>0 && newValue > heap[getParentIndex(index)])
	{
		heap[index]=heap[getParentIndex(index)];
		index=getParentIndex(index);
	}
	heap[index]=newValue;
}

public void display()
{
	for(int i=0;i<size;i++)
	{
		System.out.print(heap[i]+" ");
	}
}

}
