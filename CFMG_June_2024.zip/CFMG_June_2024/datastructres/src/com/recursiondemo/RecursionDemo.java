package com.recursiondemo;

public class RecursionDemo {
	//fib series upto n
	public void fib(int first,int second,int n)
	{
		int third=first+second;
		if(third<n)
		{
			System.out.print(" "+third);
			first=second;
			second=third;
			fib(first,second,n);
		}
		
	}
	
	
	public int sumDig(int n)
	{
		if(n==0)
			return 0;
		return (n%10)+sumDig(n/10);
	}

	public static void main(String[] args) {
		RecursionDemo rd = new RecursionDemo();
		//System.out.println("sum="+rd.sumDig(1234));
		int first=0,second=1;
		System.out.print(first+" "+second);
		rd.fib(first,second,20);
	}

}
