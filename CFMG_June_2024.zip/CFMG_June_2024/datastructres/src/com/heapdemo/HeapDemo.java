package com.heapdemo;

public class HeapDemo {
private int[] heap;
private int size;

public HeapDemo(int capacity)
{
	heap=new int[capacity];
	size=0;
}

public void insert(int newVal)
{
	if(isFull())
	{
		throw new ArrayIndexOutOfBoundsException("Heap is full!");
	}
	heap[size]=newVal; //added new element at the end of the heap
	fixHeapAboveSize(size); //Heapify-- converting a binary tree to heap
	size++;
	
}

public boolean isFull()
{
	return size==heap.length;
}

public int getParent(int index)
{
	return (index-1)/2;
}

public void fixHeapAboveSize(int size)
{
	int newVal = heap[size];
	int index=size;
	while(index > 0 && newVal > heap[getParent(index)])
	{
		heap[index]=heap[getParent(index)];
		index=getParent(index);
	}
	heap[index]=newVal;
}

public void display()
{
	for(int i=0;i<size;i++)
	{
		System.out.print(heap[i]+"  ");
	}
}

}
