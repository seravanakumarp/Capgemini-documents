package com.stackdemo;
//Array impl of stack
public class StackDemo {
	private int[] stack;
	private int top;
	private int size;
	
	public StackDemo(int size)
	{
		this.size=size;
		this.stack=new int[size];
		this.top=-1;
	}
	
	public void push(int ele) throws StackOverflowException 
	{
		
		//stack is full ?
		if(top==size-1)
			{
				throw new StackOverflowException("Stack is full!");
			}
			top++;
			stack[top]=ele; //pushed an ele
	}
	
	public void pushDynamicGrow(int ele) 
	{
		
		//stack is full -- Dynamically increase the size
		//1.Create new stack with more size
		//2.copy old to new stack
		//3renmae old as newstack
		//4.update this.size
		if(top==size-1)
			{
				int[] newStack=new int[this.size*2];
				this.size=this.size*2;
				System.arraycopy(stack, 0, newStack, 0, stack.length);
				stack=newStack;
			}
			top++;
			stack[top]=ele; //pushed an ele
	}
	
	
	public int pop() throws StackUnderflowException
	{
		if(top==-1) //stack is empty
		{
			throw new StackUnderflowException("Stack is empty");
		}
		int ele=stack[top];
		top--;
		return ele;
	}
	
	
	public int peek() throws StackUnderflowException
	{
		if(top==-1) //stack is empty
		{
			throw new StackUnderflowException("Stack is empty");
		}
		int ele=stack[top];
		return ele;
	}
	
	
	public void display() throws StackUnderflowException
	{
		if(top==-1) //stack is empty
		{
			throw new StackUnderflowException("Stack is empty");
		}
		System.out.println(stack[top]+"<----- Top");
		for(int i=top-1;i>=0;i--)
		{
		System.out.println(stack[i]);
		}
		System.out.println("=====================");
	}
}


