package com.calcitest;

import static org.junit.Assert.fail;

import java.time.Month;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.calculator.Calci;

public class CalciTest {
	@BeforeAll
	public static void init()
	{
		System.out.println("Before All");
	}
	@BeforeEach
	public  void initEach()
	{
		System.out.println("Before Each");
	}
	
	@Test
	@DisplayName("add_two_integers")
	public void add_two_positive_Integers_to_get_positive_sum()
	{
		Calci calci=new Calci(3,4);
		int actual=calci.add();
		int expected=7;
		Assertions.assertEquals(expected, actual,"Expected answer not matching woth actual answer");
	}
	 
	@Test
	public void given_two_negativeIntegers_when_add_then_returs_negative_sum()
	{
		Calci calci=new Calci(-3,-4);
		int actual=calci.add();
		int expected=-7;
		Assertions.assertEquals(expected, actual);
	}
	@Test
	public void given_two_Integers_when_add_then_returs_quotient()
	{
		Calci calci=new Calci(5,2);
		int actual=calci.div();
		int expected=2;
		Assertions.assertEquals(expected, actual);
	}
	@Test
	public void given_second_operand_is_zerod_then_throws_exception()
	{
		Calci calci=new Calci(5,0);
		Assertions.assertThrows(ArithmeticException.class, ()->calci.div());
	}
	
	@Test
	public void is_even_for_even_operand_returns_true()
	{
		Calci calci=new Calci(4,3);
		boolean actual=calci.isEven(); 
		boolean expected=true;
		Assertions.assertTrue(actual);
		//Assertion.assertFalse();
	}

	@Test
	public void aborted_test_case()
	{
	fail("This is failed testcase");
	}
	
	@AfterAll
	public static void tearDown()
	{
		System.out.println("After All");
	}
	
	@AfterEach
	public  void teardownEach()
	{
		System.out.println("After Each");
	}
	
	@ParameterizedTest
	 @EnumSource(value=Month.class, names = {"APRIL", "JUNE", "SEPTEMBER", "NOVEMBER"}) // passing 4 specific months
	 void getValueForSpecificMonth_IsAlwaysBetweenOneAndTwelve(Month month) {
	     int monthNumber = month.getValue();
	     assertTrue(monthNumber >= 1 && monthNumber <= 12,"Asserion failed");
	 }
}
