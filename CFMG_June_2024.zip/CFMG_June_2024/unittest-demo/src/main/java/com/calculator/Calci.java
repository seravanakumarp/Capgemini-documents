package com.calculator;

public class Calci {
private int a;
private int b;
public Calci(int a,int b)
{
	this.a=a;
	this.b=b;
}

public int add()
{
	return a+b;
}

public int sub()
{
	return a-b;
}
public int mult()
{
	return a*b;
}
public int div()
{
	return a/b;
}

public boolean isOdd()
{
	return a%2==1;
}
public boolean isEven()
{
	return a%2==0;
}
}
