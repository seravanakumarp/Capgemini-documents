package com.cg;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.Load driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		//2.Establish connection
		Connection con=DriverManager.getConnection(url, "system", "system");
		String qry="SELECT employee_id,last_name FROM hr.employees where employee_id>180";
		//3.Statement object
		Statement st = con.createStatement();
		//4. Execute query and get the ResultSet
		ResultSet rs = st.executeQuery(qry);
		//5. Processing resultset
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"   "+rs.getString(2));
		}
		
		//6.closing conn
		if(con!=null)
		{
			con.close();
		}
	}

}
