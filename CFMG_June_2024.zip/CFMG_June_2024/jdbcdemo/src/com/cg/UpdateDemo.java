package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateDemo {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	//2.Establish connection
	Connection con=DriverManager.getConnection(url, "system", "system");


	
	String qry = "UPDATE books SET bprice=999.99 WHERE bid=?";
	PreparedStatement st = con.prepareStatement(qry);
	st.setInt(1, 11);

	int res = st.executeUpdate();
	System.out.println("Rows updated="+res);
	
	
	qry = "SELECT * FROM books";
	st=con.prepareStatement(qry);
	ResultSet rs = st.executeQuery();
	
	while(rs.next()) {
		System.out.println(rs.getObject(1)+" "+rs.getObject(2)+" "+rs.getObject(3));
	}
	
	con.close();
}
}
