package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class StaticDemo {

	static String url;
	static String uname;
	static String pwd;
	static Connection con;
	static
	{
		url="jdbc:oracle:thin:@localhost:1521:XE";
		uname="system";
		pwd = "system";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url, uname, pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
	

	}

}
