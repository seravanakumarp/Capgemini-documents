package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrepStmt2 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.Load driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		//2.Establish connection
		Connection con=DriverManager.getConnection(url, "system", "system");
		String qry="SELECT employee_id,last_name,job_id FROM hr.employees where job_id like ?";
		//3.Statement object
		PreparedStatement st = con.prepareStatement(qry);
		st.setString(1, "AD%");
//		st.setInt(2, 80);
		//4. Execute query and get the ResultSe
		ResultSet rs = st.executeQuery();
		//5. Processing resultset
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"   "+rs.getString(2)+" "+rs.getString(3));
		}
		
		//6.closing conn
		if(con!=null)
		{
			con.close();
		}
	}
}
