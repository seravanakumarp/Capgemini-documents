package com.cg;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ClobDemo {

	public static void main(String[] args) {
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver"); //Load and Register driver
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		
		
		
		PreparedStatement ps=con.prepareStatement( "insert into filetable3 values(?,?)"); 
		//File f=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\a.txt"); 
		
		FileReader fr=new FileReader("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\a.txt"); 
		
		ps.setInt(1,101); //setting id
		ps.setCharacterStream(2,fr,15); 
		ps.executeUpdate(); 
		
		
		
	//	System.out.println(i+" records affected"); 
		//============ Retrieving from file 
		ps=con.prepareStatement("select id,name from filetable3"); 
		ResultSet rs=ps.executeQuery(); 
		rs.next();//now on 1st row 
		rs.next();//now on second row row 
		Clob c=rs.getClob(2); 
		Reader r=c.getCharacterStream(); 
		FileWriter fw=new FileWriter("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\mmm.txt"); 
		int i1; 
		
		//reading from first file then writing to second file***********
		while((i1=r.read())!=-1) 
		{
			fw.write((char)i1); 
			System.out.print((char)i1);
		}
		fw.close(); 
		con.close(); 
		}
		catch (Exception e)
		{e.printStackTrace();} 
		} 

	

}
