package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreateDemo {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	//2.Establish connection
	Connection con=DriverManager.getConnection(url, "system", "system");

	
//	String qry = "CREATE TABLE school(no number primary key,name varchar2(15),city varchar2(10),strength number(3))";
//	PreparedStatement st = con.prepareStatement(qry);
//	st.execute();

	
	String qry1 = "INSERT INTO school(no,name,city) VALUES(?,?,?)";
	PreparedStatement st = con.prepareStatement(qry1);
	st.setObject(1, 300);
	st.setObject(2, "MyNewSchool");
	st.setObject(3, "Pune");
	//st.setObject(4, 100);
	st.executeUpdate();
	
	qry1 = "SELECT * FROM school";
	st=con.prepareStatement(qry1);
	ResultSet rs = st.executeQuery();
	
	while(rs.next()) {
		System.out.println(rs.getObject(1)+" "+rs.getObject(2)+" "+rs.getObject(3)+" "+rs.getObject(4));
	}
	
	con.close();
}
}
