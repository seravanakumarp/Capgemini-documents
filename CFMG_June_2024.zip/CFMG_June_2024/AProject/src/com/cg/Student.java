package com.cg;

public class Student {
	private int rno;
	private String name;
	private double marks;
	static {
		System.out.println("static block 1");
	}
	static {
		System.out.println("static block 2");
	}
	static {
		System.out.println("static block 3");
	}
	public Student() {
		super();
		this.rno = 1;
		this.name = "aa";
		this.marks = 89.9;
	}
	{
		System.out.println("init block 1");
		marks=111;
	}
	{
		System.out.println("init block 2");
	}
	public Student(int rno, String name, double marks) {
		super();
		this.rno = rno;
		this.name = name;
		this.marks = marks;
	}



	@Override
	public String toString() {
		return "Student [rno=" + rno + ", name=" + name + ", marks=" + marks + "]";
	}

	public static void main(String[] args) {
		System.out.println("main");
		
		Student s=new Student();
		System.out.println(s);
	}

}
