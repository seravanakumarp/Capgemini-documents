package com.sprintdoubts;

import javax.swing.MenuElement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Rounak {
WebDriver driver;

public Rounak()
{
	
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();

	driver.manage().window().maximize();
	PageFactory.initElements(driver, this);
	
	driver.get("https://www.bestbuy.com/site/searchpage.jsp?st=hp+laptop&_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=&sp=&qp=&list=n&af=true&iht=y&usc=All+Categories&ks=960&keys=keys");
	System.out.println(driver.getTitle());
}


//		@FindBy(xpath="//div[@lang='en']/div[@class='country-selection']/a[2]")

//		WebElement  imgEle;


		@FindBy(xpath="//button[@class='c-button-unstyled hamburger-menu-button']")

		WebElement menuEle;


		@FindBy(xpath="//ul[@class='hamburger-menu-flyout-list']/li[3]")

		WebElement brandEle;

		@FindBy(xpath="//ul[@class='hamburger-menu-flyout-list hamburger-menu-flyout-sidecar-list']/li[2]")

		WebElement appleEle;

		@FindBy(xpath="//ul[@class='hamburger-menu-flyout-list']/li[2]")

		WebElement  serviceEle;

		@FindBy(xpath="//ul[@class='hamburger-menu-flyout-list hamburger-menu-flyout-sidecar-list']/li[2]")

		WebElement visitEle;

	    @FindBy(xpath="//ul[@class='hamburger-menu-flyout-list']/li[5]")

	    WebElement applianceEle;

	    @FindBy(xpath ="//ul[@class='hamburger-menu-flyout-list']/li[2]")

	    WebElement  majorApplianceEle;

	    @FindBy(xpath="//ul[@class='hamburger-menu-flyout-list hamburger-menu-flyout-sidecar-list']/li[3]/a")

	    WebElement refrigeratorsEle;

	    @FindBy(xpath="//ul[@class='hamburger-menu-flyout-list']/li[1]")

	    WebElement dealEle;


	    @FindBy(xpath="//ul[@class='hamburger-menu-flyout-list hamburger-menu-flyout-sidecar-list']/li[3]/a")

	    WebElement topDealEle;


	 
		 public void click_on_img() {

			// imgEle.click();

			// driver.findElement(By.xpath(properties.getProperty("image"))).click();

		 }

		public void  click_on_menu() {

			menuEle.click();

		}

		public void click_on_brand() {

			brandEle.click();

		}
	 /*
		public void click_on_apple_option() throws InterruptedException

		 { Thread.sleep(2000);

		    ApplePage applePage  =new ApplePage(driver);

			  appleEle.click();

			  return applePage;

		 }

		 //------------------------------------------------------------------

		 //2nd

		 public void click_on_ServiceSupport() {

				serviceEle.click();

			}

		 public SupportPage click_on_visitSupport() {

			 SupportPage supportPage=new SupportPage(driver); 

			 visitEle.click();

			 return  supportPage;

			}

		 //4th

		 public void click_on_appliance() {

			 applianceEle.click();

		 }

		 public void click_on_major() throws InterruptedException {

			 Thread.sleep(4000);

			 majorApplianceEle.click();

		 }

		 public RefrigeratorPage click_on_refrigerator() throws InterruptedException {

			 Thread.sleep(2000);

			 RefrigeratorPage refrigeratorPage= new RefrigeratorPage(driver);

			 refrigeratorsEle.click();

			return refrigeratorPage;

		 }


		 //5th senario

		  public void click_on_deal() {

			  dealEle.click();

		  }

//		 

//		 public TopDealPage click_on_topdeal() {

//			 TopDealPage topDealPage=new TopDealPage(driver);

//			 topDealEle.click();

//			 return topDealPage;

		 }

	 
	 
	 
	
	
	
	
}

*/
public static void main(String[] args) {
	Rounak r = new Rounak();
	
	WebElement el = r.driver.findElement(By.linkText("United States"));
	el.click();
	//el=r.driver.findElement(By.xpath(" //img[@class='primary-image max-w-full max-h-full']"));
	//el.click();
	r.menuEle.click();
	r.brandEle.click();
	r.appleEle.click();
	r.serviceEle.click();
	
	
	
	
	
	
	
	
	
	//WebElement  ele=r.driver.findElement(By.xpath("//div[@id='pricing-price-44064844']//div[contains(@class,'pricing-price')]//div[contains(@class,'pricing-price')]//div[contains(@class,'gvpc-price-1-2435-4 price-view-pb priceView-layout-medium')]//div[contains(@data-testid,'large-price')]//div[contains(@class,'pricing-price gvpc-price-1-2435-4 priceView-price')]//div[contains(@class,'flex gvpc-price-1-2435-4')]//div//div//span[contains(@aria-hidden,'true')][normalize-space()='$579.99']"));
	//System.out.println(ele.getText());
	//div[@id='pricing-price-24722363']//div[@class='pricing-price']//div[@class='pricing-price']//div[@class='gvpc-price-1-2435-4 price-view-pb priceView-layout-medium']//div[@data-testid='large-price']//div[@class='pricing-price gvpc-price-1-2435-4 priceView-price']//div[@class='flex gvpc-price-1-2435-4']//div//div//span[@aria-hidden='true'][normalize-space()='$579.99']
} 
}
