package com.cg;

public class MyDate2 {
String name;
	int a;
	public static void main(String[] args) {
	MyDate2 m = new MyDate2();
	System.out.println("Hello");
	
	}

}
