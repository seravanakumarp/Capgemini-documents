/**
 * 
 */
/**
 * 
 */
module MyProj {
}