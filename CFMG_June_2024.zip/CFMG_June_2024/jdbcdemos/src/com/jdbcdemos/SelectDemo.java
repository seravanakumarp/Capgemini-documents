package com.jdbcdemos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class SelectDemo {

	public static void main(String[] args) {
	//1.Load the driver-- oracle SQL
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//2.Establish Connection
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String uname="system";
			String pwd="system";
			Connection con= DriverManager.getConnection(url,uname,pwd);
			System.out.println("Connection established");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
