package com.classess;

public class SalesPerson extends Employee {
private double sales;
private double comm;

//no-arg ctor
public SalesPerson()
{
	super();
}


//para ctor
public SalesPerson(int eid,String ename,double ebasicSalary,double sales,double comm)
{
	super(eid,ename,ebasicSalary);
	this.sales=sales;
	this.comm=comm;
	
}

@Override
public String toString()
{
	return super.toString()+" "+sales+" "+comm+"\n";
}

@Override
public double computeSalary()
{
	return getEbasicSalary() + sales*comm/100;
}

}
