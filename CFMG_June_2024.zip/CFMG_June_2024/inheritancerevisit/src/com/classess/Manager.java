package com.classess;

public class Manager extends Employee {

	private double tAllow;
	private double fAllow;
	
	//no-arg ctor
	public Manager()
	{
		super();
	}
	//parameterized-ctor
	public Manager(int eid,String ename,double ebasicSalary,double tAllow,double fAllow)
	{
		super(eid,ename,ebasicSalary);
		this.tAllow=tAllow;
		this.fAllow=fAllow;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+" "+tAllow+" "+fAllow+"\n";
	}
	
	@Override
	public double computeSalary()
	{
		return getEbasicSalary()+tAllow+fAllow;
	}
	
	public double getBonus()
	{
		return 5000.0;
	}
}
