package com.classess;

public class TestHierarchy {

	public static void main(String[] args) {
	Employee employee = new Employee(100,"Raj",8000);
	System.out.println(employee);
	
	
	Manager manager = new Manager(200,"Giri",9000,2000,3000);
	System.out.println(manager);
	
	SalesPerson salesPerson = new SalesPerson(300,"Hari",6000,5000,5);
	System.out.println(salesPerson);
	
	Employee emp = manager;
	emp.computeSalary();
	if(emp instanceof Manager)
	{
		Manager m = (Manager)emp; //downcasting
		System.out.println("Manager bonus="+m.getBonus());
	}
	

	}

}
