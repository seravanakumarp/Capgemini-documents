package com.classess;

public class Employee {
	private int eid; //instance variables
	private String ename;
	private double ebasicSalary;

	//no-arg ctor
	public Employee()
	{
		super();
	}
	//parameterized ctor
	public Employee(int eid,String ename,double ebasicSalary) //formal para
	{
		this.eid = eid;
		this.ename=ename;
		this.ebasicSalary=ebasicSalary;
		
	}
	
	public double getEbasicSalary()
	{
		return this.ebasicSalary;
	}
	
	public void setEbasicSalary(double ebasicSalary)
	{
		this.ebasicSalary=ebasicSalary;
	}
	
	@Override
	public String toString()
	{
		return eid+"  "+ename+"  "+ebasicSalary+"\n";
	}
	
	public double computeSalary()
	{
		return ebasicSalary;
	}
}
