package com.arrays;

import java.util.Arrays;

public class ArrayDemo2 {

	public static void display(int[] a)
	{
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println();
	}
	
	public static int[] square(int[] a,int[] b)
	{
		for(int i=0;i<a.length;i++)
		{
			b[i]=a[i]*a[i];
		}
		return b;
	}
	public static void main(String[] args) {
			int[] a= {5,3,4,8,7,5,6,9};
			display(a);
//			System.out.println();
//			int[] b=new int[8];
//			square(a,b);
//			display(b);
			//Array API
			Arrays.sort(a);
			display(a);
			System.out.println(Arrays.binarySearch(a, 77));
			int[] a1= {1,2,3,4};
			int[] b1= {1,2,30};
			//System.out.println(Arrays.deepEquals(a1, b1));
			System.out.println(Arrays.compare(a1, b1));
			
			
	}
}
