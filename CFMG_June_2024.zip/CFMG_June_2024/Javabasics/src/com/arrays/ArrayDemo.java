package com.arrays;

public class ArrayDemo {
	int rno;//instance var-- initialized default values
	public void display()
	{
		System.out.println(rno);
	}
	public static void main(String[] args) {
		
		int[] a=new int[5];
		a[0]=11;
		a[1]=22;
		System.out.println(a.length);
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println("==================");
		
		int[] b= {1,2,3,4,5};
		System.out.println(a.length);
		for(int i=0;i<b.length;i++)
		{
			System.out.print(b[i]+" ");
		}

	}
}


/*
int b=10;
	int a; //local variable
	
	
//	if(b>=5)
//	{
//	a=10;
//	}
//	else
//	{
//		a=11;
//	}
	//System.out.println(a);
*/