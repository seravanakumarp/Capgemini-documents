package com.arrays;

public class VarArrayDemo {

	public static void display(int...p)
	{
		for(var ele:p)
		{
			System.out.print(ele+" ");
		}
		System.out.println("\n========================");
	}
	public static void main(String[] args) {
	int a[] = {1,2,3};
	int[] b= {1,2,3,4,5,6,7};
	int c[]= {3};
	display(a);
	display(b);
	display(c);
	display(11,22,33,44);
	display(11,22);
	display();//zero or any number of ele
	System.out.println("*************");
	}

}
