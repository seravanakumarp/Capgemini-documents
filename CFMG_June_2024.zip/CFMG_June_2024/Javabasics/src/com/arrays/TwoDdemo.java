package com.arrays;

public class TwoDdemo {

	public static void main(String[] args) {
		//int[] p=new int[-5];
		//int[][] a= {{1,2,3},{3,4,5},{5,6,7}};
		int[][]a = new int[3][];
		a[0]=new int[3];
		a[1]=new int[5];
		a[2]=new int[4];
		//3 rows
		//3  5  4
		for(int i=0;i<a.length;i++) //number of rows
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
	}

}
