package com.enumdemo;


enum CoffeeSize{SMALL(100),MEDIUM(150),LARGE(200);
	private int val; 
	
	CoffeeSize(int val)
	{
		this.val=val;
		System.out.println("Val inside enum: "+name()+" "+val+" "+this.ordinal());
		
	}
	
	public int getVal()
	{
		return this.val;
	}
}

class CoffeeShop
{
	CoffeeSize size;
	CoffeeShop(CoffeeSize size)
	{
		this.size=size;
	}
	
	public String toString()
	{
		return "Coffee size:"+size;
	}
	
}
public class EnumDemoCoffeeShop {

	public static void main(String[] args) {
		CoffeeShop order = new CoffeeShop(CoffeeSize.SMALL);
		System.out.println(order);
		
		
		
//		
//		for(CoffeeSize s:CoffeeSize.values()) {
//			System.out.println(s+"->"+s.getVal());
//		}
		
//		int[] ar = {11,22,33,44,55};
//		for(int i:ar)
//		{
//			System.out.println(i);
//		}

	}

}
