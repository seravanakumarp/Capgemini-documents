package com.enumdemo;

import java.util.Scanner;

//RED YELLOW GREEN
//A,B,AB,O


enum Colours{RED,YELLOW,GREEN,WHITE,BLACK,PINK}
//enum BloodGroup{}
//enum BankAccountType{}

public class EnumDemo {

	public static void main(String[] args) {
		
		for(Colours c:Colours.values())
		{
			System.out.println(c);
		}
		
		Colours fg=Colours.RED;
		Colours bg;
		
		switch(fg)
		{
		case RED:bg=Colours.WHITE;
		break;
		case YELLOW:bg=Colours.BLACK;
		break;
		
		}
		
	}

}
