package com.fildemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Prathamesh {
 
	public static void main(String[] args) throws IOException {
		File file=new File("C:\\\\Users\\\\PDASKE\\\\Desktop\\c.txt");
		//byte stream
		//abstract n
		FileOutputStream fos= new FileOutputStream(file);
		//System.out.println(file.exists());
		BufferedOutputStream bos= new BufferedOutputStream(fos);
		String s= "javabuffer";
		byte[] b=s.getBytes();
		bos.write(b);
		bos.close();
		fos.close();

		FileInputStream fis =new FileInputStream(file);
		BufferedInputStream bis= new BufferedInputStream(fis);
		System.out.println(bis.markSupported());
		System.out.print((char)bis.read());   // j
		System.out.print((char)bis.read());    // a
		bis.mark(5);
		System.out.print((char)bis.read());   // v
		System.out.print((char)bis.read()); 	//a
		bis.reset();
		System.out.print((char)bis.read());   // j
		System.out.print((char)bis.read()); 

		bis.close();
		fis.close();
	}
 
}

