package com.fildemo;

import java.io.IOException;

public class StdSTreamDemo {

	public static void main(String[] args) throws IOException {
		System.out.println("Hello");
		System.out.println("Enter any input:");
		int res=System.in.read();
		System.out.println((char)res);
		System.err.print("This is std error!");
		System.out.println("Hello");
	}

}
