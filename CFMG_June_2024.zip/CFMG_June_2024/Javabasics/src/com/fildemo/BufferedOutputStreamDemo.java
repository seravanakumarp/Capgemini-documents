package com.fildemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamDemo {

	public static void main(String[] args) throws IOException {
		File file=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\c.txt");
		//byte stream
		//abstract pathname created
		FileOutputStream fos=new FileOutputStream(file);//Physical file is created
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		String s = "JavaProgram";
		byte[] b=s.getBytes();
		bos.write(b);
		
		bos.close();
		fos.close();
		
		FileInputStream fis=new FileInputStream(file);
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		System.out.println(bis.markSupported());
		System.out.print((char)bis.read());//J
		System.out.print((char)bis.read());//a
		bis.mark(5);
		System.out.print((char)bis.read());//v
		System.out.print((char)bis.read());//a
		bis.reset();
		System.out.print((char)bis.read());//v
		System.out.print((char)bis.read());//a
		
		
		
		
		fis.close();
		bis.close();
		
	}

}
