package com.fildemo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReaderDemo {
//character stream
	public static void main(String[] args) throws IOException {
		File file=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\b.txt");
		//byte stream
		//abstract pathname created
		FileWriter fos=new FileWriter(file);//Physical file is created
		
		String s = "This is Java File Handling demo";
		char[] cary = s.toCharArray();
		fos.write(cary);
		fos.close();
		
		FileReader fr = new FileReader(file);
		int ch;
		while((ch=fr.read())!=-1)
		{
			System.out.print((char)ch);
		}
		fr.close();
	}

}
