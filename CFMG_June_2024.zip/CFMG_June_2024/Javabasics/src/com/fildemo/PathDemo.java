package com.fildemo;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathDemo {

	public static void main(String[] args) {
		Path path=Paths.get("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop");
		System.out.println(path.getNameCount());
		System.out.println(path.getFileName());
		System.out.println(path.getParent());
		System.out.println(path.getRoot());

	}

}
