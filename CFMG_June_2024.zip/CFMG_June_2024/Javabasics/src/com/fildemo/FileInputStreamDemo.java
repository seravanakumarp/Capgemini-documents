package com.fildemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileInputStreamDemo {
	
	public static void main(String[] args) throws IOException {
		File file=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\a.txt");
		//byte stream
		//abstract pathname created
		FileOutputStream fos=new FileOutputStream(file);//Physical file is created
		
		String s = "This is Java File Handling demo";
		//byte[] b= {'J','A','V','A'};
		byte[] b = s.getBytes();
		for(byte bb:b)
		{
			System.out.print((char)bb+"   ");
		}
		System.out.println("====================");
		fos.write(b);
		fos.close();
		
		FileInputStream fis=new FileInputStream(file);
		int ch;
		while((ch=fis.read())!=-1)
		{
			System.out.print((char)ch);
		}
	
		
		fis.close();

	}

//	public static void main(String[] args) throws IOException {
//		File file=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\a.txt");
//		//byte stream
//		//abstract pathname created
//		FileOutputStream fos=new FileOutputStream(file);//Physical file is created
//		//System.out.println(file.exists());
//		fos.write(65);
//		fos.write(10);
//		fos.write(66);
//		fos.write(10);
//		fos.write(67);
//		
//		fos.close();
//		
//		FileInputStream fis=new FileInputStream(file);
//		int ch;
//		while((ch=fis.read())!=-1)
//		{
//			System.out.print((char)ch);
//		}
//	
//		
//		fis.close();
//
//	}

}
