package com.fildemo;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		//path- hier  directories- locate the file
		//path - as string==> pathname
		
		//Abstract pathname
	File file=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop");
	System.out.println(file.exists());//false
	file.createNewFile();
	System.out.println(file.exists());//true
	System.out.println(file.isDirectory());
	System.out.println(file.isFile());
	System.out.println(file.getParent());
	System.out.println(file.getAbsoluteFile());
	System.out.println(file.getName());
	System.out.println("==================================");
	
	String[] files = file.list();
	for(String s:files)
	{
		System.out.println(s);
	}
	System.out.println("==================================");
	File[] filen = file.listFiles();
	for(File s:filen)
	{
		System.out.println(s);
	}
	
	File file2=new File("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\cfmgTesting2024\\cfmgHune\\cfmgA");
	
	file2.mkdirs();
	
	}

}
