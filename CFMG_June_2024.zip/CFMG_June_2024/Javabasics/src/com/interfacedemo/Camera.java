package com.interfacedemo;

public interface Camera {
	//contract based inheritance
	//members-  public
	//reference
	//can NOT instantiate
	//Reusability
	//Extensibilty
	//concrete -methods  static & default
	//public final variable
	final int px=10;//public
	
void click(); //public abstract
void record();//public abstract
default void  display()
{
	
}

static void show() //static method invoked by interface name
{
	System.out.println("Concrete static method");
}

default void view()  //concrete method - can be invoked by class object
{
	System.out.println("Concrete default method");
}
}
