package com.interfacedemo;

public class Tablet extends Phone implements Camera,MediaPlayer {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void click() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void record() {
		// TODO Auto-generated method stub
		
	}

}
