package com.interfacedemo;

public  class Phone {
 public void call()
{
	System.out.println("Basic Phone call");
}
public void message()
{
	System.out.println("Basic Phone message");
}
}
