package com.interfacedemo;

public class TestPhoneHier {

	public static void main(String[] args) {
//	SmartPhone sp = new SmartPhone();
//	sp.play();
//	sp.click();
		
//		Camera sp = new SmartPhone();// Polymorphism
//		sp.click();
//		sp.record();
	//	sp.call();
//		sp.play();
//		sp.click();
		
	Camera c = new SmartPhone();
	Camera.show();//static method invoked by interface
		c.view();
	}

}
