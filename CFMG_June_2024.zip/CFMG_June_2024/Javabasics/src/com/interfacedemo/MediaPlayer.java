package com.interfacedemo;

public interface MediaPlayer {
void play();//public abstract
void pause();
void stop();
}
