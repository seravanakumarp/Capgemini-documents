package com.interfacedemo;

public class SmartPhone extends Phone implements Camera,MediaPlayer{

	@Override
	public void play() {
		System.out.println("Play the recording");
		
	}

	@Override
	public void pause() {
		System.out.println("Pause the recording");
		
	}

	@Override
	public void stop() {
		System.out.println("Stop the recording");
		
	}

	@Override
	public void click() {
		System.out.println("Click the image");
		
	}

	@Override
	public void record() {
		System.out.println("Record the video");
		
	}

}
