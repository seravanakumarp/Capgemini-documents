package com.regexpre;

import java.util.regex.Pattern;

public class PhoneNumber {

	public static void main(String[] args) {
		//+(398) 123-4567-789-valid
		//023-4567-789-invalid
	String phone="+(398) 123-4567-789";
	
	System.out.println(Pattern.matches("\\+\\({1}[0-9]{3}\\){1}( )?[1-9]{3}-\\d{4}-[0-9]{3}", phone));
	}

}
// email id
//raj@gmail.com
//raj.sharma@gmail.com
//raj.sharma@yahoo.co.in
//raj.p.sharma@gmail.com

//Full Name
//Raj Ramesh Sharma -valid name

//372
//int a=0o372;
//0x372
//0b1111


