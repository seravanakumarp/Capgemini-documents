package com.regexpre;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExDemo {

	public static void main(String[] args) {
	//String sStr="Java is a programming language named after Java coffee brand found in Java island";
	String sStr="Python";
	
	
//	Pattern p=Pattern.compile("[A-Z]{1}[a-z]+");//Java
//	Matcher m=p.matcher(sStr);
//	Boolean res = m.matches();
//	System.out.println(res);
	
	//or
	
	System.out.println(Pattern.compile("[A-Z]{1}[a-z]+").matcher(sStr).matches());
	
	//or

	System.out.println(Pattern.matches("[A-Z]{1}[a-z]+", sStr));
	
	}

}
