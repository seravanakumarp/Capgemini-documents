package com.regexpre;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExDemo2 {

	public static void main(String[] args) {
		String sStr="Java22 is a progRamming Language named after Java444 coffee brand found in Java island";
		Pattern p=Pattern.compile("\\b[A-Z]{1}[a-z]+[0-9]*\\b");//word boundary
		Matcher m = p.matcher(sStr);
		int count=0;
		while(m.find())
		{
			System.out.println(m.group()+" "+m.start()+" "+m.end());
			count++;
		}
		System.out.println("occur="+count);
		String nStr=m.replaceAll("XXXXXXX");
		System.out.println(nStr);
	}

}


// +  one or any number
// * zero or any number
// ? zero or one
// . exactly one char

//[A-Za-z0-9_]   word char or \\w
//[^A-Za-z0-9_]   word char or \\W
//  \\s    \\S -- spaces
// \\d [0-9]   \\D   [^0-9]




