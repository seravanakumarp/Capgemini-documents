package com.exceptiondemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
 

class UnderAgeException extends Exception
{
	UnderAgeException()
	{
		super();
	}
	UnderAgeException(String msg)
	{
		super(msg);
	}
}

class OverAgeException extends Exception
{
	OverAgeException()
	{
		super();
	}
	OverAgeException(String msg)
	{
		super(msg);
	}
}
public class ExceptionThrowDemo {

	static void checkAge(int age) throws FileNotFoundException
	{
		try
		{
		if(age<10)
		{
			throw new UnderAgeException("Underage");
			//user defined exception/custom exceptrion
		}
		else
			if(age>30)
			{
				throw new OverAgeException("OverAge");
			}
			
		}
		catch(NullPointerException e)
		{
			System.out.println("Handled in method");
		}
		catch(UnderAgeException e)
		{
			System.out.println("Below 10 age "+e);
		}
		catch(OverAgeException e)
		{
			System.out.println("Above 30 age "+e);
		}
		
		System.out.println("method cont...");
	}

public static void main(String[] args)  {
		int age=40;
try
{//

	checkAge(age);
	System.out.println("Back to main");
}
catch(RuntimeException  e)
{
	System.out.println(e);
	}
//catch(RuntimeException e)
//{
//	System.out.println(e);
//}



//catch(FileNotFoundException e)
//{
//	System.out.println("In main exception handled");
//}
catch(Exception e)
{
	System.out.println("catch all block");
}
//if exception thrown or not thrown
finally {
	System.out.println("Finally block");
	//clean up code
	//resource release
}
System.out.println("After catch in the main");




}
}
