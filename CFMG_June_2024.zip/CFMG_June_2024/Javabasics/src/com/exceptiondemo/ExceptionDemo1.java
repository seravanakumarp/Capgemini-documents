package com.exceptiondemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionDemo1 {

	public static void main(String[] args) {
		
		int a=10;
		int b=2;
		try
		{
			
			FileInputStream fis=new FileInputStream("a.txt");
			//checked Exceptions
			//Thread.sleep(2000);//checked Exceptions
			int res = a/0; //unexpected event occurred here
			//unchecked Exception
			System.out.println("Res="+res);
			int[] ar= {1,2,3};
			System.out.println(ar[0]);
			String s = null;
			System.out.println(s.startsWith("J"));
		}
		catch(ArithmeticException e)
		{
			System.out.println("Trying to divide by zero value");
			System.out.println(e);
		}
		
		//unchecked exception
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array size is 3");
			System.out.println(e);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("Object is null");
			System.out.println(e);
		}
		
		catch(FileNotFoundException e)
		{
			System.out.println("File not found-- checked exception");
		}
		System.out.println("************");
		//
	}
	
	//Understand the exception--exception definition
	//Part of the code where it is occurring--  try block
	//Alternate solu- handling the exception- exception handler
	//Understandable message to end user
	//Resource management-clean up,save the data
	//either terminate-graceful termination or continue with the program run
	
//JVM
	//the class associated with the logical error
	//instatntiate that class-created object
	//throw that object-JVM is runninbg default excepton handler blck
	//JVM terminates the program-abrupt termination
	
}
