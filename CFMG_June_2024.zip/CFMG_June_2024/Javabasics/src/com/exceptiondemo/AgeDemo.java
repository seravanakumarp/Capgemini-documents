package com.exceptiondemo;

class UnderAgeException1 extends Exception
{
	UnderAgeException1()
	{
		super();
	}
	UnderAgeException1(String msg)
	{
		super(msg);
	}
}

class OverAgeException1 extends Exception
{
	OverAgeException1()
	{
		super();
	}
	OverAgeException1(String msg)
	{
		super(msg);
	}
}
public class AgeDemo {
public static void main(String[] args) {
	int age=5;
	try
	{
	if(age<10)
	{
		throw new UnderAgeException1("Underage");
		//user defined exception/custom exceptrion
	}
	else
	{
		if(age>30)
		{
			throw new OverAgeException1("OverAge");
		}
	}
	} //try
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("Handled in method");
		throw new NullPointerException(); //rethrowing
	}
	catch(NullPointerException e)
	{
		System.out.println("Handled in method");
		System.out.println(e);
		System.out.println(e.toString());
		System.out.println(e.getMessage());
		e.printStackTrace();
		
	}
	catch(UnderAgeException1 e)
	{
		System.out.println("Below 10 age "+e);
		
		//return;
		//System.exit(0);v
	}
	catch(OverAgeException1 e)
	{
		System.out.println("Above 30 age "+e);
		return;
	}
	finally
	{
		System.out.println("finally block");
	}
	
	System.out.println("method cont...");

}
}

