package com.exceptiondemo;

public class ErrorDemo {
static Integer x; //assigned to null
static int y=x.intValue();
//Unchecked Exception
//Error type Exception
//JVM failed
//Can not be handeled

	public static void main(String[] args) {
//		try
//		{
		System.out.println("In main");
//		}
//		catch(NullPointerException e) //can not be handles
//		{
//			System.out.println("null pointer exception");
//		}

	}

}
