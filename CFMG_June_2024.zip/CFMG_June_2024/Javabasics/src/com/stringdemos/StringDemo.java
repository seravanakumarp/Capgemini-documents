package com.stringdemos;

public class StringDemo {

	public static void main(String[] args) {
		
		String s1="Java"; //String const pool - String intern pool
		String s11="Java"; //String const pool - String intern pool
		
		//System.out.println(s1==s11); //false
		
		String s2=new String("java");// heap
		String s22=new String("Java");// heap
		//System.out.println(s2==s22); //references compared
		
		//==  object references compared
		//equals() objects are compared
		//System.out.println(s1.equals(s11));
		
		//System.out.println(s2.equals(s22));//true
		
		//System.out.println(s2.compareTo(s22)); //
		//s1=s2   0
		//s1<s2   negative
		//s1>s2 positive
		
		//==================================
		
		String str = "Java";
		
		str = str + " Lanaguage"; //new string-  Immutable , Synchronized(thread safe)
		//System.out.println(str);
		
		//StringBuffer--  Mutable,Synchronized(
		StringBuffer sb1 = new StringBuffer("Java");
		//sb.append(" Language");
		System.out.println(sb1);
		StringBuffer sb2 = new StringBuffer("Java");
		System.out.println(sb1==sb2); //false
		System.out.println(sb1.equals(sb2));//true
		//==========================
		//StringBuilder sbr = new StringBuilder("Java"); // Mutable, Not syncronized
		
		//Mutablity  synchronized
		
		String name = "Raj";
		name.concat(" Sharma");
		System.out.println(name);
		//Raj 
		
		StringBuffer name2 = new StringBuffer("Ravi");
		name2.append(" Patel");
		System.out.println(name2);
		//Ravi Patel
	}

}
