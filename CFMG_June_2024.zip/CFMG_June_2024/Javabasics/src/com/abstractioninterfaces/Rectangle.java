package com.abstractioninterfaces;

public class Rectangle extends Shape {
	private int side1;
	private int side2;

	Rectangle(int side1,int side2)
	{
		this.side1=side1;
		this.side2=side2;
	}
	@Override
	void area() {
		System.out.println("Area of rect="+(side1*side2));
		
	}

	@Override
	void draw() {
		System.out.println("drawing Rectangle");
		
	}
	void display()
	{
		System.out.println("display of rectangle class");
	}

}
