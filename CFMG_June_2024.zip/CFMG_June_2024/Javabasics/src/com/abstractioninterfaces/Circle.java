package com.abstractioninterfaces;

public class Circle extends Shape {
private int rad;

Circle(int rad)
{
	this.rad=rad;
}
@Override
void area() {
	System.out.println("area of circle:"+(3.14*rad*rad));
	
}

@Override
void draw() {
	System.out.println("Drawing circle");
	
}

}
