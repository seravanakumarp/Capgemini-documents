package com.abstractioninterfaces;

public  abstract  class Shape {
	//abstract class can have- attributes,abstract methods,concrete method,ctors
	//can not instantiate
	//reference can created
	// Reusability, extensibility
	
		int var; //instance var

		abstract  void area(); //declaration of the method- prototype

	 abstract void draw();
	 
	 void peri()
	 {
		 System.out.println("Shape class concere method show()");
	 }
}
