package com.abstractioninterfaces;

public class TestShape {
public static void main(String[] args) {
	Shape shape = new Rectangle(2,3);
	shape.area();
	shape.draw();
	//shape.display();
	
	shape=new Circle(1);
	shape.area();
	shape.draw();//Dynamic method dispatch
	
}
}
