package com.genericscollections;

public class GenericDemo {

	public static void main(String[] args) {
//		Object obj=new Integer(10);
//		
//		String str=(String)obj;
//		System.out.println(str);
		
		Object[] obArray=new Object[3];
		obArray[0]=new String("Java");
		obArray[1]=new String("Python");
		obArray[2]=new Integer(10);
		
		for(int i=0;i<3;i++)
		{
			String st=(String)obArray[i];
			System.out.println(st);
		}
		//problem: java.lang.ClassCastException:
	}

}
