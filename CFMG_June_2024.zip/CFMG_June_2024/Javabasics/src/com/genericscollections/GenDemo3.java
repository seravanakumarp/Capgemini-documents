package com.genericscollections;


public class GenDemo3<T> {
	T[] dataArray;
	int size;
	public GenDemo3(int capacity)
	{
		dataArray=(T[])new Object[capacity];
		size=0;
	}
	
	public void append(T ele)
	{
		dataArray[size]=ele;
		size++;
		
	}
	
	public void display()
	{
		for(int i=0;i<size;i++)
		{
			System.out.print(dataArray[i]+" ");
		}
	}

	
	public static void main(String[] args) {
		GenDemo3<Integer> gd = new GenDemo3<>(10);
		gd.append(10);
		gd.append(20);
		gd.append(30);
		gd.display();

	}

}
