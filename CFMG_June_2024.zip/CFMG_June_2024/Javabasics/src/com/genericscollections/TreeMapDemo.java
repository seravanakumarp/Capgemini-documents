package com.genericscollections;

import java.util.Collection;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		//key valu
		//not following order of insertion
		//one null key allowed
	TreeMap<Integer,String> hm = new TreeMap<>();
	hm.put(2,"BB");
	hm.put(1,"AA");
	hm.put(4, "DD");
	hm.put(3,"CC");
	
	System.out.println("First "+hm.firstEntry());
	System.out.println("last "+hm.lastEntry());
	hm.pollFirstEntry();
	hm.pollLastEntry();
	Set<Entry<Integer,String>> es = hm.entrySet();
	for(Entry<Integer,String> e:es)
	{
		System.out.println(e.getKey()+"  "+e.getValue());
	}
	//System.out.println(hm);

	hm.containsKey(4);
	System.out.println("----------------");
	
	hm.forEach((k,v)->System.out.println(k+" "+v));
	Collection se = hm.values();
	Set<Integer> s = hm.keySet();
	System.out.println(s);
	System.out.println(se);
	hm.size();
	

	}
	

}
