package com.genericscollections;

import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		//Insertion order
		//LRU - 
		LinkedHashMap<Integer,String> hm = new LinkedHashMap<>(5,0.5f,true)
		{
			protected boolean removeEldestEntry(Map.Entry e)
			{
				return size()>5;
			}
		};
		hm.put(2,"BB");
		hm.put(1,"AA");
		hm.put(4, "DD");
		hm.put(3,"CC");
		hm.put(5, "EE");
		System.out.println(hm.get(2));
		hm.put(6,"FF");
		hm.put(7,"GG");
		
		hm.forEach((k,v)->System.out.println(k+" "+v));

		//Synchronized
		Hashtable<Integer,String> ht = new Hashtable<>();
		ht.put(1, "AA");
		
		Properties p= new Properties();
	
	}

}





