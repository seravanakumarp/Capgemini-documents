package com.genericscollections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

class MyCompEmp1 implements Comparator<Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		if(o1.getId()==o2.getId() && o1.getName().equals(o2.getName()) && o1.getSalary()==o2.getSalary())
		{
			return 0;
		}
		else if(o1.getSalary()> o2.getSalary())
			return 1;
		else 
			return -1;
		
	}
	
}

class MyCompEmpId implements Comparator<Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		if(o1.getId()==o2.getId() && o1.getName().equals(o2.getName()) && o1.getSalary()==o2.getSalary())
		{
			return 0;
		}
		else if(o1.getId()> o2.getId())
			return 1;
		else 
			return -1;
		
	}
	
}
public class PriorityQueueEmployee {

		
	
	public static void main(String[] args) {
		Employee e1=new Employee(100, "Raj", 6000);
		Employee e2=new Employee(101, "Ravi", 7000);
		Employee e3=new Employee(102, "Ram", 8000);
//		Employee e4=new Employee(103, "Giri", 8000);
//		Employee e5=new Employee(104, "Hari", 8000);
//		Employee e6=new Employee(105, "Sam", 9000);
		PriorityQueue<Employee> emp = new PriorityQueue<Employee>();//new MyCompEmpId());
		emp.add(e1);
		emp.add(e1);
		emp.add(e3);
		//emp.add(e4);
		System.out.println(emp);
		//getting exception--  problem

	}

}
