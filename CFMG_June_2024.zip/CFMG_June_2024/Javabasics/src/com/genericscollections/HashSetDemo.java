package com.genericscollections;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		//Not following insertion order
		//Duplicates not allowed
		//Only one null object allowed
		HashSet<Integer> hs = new HashSet<>();
		hs.add(10);
		hs.add(20);
		hs.add(30);
		hs.add(20);
		hs.add(null);
		hs.add(null);
		System.out.println(hs);
		System.out.println("=========================");
		Iterator<Integer> itr=hs.iterator();
		while(itr.hasNext())
		{
			System.out.print(itr.next()+" ");
			hs.add(40); //Java.util.ConcurrentModificationException
			//Fail-fast
		}

	}

}
