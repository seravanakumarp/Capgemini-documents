package com.genericscollections;

import java.util.Comparator;
import java.util.TreeSet;

class MyCompTS implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
		if(o1>o2)
			return -1;
		else if(o1<o2)
			return 1;
		else
		return 0;
	}
	
}
public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Integer> ts = new TreeSet<>();//new MyCompTS());
		ts.add(10);
		ts.add(40);
		ts.add(20);
		ts.add(30);
		ts.add(25);
		ts.add(15);
		System.out.println(ts);
		System.out.println(ts.descendingSet());
		//Unique values
		//sorted while storing- defalut ascending
		//using -comparator- vhange to descnding oer use ts.descendingSet()
		
		

	}

}
