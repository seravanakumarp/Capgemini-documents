package com.genericscollections;
//generic class
class GenClass<T extends Number>
{
	private T data;
	
	public T getData()
	{
		return data;
	}
	public void setData(T data)
	{
		this.data=data;
	}
	
}
//class GenClassIn<T> extends GenClass
//{
//	
//}

public class GenDemo2 {

	public static void main(String[] args) {
		GenClass<Integer> gc = new GenClass<>();
		gc.setData(10);
		System.out.println(gc.getData());
	}

}
