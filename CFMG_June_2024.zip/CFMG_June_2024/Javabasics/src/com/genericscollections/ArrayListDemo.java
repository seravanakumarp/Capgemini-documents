package com.genericscollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>(3);
		//ordered collection data
		//following the insertion order 
		//Dynamic Array
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(0,5);
		al.add(5,55);
		//al.add(10,100); Exception
		System.out.println(al);
		
		//al.remove((Integer)5);
		System.out.println(al);
		
		ArrayList<Integer> al2 = new ArrayList<>(List.of(111,222,55));
		
		//System.out.println(al.contains(55));
		System.out.println(al.containsAll(al2));
		
		//al.addAll(0,al2);
		al.add(55);
		System.out.println(al);
		al.removeAll(al2);
		System.out.println(al);
		al.ensureCapacity(10);
		al.trimToSize();
		al.add(888);
		
		System.out.println(al.indexOf(1111));
		Object arr[]=al.toArray();
//		for(int i=0;i<al.size();i++)
//		{
//			System.out.print(al.get(i)+" ");
//		}
//		System.out.println();
//		for(var i:al)
//		{
//			System.out.print(i+" ");
//		}
//		System.out.println();
//		//traverse- forward dir
//		Iterator<Integer> itr = al.iterator();
//		while(itr.hasNext())
//		{
//			Integer temp=itr.next();
//			System.out.print(temp+" ");
//		}
//		System.out.println();
//		//bidirection iteration
//		ListIterator<Integer> litr = al.listIterator(al.size());
//		while(litr.hasPrevious())
//		{
//			Integer temp=litr.previous();
//			System.out.print(temp+" ");
//		}
//		System.out.println();
//		
//		al.forEach((x)->System.out.print(x+" "));
		
		
		
	}

}
