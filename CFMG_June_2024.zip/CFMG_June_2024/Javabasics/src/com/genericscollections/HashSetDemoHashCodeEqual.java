package com.genericscollections;

import java.util.HashSet;
import java.util.Objects;
//Object-- int hashcode()--- Memory address
class Person
{
	private String name;
	static int equalsCount;
	public Person(String name)
	{
		this.name=name;
	}
	


	@Override
	public int hashCode()
	{
		int hcode=0; //worst hashcode
		
		//int hcode=this.name.charAt(0)%10;
		//int hcode=this.name.hashCode();
		System.out.println("hashcode of "+this.name+" "+hcode);
		return hcode;
	}
	
	@Override
	public boolean equals(Object o)
	{
		Person p = (Person)o;
		System.out.println(this.name+"---"+p.name);
		equalsCount++;
		if(this.name.equals(p.name))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	
	
	public String toString()
	{
		return this.name+" --- "+this.hashCode()+"\n";
	}
}

public class HashSetDemoHashCodeEqual {

	
	//hashcode-- second char Ascii val-- different
	//equal--first char -same
	
	public static void main(String[] args) {
		HashSet<Person> hs = new HashSet<>();
		hs.add(new Person("Payan"));//0
		System.out.println("====================");
		hs.add(new Person("Putin"));//0
		System.out.println("====================");
		hs.add(new Person("Narendra"));
		System.out.println("====================");
		hs.add(new Person("Prithviraj"));
		System.out.println("====================");
		hs.add(new Person("Pratik"));
		System.out.println("====================");
		hs.add(new Person("Nitin"));
		
		System.out.println("\nequals count="+Person.equalsCount);
//		Person p1=new Person("Ansh");
//		Person p2=p1; 
//		hs.add(p1);
//		hs.add(p2); //both p1 p2 have same reference so same hashcode so addedd only once
		
		
		//System.out.println(hs);

	}

}
