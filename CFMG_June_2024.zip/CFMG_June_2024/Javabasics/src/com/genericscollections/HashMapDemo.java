package com.genericscollections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		//key valu
		//not following order of insertion
		//one null key allowed
	HashMap<Integer,String> hm = new HashMap<>();
	hm.put(2,"BB");
	hm.put(1,"AA");
	hm.put(4, "DD");
	hm.put(3,"CC");
	
	Set<Entry<Integer,String>> es = hm.entrySet();
	for(Entry<Integer,String> e:es)
	{
		System.out.println(e.getKey()+"  "+e.getValue());
	}
	//System.out.println(hm);

	hm.containsKey(4);
	System.out.println("----------------");
	
	hm.forEach((k,v)->System.out.println(k+" "+v));
	Collection se = hm.values();
	Set<Integer> s = hm.keySet();
	System.out.println(s);
	System.out.println(se);
	hm.size();
	}
	

}
