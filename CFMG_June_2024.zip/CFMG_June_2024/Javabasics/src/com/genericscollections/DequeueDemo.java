package com.genericscollections;

import java.util.ArrayDeque;

public class DequeueDemo {

	public static void main(String[] args) {
		ArrayDeque<Integer> aq = new ArrayDeque<>();
		//aq.add(10);
		//aq.addFirst(5);
		aq.addLast(10);
		aq.add(111);
		System.out.println(aq);
		aq.removeFirst();
		aq.removeLast();
		aq.offerFirst(11);
		aq.add(null);
		
		//Stack,Queue
		//
		

	}

}
