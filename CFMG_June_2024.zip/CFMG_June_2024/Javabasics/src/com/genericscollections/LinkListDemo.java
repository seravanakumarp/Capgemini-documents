package com.genericscollections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkListDemo {

	public static void main(String[] args) {
		LinkedList<Integer> ll = new LinkedList<>();
		ll.add(10);
		ll.add(0,5);
		ll.add(2,3);
		System.out.println(ll);
		ll.offer(6);
		ll.offerFirst(1);
		ll.offerLast(55);
		System.out.println(ll);
//		ll.remove();
//		ll.remove(0);
//		ll.pollFirst()
//		ll.pollLast();
//		ll.poll();
		Iterator<Integer> itr = ll.descendingIterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}

	}

}
