package com.genericscollections;

import java.util.Comparator;
import java.util.PriorityQueue;

class MyCompPQ implements Comparator<Integer>
{
	@Override
	public int compare(Integer o1, Integer o2) {
		if(o1>o2)
			return -1;
		else
			if(o1<o2)
				return 1;
				else
					return 0;
	}
	
}


public class PriorityQueueDemo {

	public static void main(String[] args) {
	PriorityQueue<Integer> pq = new PriorityQueue<>(new MyCompPQ());
	pq.add(7);
	pq.add(3);
	pq.add(5);
	pq.add(5);
	pq.add(5);
	pq.add(4);
	//pq.add(null);
	pq.add(1);
	System.out.println(pq);
	pq.remove((Integer)3);
	System.out.println(pq);
	System.out.println("Max="+pq.peek());  //maxHeap
	
//	7  3  5  4  1
	//[1, 3, 5, 7, 4]  //minHeap
	//Lower the value higher the priority
	//not following insertion order

	}

}
