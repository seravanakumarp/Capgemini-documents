package com.cg;



public class ComdLine {

	public static void main(String[] args) {
	int sum=0;
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
			sum=sum+Integer.parseInt(args[i]);
		}
		
		System.out.println("Sum="+sum);
	}

}

//primitive numeric datatype- byte short int long float double 
//Byte Short Integer Long Float Double -  wrapper classes 
//Super class- Number

