package com.cg;

public class MethodOverloadDemo {
	//Method overloading: Methods in same scope and different method signature
	//Static polymorphism
	// Method Signature
	//Number of para
	//Data type of para
	//Order para passed
	
	//called fun
	//compile time binding-- static binding -- early binding
	public static void add(int a,int b) //formal para-- parameters
	{
		System.out.println("Add int int: "+(a+b));
	}
	public static void add(float a,float b) //formal para-- parameters
	{
		System.out.println("Add float float: "+(a+b));
	}
	public static void add(int a,double b) //formal para-- parameters
	{
		System.out.println("Add int double: "+(a+b));
	}
	public static void add(double a,int b) //formal para-- parameters
	{
		System.out.println("Add double int: "+(a+b));
	}
	
	public static void add(double a,double b) //formal para-- parameters
	{
		System.out.println("Add double double: "+(a+b));
	}
	
	
	public static void add(int a,int b,int c) //formal para-- parameters
	{
		System.out.println("Add int int int: "+(a+b+c));
	}
//calling fun
	public static void main(String[] args) {
		int num1=10;
		int num2=20;
		add(num1,num2); //actual para-- arguments
		//add(10,20,30);
		add(1.2,2.3);
		add(1.2,100);
		add(100,1.2);
		//add(100.0f,10); // int,float
	}

}
