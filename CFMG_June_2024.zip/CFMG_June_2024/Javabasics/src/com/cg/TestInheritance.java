package com.cg;

public class TestInheritance {

	public static void main(String[] args) {
		Manager m = new Manager(200,"Ravi",9000,new MyDate(3,3,2003),3000,2000);
//		m.display();
//		System.out.println("Total salary of manager="+m.computeSalary());

		
		SalesPerson sp = new SalesPerson(300, "John", 7000, new MyDate(1,1,2001),1000, 10);
//		sp.display();
//		System.out.println("Total salary of SalesPerson="+sp.computeSalary());
//		
		Developer d = new Developer(400, "Giri", 8000, new MyDate(1,2,2001), "Java", "Insurance", 7000);
//		d.display();
//		System.out.println("Total salary of Developer="+d.computeSalary());
//		
		Employee emp = sp; //resolve  runtime
		emp.computeSalary();//binding --Runtime- late binding-dynamic binding
		
		if(emp instanceof Manager)
		{
		Manager mgr=(Manager)emp; //downcasting
		mgr.getBonus(); //class specific method 
		}
		else
		{
			System.out.println("Not a manager");
		}
		
		//Dynamic Polymorphism
		//Dynamic Method disptach
		
		//Overloading   ----   
		
		//Overriding ----
		
		
	}

}
