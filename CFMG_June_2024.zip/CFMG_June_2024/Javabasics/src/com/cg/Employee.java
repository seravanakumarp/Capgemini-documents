package com.cg;

import java.io.FileNotFoundException;

//Abstraction
//id,name,basicSalary,desig,dept,manager,project,email,doj,dob,phone

public class Employee {
private int id;
private String name;
protected double basicSalary;
private MyDate doj; //day,mon,year


//Access specifiers- visibilty
//private --  within same class
//default -- Inside the package
//protected--In the immediate derived classes - in same package or in different
//public -least restricted


public Employee()
{
	id=0;
	name=null;
	basicSalary=0.0;
	doj=null;
}


public Employee(int id,String name,double basicSalary,MyDate doj)
{
	this.id=id;
	this.name=name;
	this.basicSalary=basicSalary;
	this.doj=doj;
}

public String toString()
{
	return id+"  "+name+" "+basicSalary+"  "+doj.toString();
}

public void display() //overrdden method
{
	System.out.println(id+"  "+name+" "+basicSalary+"  "+doj.toString());
}

public Number computeSalary()
{
	System.out.println("Employee salary calculation");
	Double bs = basicSalary;
	return bs;
}
public void some() throws FileNotFoundException
{
	System.out.println("Some method in Employee");
}
}
//Number- Double
