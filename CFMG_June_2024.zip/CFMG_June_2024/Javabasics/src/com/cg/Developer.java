package com.cg;

public class Developer extends Employee {
private String technology;
private String project;
private double projInce;

Developer()
{
	super();
	this.technology=null;
	this.project=null;
	this.projInce=0.0;
	
}

Developer(int id,String name,double basicSalary,MyDate doj,String technology,String project,double projInce)
{
	super(id,name,basicSalary,doj);//invoking superclass ctor
	this.technology=technology;
	this.project=project;
	this.projInce=projInce;
}

public void display()
{
	super.display(); //Employee display()-- Reusability
	System.out.println(technology+" "+project+" "+projInce);
}

public Double computeSalary()
{
	System.out.println("Developer salary calculation");
	return super.basicSalary+projInce;
}
}
