package com.cg;

public class SalesPerson extends Employee {
private double sales;
private double comm; //percentage

SalesPerson()
{
	super();
	sales=0;
	comm=0;
}

SalesPerson(int id,String name,double basicSalary,MyDate doj,double sales,double comm)
{
	super(id,name,basicSalary,doj);//invoking superclass ctor

	this.sales=sales;
	this.comm=comm;
}


public void display()
{
	super.display(); //Employee display()-- Reusability
	System.out.println(sales+" "+comm);
}

public Double computeSalary()
{
	System.out.println("SalesPerson salary calculation");
	return super.basicSalary+sales*comm/100;
}


//no-arg ctor
//para ctor
//display()
//computeSalary() //--- basicSalary+sales*comm/100;
//toString()

}
