package com.cg;

public class MyDate {
	//Characteristics--Attributes-- data members
	//Access specifiers- visibility mode - defalut
	private int day;//instance variable
	private int mon;
	private int year;
	
	static int count; //only one copy -- class variable- static variable
//	
//	static
//	{
//		count=0;
//	System.out.println("Static block-1");
//	}
//	static
//	{
//	
//	System.out.println("Static block-2");
//	}
//	static
//	{
//		
//	System.out.println("Static block-3");
//	}
//	//instance block
//	{
//		System.out.println("Instance block-1");
//	}
//	{
//		System.out.println("Instance block-2");
//	}
	//during classloading memory alloc
	
	//constructor- default -- no-arg
	// initializes instance variables
	
	//no-arg ctor
	
	//class name
	//invoked automatically
	//overload ctor
	
	public MyDate()
	{
		this.day=1;
		this.mon=1;
		year=2001;
		count++;
		System.out.println("This is no-arg ctor");
		//this(3,3,2003); //constructor chaining
		
	}
	
	//parameterized ctor
	public MyDate(int day,int mon,int year) //formal para-- local var
	{
		this.day=day;  ///local & instance(under shadow)
		this.mon=mon;// this--> current object
		this.year=year;
		count++;
	}
	public MyDate(int day,int mon) //formal para-- local var
	{
		this.day=day;  ///local & instance(under shadow)
		this.mon=mon;// this--> current object
		this.year=2000;
		count++;
	}
	
	public static  void dispCount()
	{
		System.out.println("Count of objects:"+count);
	}
	
	//String representation of the object
	@Override
	public String toString()
	{
		return "Date of Birth:"+this.day+"/"+mon+"/"+year;
	}
	
	public void display()
	{
		System.out.println(this.day+"/"+mon+"/"+year);
	}

	//getter-accessor-selector
	public int getDay()
	{
		return day;
	}
	//setter-mutator-modifier
	public void setDay(int day)
	{
		this.day=day;
	}
	
	public int getYear()
	{
		return year;
	}
}
