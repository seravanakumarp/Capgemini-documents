package com.cg;

public class TestEmployee {

	public static void main(String[] args) {
		
		Employee employee =new Employee(100,"Raj",8000,new MyDate(2,2,2002));
		System.out.println(employee);
	}

}
