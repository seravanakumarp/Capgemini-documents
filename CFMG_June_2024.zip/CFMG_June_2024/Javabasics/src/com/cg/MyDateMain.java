package com.cg;

public class MyDateMain {

	public static void main(String[] args) {
		//instantiating class--  object
		MyDate dobRaj = new MyDate(); //comnpiler --  constructor
		dobRaj.display(); //facilitator
		
		//MyDate dobRavi = new MyDate();
		//dobRavi.display(); //implicitly ref of dobRavi
//		System.out.println(dobRavi.getDay());
//		dobRavi.setDay(11);
//		System.out.println(dobRavi.getDay());
//		int n=100;
//		System.out.println(n);
//		System.out.println(dobRavi);
//		MyDate dobJohn=new MyDate();
		
		MyDate.dispCount();
	}

}
