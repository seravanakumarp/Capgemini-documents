package com.cg;

import java.io.FileNotFoundException;

public class Manager extends Employee {
	
	private double foodAllow;
	private double petrolAllow;
	
	Manager()
	{
		super();
		this.foodAllow=0.0;
		this.petrolAllow=0.0;
		
	}
	
	Manager(int id,String name,double basicSalary,MyDate doj,double foodAllow,double petrolAllow)
	{
		super(id,name,basicSalary,doj);//invoking superclass ctor
		this.foodAllow=foodAllow;
		this.petrolAllow=petrolAllow;
	}
	
	public void display() //overriding method
	{
		//super.display(); //Employee display()-- Reusability
		System.out.println(foodAllow+" "+petrolAllow);
	}
	
	public Double computeSalary() //Covarient return type 
	{
		System.out.println("Manager salary calculation");
		Double ts = super.basicSalary+foodAllow+petrolAllow;
		return ts;
	}
	
	public void getBonus()
	{
		System.out.println("Manager is getting bonus");
	}
	public void some() throws RuntimeException
	{
		System.out.println("Some method in manager");
	}
}
