package com.parameters;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoginCredentialExcelReader {
	
	public String[] getCredentialsFromMyExcel(int sheetNo,int rowNo) throws IOException{
//		FileInputStream fis = new FileInputStream("C:\\Users\\medjoshi\\OneDrive - Capgemini\\Desktop\\myCredentials.xlsx");
		FileInputStream fis = new FileInputStream("src/test/resources/mycolorchoice.xlsx");
	
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(sheetNo);
		
		XSSFRow row = sheet.getRow(rowNo);
		int colCount=row.getPhysicalNumberOfCells();
		String[] data=new String[colCount];
		for(int i=0;i<colCount;i++)
		{
		XSSFCell cell1 = row.getCell(i);
		data[i] = cell1.getStringCellValue(); 
		}
		return data;	//SD array of Strings
	}
	

}
