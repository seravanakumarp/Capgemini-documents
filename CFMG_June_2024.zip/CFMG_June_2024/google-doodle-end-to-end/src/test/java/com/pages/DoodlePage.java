package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DoodlePage extends BasePage {
	
	//Object Repository
	@FindBy(linkText="Library")
	WebElement libraryEle;

	//constructor
	public DoodlePage(WebDriver driver)
	{
		super(driver);
	}
	
	
	
	//=======================================================
	// Methods performing operations on the page objects
	
	public LibraryPage click_libraryEle()
	{
		LibraryPage libraryPage = new LibraryPage(driver);
		libraryEle.click();
		return libraryPage;
	}
	
}
