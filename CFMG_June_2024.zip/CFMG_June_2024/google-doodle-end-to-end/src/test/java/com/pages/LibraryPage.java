package com.pages;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LibraryPage extends BasePage {
//Object Repository

	@FindBy(id="search-doodle__filter-5-toggle")
	WebElement colorEle;
	
	@FindBy(xpath = "(//span[@class='search-doodle__filter-panel__content-circle__input-circle-text'])[3]")
	WebElement blueColor;
	
	@FindBy(xpath = "(//span[@class='search-doodle__filter-panel__content-circle__input-circle-text'])[4]")
	WebElement brownColor;
	
	@FindBy(xpath = "(//span[@class='search-doodle__filter-panel__content-circle__input-circle-text'])[6]")
	WebElement greenColor;
//

	// This gives list of all input elements
	@FindBy(xpath = "//div[@class='search-doodle__filter-panel__content-circle']/label/input[@type='checkbox']")
	List<WebElement> unclickable_ColourElements;

	@FindBy(xpath = "//div[@class='search-doodle__filter-panel__content-circle']/label")
	List<WebElement> clickable_elements;
/*
	public void  select_colours(String... colour) {
		Iterator<WebElement> unclickable_colItr = unclickable_ColourElements.iterator();
		for (WebElement element : colourElements) {
			WebElement colorElement = (WebElement) unclickable_colItr.next();
			colors: for (String color : colour) {
				if (colorElement.getAttribute("value").equalsIgnoreCase(color)) {
					element.click();
					break colors;
				}

			}

		}
	}
	*/

	@FindBy(name = "search")
	WebElement searchButton;

	// By.xpath(String.format("//label[input[@value='%s']]", color1.toLowerCase()))

	public LibraryPage(WebDriver driver) {
		super(driver);
	}

	// methods

	public void click_color() {
		waitforvisibilityofWebElement(colorEle);
		colorEle.click();
	}

	public void blueColor_click() {
		waitforvisibilityofWebElement(blueColor);
		blueColor.click();
	}

	public void brownColor_click() {
		waitforvisibilityofWebElement(brownColor);
		brownColor.click();
	}

	public void greenColor_click() {
		waitforvisibilityofWebElement(greenColor);
		greenColor.click();
	}

	public void select_color_kishan(String...colors) throws InterruptedException {
		//Thread.sleep(2000);
		for(String c:colors)
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath(String.format("//label[input[@value='%s']]", c.toLowerCase()))).click();
		}
		
	}
	
	// div/div/label/input[@value='green']
	public void select_color(String color) throws InterruptedException {
		Thread.sleep(2000);
		/*
			for(WebElement element:clickable_elements) {
				if(element.getText().equals(color)) {
					System.out.println(color);
					element.click();
				}

			}

		
	 */
		/*
		
		//Chetan
		String xpath="//input[@value='"+color.toLowerCase()+"']/..";
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(xpath)).click();
	
		 */
		
		
		//input[contains(@id,"aaa"]
		
		//Sarang
//		String xpath="//div[@class='search-doodle__filter-panel__content-circle']//label//span[contains(.,'"+color+"')]";
//		Thread.sleep(2000);
//		driver.findElement(By.xpath(xpath)).click();
		 
		//Narendra
//		String xpath="//span[contains(.,'"+color+"')]";
//		Thread.sleep(2000);
//		driver.findElement(By.xpath(xpath)).click();
//		

		
		
		
		List<WebElement> inputEle = driver
				.findElements(By.xpath("(//div[@class='search-doodle__filter-panel__content-circle']/label)/input"));

		List<WebElement> allColors = driver
				.findElements(By.xpath("//div[@class='search-doodle__filter-panel__content-circle']/label"));

		Iterator<WebElement> itr = inputEle.iterator();
		// while(itr.hasNext())
		// {
		WebElement temp = itr.next();
		int count = 0;
		for (WebElement ac : allColors) // clickable colors
		{
			count++;
			if (temp.getAttribute("value").equals(color)) {
				System.out.println(temp.getAttribute("value"));
				driver.findElement(
						By.xpath("//div[@class='search-doodle__filter-panel__content-circle']/label[" + count + "]"))
						.click();
				// ac.click();

				break;
			}
		}
		// }*/
	}

	/*
	 * //WebElement
	 * element=driver.findElement(By.xpath("//div/div/label/input[@value='"+color+
	 * "']")); WebElement element=driver.findElement(By.xpath(
	 * "//div[@id='search-doodle__filter-5-content']/div/div/label/input[@value='"+
	 * color+"']")); driver.findElement(By.xpath(
	 * "(//div[@class='search-doodle__filter-panel__content-circle']/label)[2]")).
	 * click(); //element.click();
	 * //div[@id='search-doodle__filter-5-content']/div/div/label/input[@value='red'
	 * ]
	 */

	public SearchResultPage searchButton_click() throws InterruptedException {
		SearchResultPage searchResultPage = new SearchResultPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,10)");
		Thread.sleep(2000);
		// waitforvisibilityofWebElement(searchButton);
		searchButton.click();
		// js = (JavascriptExecutor)driver;

		js.executeScript("window.scrollBy(0,300)");
		return searchResultPage;
	}
	/*
	public void select_colors_dynamic(String color1, String color2, String color3) {


		WebElement color1Elem = 

				driver.findElement(By.xpath(String.format("//label[input[@value='%s']]", color1.toLowerCase())));

		WebElement color2Elem = 

				driver.findElement(By.xpath(String.format("//label[input[@value='%s']]", color2.toLowerCase())));

		WebElement color3Elem = 

				driver.findElement(By.xpath(String.format("//label[input[@value='%s']]", color3.toLowerCase())));

		waitForVisisbilityofWebElement(color1Elem);

		color1Elem.click();

		waitForVisisbilityofWebElement(color2Elem);

		color2Elem.click();

		waitForVisisbilityofWebElement(color3Elem);

		color3Elem.click();

	}
	*/
 
}
