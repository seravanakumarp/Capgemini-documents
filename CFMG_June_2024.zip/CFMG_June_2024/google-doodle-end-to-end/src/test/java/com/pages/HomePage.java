package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage  extends BasePage{
	//Object Repository
	
	@FindBy(xpath="//div[@class='FPdoLc lJ9FBc']//input[@name='btnI']")
	WebElement feelingLuckyEle;
	
	//=================================
	//constructor
	public HomePage(WebDriver driver)
	{
		super(driver);
	}
	
	//==================================
	//Methods operating on the objects-WebElements
	public DoodlePage click_feelingluckyEle()
	{
		DoodlePage doodlePage=new DoodlePage(driver);
		feelingLuckyEle.click();
		return doodlePage;
	}
	
	
	
}
