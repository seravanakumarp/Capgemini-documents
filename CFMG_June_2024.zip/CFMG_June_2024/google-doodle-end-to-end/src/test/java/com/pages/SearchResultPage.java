package com.pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class SearchResultPage  extends BasePage{

	String expextedUrl="https://doodles.google/search/?color_tags=brown&color_tags=green&color_tags=blue";
	
	@FindBy(linkText="Mountain Day 2024")
	WebElement doodleEle;
	
	SearchResultPage(WebDriver driver) {
		super(driver);
	}
	
	//
	public void validate_search_resultPage()
	{
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(expextedUrl, actualUrl);
		
		
		//OR
		//boolean res = expextedUrl.contains("brown");
		//Assert.assertTrue(res);
	}

	public void validate_doodle()
	{
		String expectedText="Mountain Day 2024";
		String actualText=doodleEle.getText();
		Assert.assertEquals(expectedText,actualText);
		
	}
	
}
