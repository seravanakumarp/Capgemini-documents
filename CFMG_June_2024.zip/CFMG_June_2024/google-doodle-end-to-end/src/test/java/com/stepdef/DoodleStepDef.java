package com.stepdef;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.DoodlePage;
import com.pages.HomePage;
import com.pages.LibraryPage;
import com.pages.SearchResultPage;
import com.parameters.LoginCredentialExcelReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DoodleStepDef {
	WebDriver driver; // instance var
	HomePage homePage;
	DoodlePage doodlePage;
	LibraryPage libraryPage;
	SearchResultPage searchResultPage;
	Properties properties;

	@Before
	public void init() throws FileNotFoundException, IOException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		properties = new Properties();
		properties.load(new FileInputStream("src/test/resources/doodle.configuration"));
	}

	@Given("User is on the Google homepage")
	public void user_is_on_the_google_homepage() {
		homePage = new HomePage(driver);
		String urlValue = properties.getProperty("url");
		homePage.loadUrl(urlValue);

		// homePage.loadUrl("https://www.google.com/");

	}

	@When("User clicks on I am feeling lucky")
	public void user_clicks_on_i_am_feeling_lucky() {
		doodlePage = homePage.click_feelingluckyEle();
	}

	@When("User clicks on library")
	public void user_clicks_on_library() {
		libraryPage = doodlePage.click_libraryEle();
	}

	@When("User clicks on Color")
	public void user_clicks_on_color() {
		libraryPage.click_color();
	}

	@When("User selects Blue Green and Brown color")
	public void user_selects_blue_green_and_brown_color() throws InterruptedException {
		Thread.sleep(2000);
		libraryPage.blueColor_click();
		libraryPage.brownColor_click();
		libraryPage.greenColor_click();
		//libraryPage.select_colours("blue","green","white");

	}

	@When("User selects {string} {string} and {string} color")
	public void user_selects_and_color(String color1, String color2, String color3) {
		try {
//			libraryPage.select_color(color1);
//			libraryPage.select_color(color2);
//			libraryPage.select_color(color3);
			libraryPage.select_color_kishan("blue","green","white");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

@When("User selects colors from {int} and {int}")
public void user_selects_colors_from_and(Integer sheetno, Integer rowno) {
	LoginCredentialExcelReader er = new LoginCredentialExcelReader();
	try {
		String[] data = er.getCredentialsFromMyExcel(sheetno,rowno);
		libraryPage.select_color_kishan(data);
	} catch (IOException e) {
		
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


	@When("User clicks on Search button")
	public void user_clicks_on_search_button() throws InterruptedException {
		searchResultPage = libraryPage.searchButton_click();
	}

	@Then("User gets doodles based on the selected colors")
	public void user_gets_doodles_based_on_the_selected_colors() {
		// searchResultPage.validate_search_resultPage();
		System.out.println("doodle validation 1");
	}

	@Then("User validates first doodle")
	public void user_validates_first_doodle() {
		// searchResultPage.validate_doodle();
		System.out.println("doodle validation 2");
	}
	
	
	
	
		@After
		public void tearDown(Scenario scenario) throws InterruptedException
		{
			Thread.sleep(4000);
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", "image"); 
			//this.tearDown(scenario);
			driver.quit();
			
		}
	

}
