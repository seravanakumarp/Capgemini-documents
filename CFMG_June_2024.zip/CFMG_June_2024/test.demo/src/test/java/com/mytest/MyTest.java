package com.mytest;

import static org.junit.Assert.assertThrows;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.myprog.Calci;

public class MyTest {
@Test
public void testPositiveIntegerAddition()
{
	Calci cal = new Calci(-10,20);
	//Assert.assertEquals(300, cal.add());
	assertThrows(ArithmeticException.class,()->cal.add());
}

@Test
public void testPositiveIntegerAdditions()
{
	Calci cal = new Calci(-10,20);
	//Assert.assertEquals(300, cal.add());
	assertThrows(ArithmeticException.class,()->cal.add());
}
}
