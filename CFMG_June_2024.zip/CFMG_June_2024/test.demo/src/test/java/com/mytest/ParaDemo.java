package com.mytest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Month;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.myprog.Calci;

public class ParaDemo {
	//execute a single test method multiple times with different parameters.
	@ParameterizedTest
	@Disabled
	@ValueSource(ints = {1, 3, 5, -3, 15, Integer.MAX_VALUE}) // six numbers
	void isOdd_ShouldReturnTrueForOddNumbers(int number) {
		Calci calci=new Calci();
	    assertTrue(calci.isOdd(number));
	}
	
	
	@Disabled
	 @ParameterizedTest
	 @EnumSource(Month.class) // passing all 12 months
	 void getValueForAMonth_IsAlwaysBetweenOneAndTwelve(Month month) {
	     int monthNumber = month.getValue();
	     assertTrue(monthNumber >= 1 && monthNumber <= 12);
	 }
	 
	@Disabled
	 @ParameterizedTest
	 @EnumSource(value=Month.class, names = {"APRIL", "JUNE", "SEPTEMBER", "NOVEMBER"}) // passing 4 specific months
	 void getValueForSpecificMonth_IsAlwaysBetweenOneAndTwelve(Month month) {
	     int monthNumber = month.getValue();
	     assertTrue(monthNumber >= 1 && monthNumber <= 12,"Asserion failed");
	 }
	 
	 //comma separated
	@Disabled
	 @ParameterizedTest
	 @CsvSource({"test,TEST", "tEst,TEST", "Java,JAVA"})
	 void toUpperCase_ShouldGenerateTheExpectedUppercaseValue(String input, String expected) {
	     String actualValue = input.toUpperCase(); //whether toUpperCase() working or not
	     assertEquals(expected, actualValue);
	 }
	 
	 //colon separeated
	 @ParameterizedTest
	 @CsvSource(value = {"test:test", "tEst:test", "Java:java"}, delimiter = ':')
	 void toLowerCase_ShouldGenerateTheExpectedLowercaseValue(String input, String expected) {
	     String actualValue = input.toLowerCase();
	     assertEquals(expected, actualValue);
	 }
	 
}
