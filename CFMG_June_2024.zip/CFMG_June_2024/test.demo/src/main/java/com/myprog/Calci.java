package com.myprog;

public class Calci {
	int a;
	int b;
	
	public  Calci()
	{
		
	}
	public Calci(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
public int add()
{
	if(a <0)
		throw new ArithmeticException("a is less than 0");
	return a+b;
}
public int sub()
{
	return a-b;
}


public boolean isOdd(int a)
{
	return a%2!=0;
}
}
