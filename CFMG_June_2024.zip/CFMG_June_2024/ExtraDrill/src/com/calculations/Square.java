package com.calculations;

public class Square extends Calculator {

}
