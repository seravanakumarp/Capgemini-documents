package com.calculations;

public class Factorial extends Calculator {
private int fact; //output


Factorial()
{
	super();
}
Factorial(int n)
{
	super(n);
}
public void calFact()
{
	int f=1;
	for(int i=1;i<=this.getN();i++)
	{
		f=f*i;
	}
	this.fact=f;
}

@Override
public void display()
{
	super.display();
	calFact();
	System.out.println("fact="+this.fact);
}
}
