package com.calculations;

public class TestCalci {

	public static void main(String[] args) {
		Factorial c=new Factorial();
		c.display();

	}

}
