package com.calculations;

public class Calculator {
private int n;//instance var
public Calculator()
{
	super();
}

public Calculator(int n)
{
	this.n=n;
}

public void display()
{
	System.out.println("n="+n);
}

public int getN()
{
	return n;
	
}

public void setN(int n)
{
	this.n=n;
	
}

}
