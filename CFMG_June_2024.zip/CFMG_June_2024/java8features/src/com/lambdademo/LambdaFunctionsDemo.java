package com.lambdademo;

//FunctionalInterface --An interface exactly one method 

@FunctionalInterface
interface myInt
{
	void display();
}

@FunctionalInterface
interface myInt2
{
	void display(String s);
}

@FunctionalInterface
interface myInt3
{
	int add(int a,int b);
}

class MyClass implements myInt
{

	@Override
	public void display() {
		System.out.println("Overridden display()");
		
	}
	
}



public class LambdaFunctionsDemo {

	public static void main(String[] args) {
//		myInt m1 = ()->{System.out.println("Display method");System.out.println("Display method 2");};
//		m1.display(); 
		
		
//		myInt2 m2 = (s)-> {System.out.println("Hello "+s);};
//		m2.display("Raj");
		
		myInt3 m3 = (a,b) -> {return a+b;};
		System.out.println(m3.add(10, 20));
		
		
//		myInt m2 = new myInt() {
//			
//			@Override
//			public void display() {
//				// TODO Auto-generated method stub
//				
//			}
//		};

	}

}
