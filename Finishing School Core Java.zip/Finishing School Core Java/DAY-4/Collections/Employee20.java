package Collections;

public class Employee20 
{
	 int id;
	 String name;
	 String designation;
	 float salary;
	 
	 public Employee20(int id,String name,String designation,float salary)
	 {
		 this.id=id;
		 this.name=name;
		 this.designation=designation;
		 this.salary=salary;
	 }

}
