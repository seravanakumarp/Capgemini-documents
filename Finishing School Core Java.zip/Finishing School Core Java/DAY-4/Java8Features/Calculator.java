package Java8Features;
@FunctionalInterface
interface Calculator
{
	public void calculate(int x,int y); //abstract method
}

