package dowhile;
import java.util.*;
public class Fibonacciseries 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int fib1=0,fib2=1,fib3,count,limit;
		
		System.out.println("Enter the limit of fibonacci series");
		limit=sc.nextInt();
		
		System.out.print(fib1+" "+fib2+" ");
		
		count=2;
		do
		{
			fib3=fib1+fib2;
			System.out.print(fib3+" ");
			fib1=fib2;
			fib2=fib3;
			count++;
		}while(count<limit);
	}

}
