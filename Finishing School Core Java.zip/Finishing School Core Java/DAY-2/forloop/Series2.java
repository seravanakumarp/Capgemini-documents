// 1*2 + 3*4 + 5*6 +...........
package forloop;
import java.util.*;
public class Series2 {

	public static void main(String[] args) 
	{
			Scanner sc=new Scanner(System.in);
			
			int i,n,sum=0;
			
			System.out.println("Enter the value of n");
			n=sc.nextInt();
			
			for(i=1;i<=2*n;i=i+2)
			{
				sum=sum+i*(i+1);
			}
			System.out.println(sum);
	}

}
