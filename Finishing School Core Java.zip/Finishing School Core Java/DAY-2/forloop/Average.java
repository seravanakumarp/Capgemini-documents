package forloop;
import java.util.*;
public class Average {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,num,i,count=0;
		float avg,sum=0;
		
		System.out.println("enter the value of n");
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
			System.out.println("Enter the number");
			num=sc.nextInt();
			
			if(num==0)
				break;
			else
			{
				sum=sum+num;
				count++;
			}
		}
		avg=sum/count;
		System.out.println(avg);
	}

}
