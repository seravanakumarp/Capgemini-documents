package forloop;
// 1*3 + 2*4 + 3*5 +.............
import java.util.Scanner;

public class Series3 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int i,n,sum=0;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
			sum=sum+i*(i+2);
		}
		System.out.println(sum);

	}

}
