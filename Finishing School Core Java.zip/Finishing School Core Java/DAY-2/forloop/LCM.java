package forloop;
import java.util.*;
public class LCM {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int a,b,largest,lcm;
		
		System.out.println("enter the value of a and b");
		a=sc.nextInt();
		b=sc.nextInt();
		
		largest=(a>b)?a:b;
		
		for(int i=1;i<=largest;i++)
		{
			if(largest%a==0 && largest%b==0)
			{
				lcm=largest;
				break;
			}
			largest++;
		}
		System.out.println("lcm of two numbers="+largest);
		
		
		/*largest=((a>b)&&(a>c))?a:((b>c)?b:c);
		for(int i=1;i<=largest;i++)
		{
			if(largest%a==0 && largest%b==0 && largest%c==0)
			{
				lcm=largest;
				break;
			}
			largest++;
		}
		System.out.println("lcm of two numbers="+largest); */
		
		
	}

}
