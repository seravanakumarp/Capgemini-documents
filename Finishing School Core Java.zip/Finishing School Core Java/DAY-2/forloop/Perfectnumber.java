package forloop;
import java.util.*;
public class Perfectnumber 
{

	public static void main(String[] args) 
	{
			Scanner sc=new Scanner(System.in);
			
			int n,i,sum=0;
			
			System.out.println("Enter the value of n");
			n=sc.nextInt();
			
			for(i=1;i<n;i++)
			{
				if(n%i==0)
					sum=sum+i;
			}
			if(n==sum)
				System.out.println(n+" "+"is a perfect number");
			else 
				System.out.println(n+" "+"is not a perfect number");
	}

}
