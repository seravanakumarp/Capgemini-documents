package whileloop;
import java.util.*;
public class Count {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n,digit,count=0,rem;
		
		System.out.println("Enter the number");
		n=sc.nextInt();
		System.out.println("Enter the digit");
		digit=sc.nextInt();
		
		while(n>0)
		{
			rem=n%10;
			if(rem==digit)
				count++;
			n=n/10;
		}
		System.out.println("occurrence of "+digit+"in a given number="+count);
	}

}
