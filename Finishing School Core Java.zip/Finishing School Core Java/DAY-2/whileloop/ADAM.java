package whileloop;
import java.util.*;
public class ADAM {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int n,sqr,temp,rev=0,rem,sqr1,rev1=0;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		sqr=n*n; //144
		
		temp=n;
		while(temp>0)
		{
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
		}
		
		sqr1=rev*rev; //441
		
		while(sqr1>0)
		{
			rem=sqr1%10;
			rev1=rev1*10+rem;
			sqr1=sqr1/10;
		}
		//rev1=144
		
		if(sqr==rev1)
			System.out.println("ADAM number");
		else
			System.out.println("Not an ADAM number");
		
	}

}
