package whileloop;
import java.util.*;
public class OddsumandEvensum {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int i,n,esum=0,osum=0;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		i=1;
		while(i<=n)
		{
			if(i%2==0)
				esum=esum+i;
			else
				osum=osum+i;
			i++; //if i++ is missing it will lead to infinite loop
		}
		System.out.println("sum of even numbers="+esum);
		System.out.println("sum of odd numbers="+osum);
	}

}
