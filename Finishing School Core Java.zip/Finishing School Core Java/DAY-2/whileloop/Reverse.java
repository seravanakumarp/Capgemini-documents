package whileloop;
import java.util.*;
public class Reverse {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,rev=0,rem,temp;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		/*while(n>0)
		{
			r=n%10;
			System.out.print(r);
			n=n/10;
		}*/
		
		temp=n;
		while(n>0)
		{
			rem=n%10;
			rev=rev*10+rem;
			n=n/10;
		}
		System.out.println("Reverse="+rev);
		
		if(temp==rev)
			System.out.println("palindrome number");
		else
			System.out.println("not a palindrome number");
		

	}

}
