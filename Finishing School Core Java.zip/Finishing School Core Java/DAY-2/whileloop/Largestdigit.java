package whileloop;
import java.util.*;
public class Largestdigit {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int n,largest,rem;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		largest=0;
		while(n>0) 
		{
			rem=n%10; 
			if(rem>largest)
				largest=rem; 
			n=n/10; 
		}
		
		System.out.println("largest digit="+largest);
	}

}
