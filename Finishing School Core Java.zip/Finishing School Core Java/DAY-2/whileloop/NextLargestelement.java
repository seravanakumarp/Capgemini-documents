package whileloop;
import java.util.*;
public class NextLargestelement {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int n,nextlargestnumber,temp,digit,rem;
		boolean flag=false;
		
		System.out.println("enter the value of n");
		n=sc.nextInt(); //2345
		
		System.out.println("Enter the digit");
		digit=sc.nextInt();
		
		nextlargestnumber=n-1; // 2344
		
		while(nextlargestnumber>0) //2343>0
		{
			temp=nextlargestnumber; //2344 //2343 //2342 //2341 //2340  //2339
			flag=false;
			while(temp>0) //2344>0 //2343>0 //234>0 //2342>0 //2339>0 //233>0  //23>0  //2>0
			{
				rem=temp%10; //4 //3 //4 //9 //3 //3 //2
				if(rem==digit) //4==4 //3==4 //4==4 //9==4 //3==4 //3==4 //2==4
				{
					flag=true;
					break;
				}
				temp=temp/10; //234 //233 //23 //2 //0
			}
			if(!flag)
				break;
			nextlargestnumber--;
			
			
		}
		if(nextlargestnumber>0)
			System.out.println(nextlargestnumber);
		else
			System.out.println("no such number exists");
		
	}

}
