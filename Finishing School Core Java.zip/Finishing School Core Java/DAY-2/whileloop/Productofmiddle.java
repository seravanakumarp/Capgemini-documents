package whileloop;
import java.util.*;
public class Productofmiddle 
{

	public static void main(String[] args) 
	{
			Scanner sc=new Scanner(System.in);
			
			int n,product=1,rem;
			
			System.out.println("Enter the value of n");
			n=sc.nextInt();
			
			n=n/10;   //removing the last digit
			
			while(n>9)
			{
				rem=n%10;
				product=product*rem;
				n=n/10;
			}
			
			System.out.println("product of middle digits="+product);
	}

}
