package whileloop;
import java.util.*;
public class Untilzero 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,psum=0,nsum=0,i,num;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		/*while(n!=0)
		{
			if(n>0)
				psum=psum+n;
			else
				nsum=nsum+n;
			
			System.out.println("Enter the value of n");
			n=sc.nextInt();
			
		}*/
		
		i=1;
		while(i<=n)
		{
			System.out.println("enter the number");
			num=sc.nextInt();
			
			if(num>0)
				psum=psum+num;
			else if(num<0)
				nsum=nsum+num;
			else
				break;
			i++;
		}
		
		System.out.println("positive sum="+psum);
		System.out.println("negative sum="+nsum);
		
		
		
	}

}
