package Patterns;
import java.util.*;
public class Pattern7 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int i,j,n;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		/*for(i='A';i<='E';i++)
		{
			for(j=i;j<'E';j++)
				System.out.print(" ");
			for(j=i;j>='A';j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*for(i='A';i<='E';i++)
		{
			for(j=i;j<'E';j++)
				System.out.print(" ");
			for(j='A';j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*for(i='E';i>='A';i--)
		{
			for(j='A';j<i;j++)
				System.out.print(" ");
			for(j=i;j<='E';j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=i;j<=5;j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=5;j>=i;j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=i;j<=5;j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		for(i=1;i<=n;i++)
		{
			for(j=i;j<n;j++)
				System.out.print(" ");
			for(j=i;j>=1;j--)
				System.out.print(j);
			System.out.println("");
		}
		
		
		
	}

}
