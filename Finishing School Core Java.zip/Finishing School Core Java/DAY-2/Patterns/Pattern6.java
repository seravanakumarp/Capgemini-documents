package Patterns;
import java.util.*;
public class Pattern6 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		char i,j;
		
		System.out.println("Enter the value of n");
		//n=sc.nextInt();
		
		/*for(i=n;i>=1;i--)
		{
			for(j=n;j>=i;j--)
				System.out.print(j);
			System.out.println("");
				
		}*/
		
		/*for(i=n;i>=1;i--)
		{
			for(j=n;j>=i;j--)
				System.out.print(i);
			System.out.println("");
				
		}*/
		
		/*for(i='A';i<='E';i++)
		{
			for(j='A';j<=i;j++)
				System.out.print(j);
			System.out.println("");
				
		}
		
		for(i='A';i<='E';i++)
		{
			for(j='A';j<=i;j++)
				System.out.print(i);
			System.out.println("");
				
		}*/
		
		/*for(i='E';i>='A';i--)
		{
			for(j='E';j>=i;j--)
				System.out.print(i);
			System.out.println("");
				
		}*/
		/*for(i='E';i>='A';i--)
		{
			for(j='E';j>=i;j--)
				System.out.print(j);
			System.out.println("");
				
		}*/
		
		/*for(i='E';i>='A';i--)
		{
			for(j=i;j>='A';j--)
				System.out.print(j);
			System.out.println("");
				
		}*/
		
		for(i='A';i<='E';i++)
		{
			for(j='E';j>=i;j--)
				System.out.print(j);
			System.out.println("");
				
		}
	}

}
