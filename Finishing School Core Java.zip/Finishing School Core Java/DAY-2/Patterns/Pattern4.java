package Patterns;
import java.util.*;
public class Pattern4 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		//int i,j,n;
		
		//System.out.println("Enter the value of n");
		//n=sc.nextInt();
		
		/*for(i=65;i<=69;i++)
		{
			for(j=65;j<=69;j++)
			{
				System.out.print((char)i);
			}
			System.out.println("");
		}*/
		
		char i,j;
		/*for(i='A';i<='E';i++)
		{
			for(j='A';j<='E';j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*for(i='E';i>='A';i--)
		{
			for(j='A';j<='E';j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*for(i='E';i>='A';i--)
		{
			for(j='E';j>='A';j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		for(i='Z';i>='V';i--)
		{
			for(j='Z';j>='V';j--)
				System.out.print(j);
			System.out.println("");
		}

	}

}
