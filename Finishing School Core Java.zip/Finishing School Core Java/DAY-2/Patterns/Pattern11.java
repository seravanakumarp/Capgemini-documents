package Patterns;
import java.util.*;
public class Pattern11 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int i,j,n,p,k=1;
		
		System.out.println("enter the value of n");
		n=sc.nextInt();
		
		/*for(i=1;i<n;i++)
		{
			if(i<=n/2)
			{
				for(j=i;j<=n/2;j++)
					System.out.print("*");
			}
			else
			{
				for(j=i;j>=n/2;j--)
					System.out.print("*");
			}
			System.out.println("");
		}*/
		
		
		/*for(i=1;i<=n;i++)
		{
			for(j=1;j<=n-i;j++)
				System.out.print(" ");
			for(j=1;j<=2*i-1;j++)
			{
				if(i==1||i==n||j==1||j==2*i-1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println("");
		}*/
		
		
		/*for(i=1;i<=n;i++)
		{
			for(j=1;j<=n-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(k++);
			for(j=i-1;j>0;j--)
			{
				p=k-2;
				k=k-1;
				System.out.print(p);
			}
			System.out.println("");
		}*/
		
		
		/*for(i=1;i<=n;i++)
		{
			for(j=1;j<=n-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(j);
			for(j=i-1;j>0;j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n-i;j++)
				System.out.print(" ");
			for(j=i;j>=1;j--)
				System.out.print(j);
			for(j=2;j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}
		

	}

}
