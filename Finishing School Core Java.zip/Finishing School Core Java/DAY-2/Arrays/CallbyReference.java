package Arrays;
import java.util.*;
public class CallbyReference {

	public static void main(String[] args)
	{
			Scanner sc=new Scanner(System.in);
			
			int a[]=new int[10];
			
			int i,n;
			
			System.out.println("Enter the size of array a");
			n=sc.nextInt();
			
			System.out.println("Enter the array a elements");
			for(i=0;i<n;i++)
				a[i]=sc.nextInt();
			
			System.out.println("Before call: Array a elements");
			for(i=0;i<n;i++)
				System.out.print(a[i]+" ");
	
			sort(a,n); //calling method
			
			System.out.println("After call: Array a elements");
			for(i=0;i<n;i++)
				System.out.print(a[i]+" ");
	}
	
	static void sort(int b[],int n)
	{
		int i,j,temp;
		
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(b[i]>b[j])
				{
					temp=b[i];
					b[i]=b[j];
					b[j]=temp;
				}
			}
		}
	}

}
