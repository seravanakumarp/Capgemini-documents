package Arrays;

import java.util.Scanner;

public class Secondsmallest {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[20];
		int i,n,smallest,ssmallest;
		
		System.out.println("enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		smallest=a[0];
		for(i=1;i<n;i++)
		{
			if(a[i]<smallest)
				smallest=a[i];
		}
		ssmallest=Integer.MAX_VALUE;
		
		for(i=0;i<n;i++)
		{
			if(a[i]<ssmallest && a[i]!=smallest)
				ssmallest=a[i];
				
		}
		System.out.println(ssmallest);
	
	}

}
