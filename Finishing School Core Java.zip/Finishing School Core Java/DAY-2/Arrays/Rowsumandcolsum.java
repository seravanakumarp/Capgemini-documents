package Arrays;

import java.util.Scanner;

public class Rowsumandcolsum {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int a[][]=new int[5][5];
		
		int i,j,row,col,rsum=0,csum=0;
		
		System.out.println("Enter the size of 2D Array a");
		row=sc.nextInt();
		col=sc.nextInt();
		
		System.out.println("Enter the 2d array a elements");
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		
		for(i=0;i<row;i++)
		{
			rsum=0;
			for(j=0;j<col;j++)
			{
				rsum=rsum+a[i][j];
			}
			System.out.print(rsum+" ");
		}
		
		for(i=0;i<row;i++)
		{
			csum=0;
			for(j=0;j<col;j++)
			{
				csum=csum+a[j][i];
			}
			System.out.print(csum+" ");
		}
	}

}
