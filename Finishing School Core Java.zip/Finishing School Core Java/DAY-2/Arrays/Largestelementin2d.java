package Arrays;
import java.util.*;
public class Largestelementin2d {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a[][]=new int[5][5];
		
		int i,j,largest,row,col,r,c;
		
		System.out.println("Enter the size of 2D Array a");
		row=sc.nextInt();
		col=sc.nextInt();
		
		System.out.println("Enter the 2d array a elements");
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		
		largest=a[0][0];
		r=0;c=0;
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				if(a[i][j]>largest)
				{
					largest=a[i][j];
					r=i;
					c=j;
				}
			}
		}
		System.out.println("largest element in an array a="+largest+"at position"+r+","+c);
		
		
	}

}
