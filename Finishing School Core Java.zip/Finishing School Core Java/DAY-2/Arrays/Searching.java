package Arrays;
import java.util.*;
public class Searching 
{

	public static void main(String[] args) 
	{
			Scanner sc=new Scanner(System.in);
			
			//int a[]= {23,45,67,91,32,1,60,91};
			
			/*int i,keyelement,pos=0,found=0;
			
			System.out.println("Enter the keyelement to be searched");
			keyelement=sc.nextInt();
			
			for(i=0;i<a.length;i++)
			{
				if(a[i]==keyelement)
				{
					found=1;
					pos=i;
					break;
				}
			}
			if(found==1)
				System.out.println("Search is successful! Keyelement found at index:"+pos);
			else
				System.out.println("Search is unsuccessful! keyelement not found");
			*/
			
			int a[]= {23,45,67,91,32,1,60,91};
			int selement,relement,i;
			
			System.out.println("enter the source and replace elements");
			selement=sc.nextInt();
			relement=sc.nextInt();
			
			for(i=0;i<a.length;i++)
			{
				if(selement==a[i])
					a[i]=relement;
			}
			for(i=0;i<a.length;i++)
				System.out.print(a[i]+" ");
	}

}
