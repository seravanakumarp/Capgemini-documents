package Arrays;
import java.util.*;
public class Rightrotation {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[10];
		
		int i,n,j,nr,temp;
		
		System.out.println("enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		System.out.println("Enter the number of rotations");
		nr=sc.nextInt();
		
		//right rotation of given array 
		for(i=0;i<nr;i++)
		{
			temp=a[n-1];
			for(j=n-1;j>0;j--)
				a[j]=a[j-1];
			a[0]=temp;
		}
		
		for(i=0;i<n;i++)
			System.out.print(a[i]+" ");

	}

}
