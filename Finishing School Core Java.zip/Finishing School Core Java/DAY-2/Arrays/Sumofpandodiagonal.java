package Arrays;
import java.util.*;
public class Sumofpandodiagonal {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int a[][]=new int[5][5];
		
		int i,j,row,col,psum=0,osum=0,sum;
		
		System.out.println("Enter the size of 2D Array a");
		row=sc.nextInt();
		col=sc.nextInt();
		
		System.out.println("Enter the 2d array a elements");
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		
		/*for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				if(i==j)
					psum=psum+a[i][j];
				if(i+j==row-1)
					osum=osum+a[i][j];
			}
		}
		
		sum=psum+osum;
		
		System.out.println("sum of principle and other diagonal elements="+sum);
		
		
		*/
		
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				if(i<j)
					System.out.print(a[i][j]+" ");
				if(i>j)
					System.out.print(a[i][j]+" ");
			}
		}
		
	}

}
