package Arrays;
import java.util.*;
public class ArrayInReverse {

	public static void main(String[] args) {
		
		//int a[]={10,20,30,40,50};
		
		//int i,low=0,high=5;
		
		//int mid=(low+high)/2;
		
		//String s[]= {"sachin","rahul","dhoni","kohli","sehwag"};
		
		//int i,low=0,high=4;
		
		//int mid=(low+high)/2;
		
		//for(i=4;i>=0;i--)
			//System.out.println(i+"-"+a[i]);
		
		//System.out.println("First element of an array a="+a[0]);
		//System.out.println("Last element of an array a="+a[4]);
		
		//System.out.println("middle element="+a[2]);
		
		//System.out.println("middle element="+a[mid]);
		
		/*for(i=0;i<5;i++)
			System.out.println(s[i]);
		System.out.println("First element of an array a="+s[0]);
		System.out.println("Last element of an array a="+s[4]);
				
		System.out.println("middle element="+s[mid]);*/
		
		
		char ch[]= {'s','a','t','h','y','a'};
		
		for(int i=0;i<ch.length;i++)
			System.out.println(ch[i]);
		System.out.println("First element of an array a="+ch[0]);
		System.out.println("Last element of an array a="+ch[ch.length-1]);
		
	}

}
