package Arrays;
import java.util.*;
public class Sumofevenandodd {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		/*int a[]= {2,3,6,9,1,12,19,23,34,11};
		
		int i,esum=0,osum=0;
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
				esum=esum+a[i];
			else
				osum=osum+a[i];
		}
		System.out.println("sum of odd numbers="+osum);
		System.out.println("sum of even numbers="+esum); */
		
		int a[]=new int[20];
		
		int i,n,psum=0,nsum=0;
		
		System.out.println("Enter the size of array a");
		n=sc.nextInt();
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		for(i=0;i<n;i++)
		{
			if(a[i]>0)
				psum=psum+a[i];
			else
				nsum=nsum+a[i];
		}
		System.out.println("sum of positive numbers="+psum);
		System.out.println("sum of negative numbers="+nsum);
		
		
		
	}

}
