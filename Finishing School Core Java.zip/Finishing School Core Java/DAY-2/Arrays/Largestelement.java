package Arrays;
import java.util.*;
public class Largestelement {

	public static void main(String[] args)
	{
		/*int a[]= {43,23,56,98,1,90,121,143,2};
		
		int i,largest;
		
		largest=a[0];
		
		for(i=1;i<a.length;i++)
		{
			if(a[i]>largest)
				largest=a[i];
		}
		System.out.println("largest element in a given array a="+largest);*/
		
		int a[]= {43,23,56,98,1,90,121,143,2};
		
		int i,smallest;
		
		smallest=a[0];
		
		for(i=1;i<a.length;i++)
		{
			if(a[i]<smallest)
				smallest=a[i];
		}
		System.out.println("smallest element in a given array a="+smallest);
		
		
	}

}
