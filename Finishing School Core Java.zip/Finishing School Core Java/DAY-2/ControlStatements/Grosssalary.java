package ControlStatements;
import java.util.*;
public class Grosssalary 
{

	public static void main(String[] args)
	{
			Scanner sc=new Scanner(System.in);
			
			int basic_salary,conveyance;
			float DA,HRA,gross_salary;
			
			System.out.println("Enter the basic salary of an employee");
			basic_salary=sc.nextInt();
			
			if(basic_salary>=5000)
			{
				DA=(110*basic_salary)/100.0f;
				HRA=(20*basic_salary)/100.0f;
				conveyance=500;
			}
			else if(basic_salary>=3000 && basic_salary<5000)
			{
				DA=basic_salary;
				HRA=(15*basic_salary)/100.0f;
				conveyance=300;
			}
			else
			{
				DA=(90*basic_salary)/100.0f;
				HRA=(10*basic_salary)/100.0f;
				conveyance=200;
			}
			gross_salary=basic_salary+DA+HRA+conveyance;
			
			System.out.println("gross salary of an employee="+gross_salary);

	}

}
