package ControlStatements;
import java.util.*;
public class Geometricalshapes {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("*****AREAS OF GEOMETRICAL SHAPES****");
		System.out.println("101: CIRCLE");
		System.out.println("102: SQUARE");
		System.out.println("103: RECTANGLE");
		System.out.println("104: TRIANGLE");
		
		float area,radius,side,length,breadth,base,height;
		int choice;
		
		System.out.println("Enter the choice");
		choice=sc.nextInt();
		
		switch(choice)
		{
			case 101: System.out.println("Enter the radius");
					  radius=sc.nextFloat();
					  area=3.142f*radius*radius;
					  System.out.println("area of circle="+area);
					  break;
			case 102: System.out.println("Enter the side");
					  side=sc.nextFloat();
					  area=side*side;
					  System.out.println("area of square="+area);
					  break;
			case 103: System.out.println("Enter the length and breadth");
					  length=sc.nextFloat();
					  breadth=sc.nextFloat();
					  area=length*breadth;
					  System.out.println("area of rectangle="+area);
					  break;
			case 104: System.out.println("Enter the base and height");
					  base=sc.nextFloat();
					  height=sc.nextFloat();
					  area=0.5f*base*height;
					  System.out.println("area of triangle="+area);
					  break;
			default:  System.out.println("Invalid choice");
					  
					  
					  
		}

	}

}
