package ControlStatements;
import java.util.*;
import java.io.*;
public class Positiveornegative 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n;
		
		System.out.println("enter the value of n");
		n=sc.nextInt();
		
		if(n>=0)
			System.out.println(n+" "+"is a positive number");
		else
			System.out.println(n+" "+"is a negative number");
	}

}

/*
`	Write a java program to check whether the number is divisible by 
   5 or not
   Write a java program to check whether the number is divisible by
   2 and 3 or not
   Write a java program which reads a character from the keyboard
   and print YES if the input is Y or y otherwise print NO
   
*/
