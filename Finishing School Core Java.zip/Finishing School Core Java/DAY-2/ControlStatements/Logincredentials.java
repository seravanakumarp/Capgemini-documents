package ControlStatements;
import java.util.*;
public class Logincredentials 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		String username="sathya@tech.com";
		int password=12345678;
		
		String uname;
		int pwd;
		
		System.out.println("Enter the user name");
		uname=sc.next();
		
		System.out.println("Enter the password");
		pwd=sc.nextInt();
		
		if(username.equals(uname))
		{
			if(password==pwd)
			{
				System.out.println("valid credentials!Login is successful");
			}
			else
			{
				System.out.println("Invalid password! Please try again");
			}
		}
		else
		{
			System.out.println("Invalid username! Please try again");
		}

	}

}
