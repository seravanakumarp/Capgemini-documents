package ControlStatements;

import java.util.Scanner;

public class Yesorno 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		char ch;
		
		System.out.println("enter the character");
		ch=sc.next().charAt(0);
		
		if(ch=='Y'||ch=='y')
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}
/*
 * Write a java program which reads the values of a,b and c from 
 * keyboard. Add them and after addition check if it is in the range 
 * of 100 to 200.
 * 
 * Write a java program which reads year as input and check
 * whether the given year is leap or not.
 */


