package ControlStatements;
import java.util.*;
public class Range 
{
	public static void main(String[] args)
	{
			Scanner sc=new Scanner(System.in);
			
			int a,b,c,sum;
			
			System.out.println("Enter the values of a,b and c");
			a=sc.nextInt();
			b=sc.nextInt();
			c=sc.nextInt();
			
			sum=a+b+c;
			
			if(sum>=100 && sum<=200)
				System.out.println(sum+" "+"is in the range of 100 to 200");
			else
				System.out.println(sum+" "+"is not in the range of 100 to 200");

	}

}
