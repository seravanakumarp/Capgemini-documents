package OOPSCONCEPTS;

public class StaticInnerClass 
{
	static class Inner
	{
		public void innerMethod()
		{
			System.out.println("method of static inner class");
		}
	}
	public static void main(String[] args) 
	{
			Inner i=new Inner();
			i.innerMethod();
	}

}
