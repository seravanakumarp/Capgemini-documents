package OOPSCONCEPTS;
class Person3
{
	String name;
	int age;
	
	Person3(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	void pdetails()
	{
		System.out.println(this.name+" "+this.age);
	}
}
class Aadhaarcard
{
	long aadhaarnumber;
	
	public Aadhaarcard(long aadhaarnumber) {
			
		this.aadhaarnumber=aadhaarnumber;
		
	}
	public void aadhaardisplay()
	{
		System.out.println(this.aadhaarnumber);
	}
	
}
public class Onetoone {

	public static void main(String[] args) 
	{
			Person3 p=new Person3("satish",45);
			p.pdetails();
			
			Aadhaarcard a=new Aadhaarcard(346248832438L);
			a.aadhaardisplay();
			
	}

}
