/*
 * Inner classes:


 * 
 * A class inside an another class is called Inner class.
 * 
 * This inner class can able to access all the members of the outer
 * class including private.
 * 
 * Advantage:
 * 
 * 1. Less line of code.
 * 2. Readability of the code.
 * 3. When a class is purely associated an one class. then we can
 * establish the inner class.
 * 
 * Types of Inner classes;
 * 1. Regular Inner class.
 * 2. Method local Inner class.
 * 3. Anonymous Inner class.
 * 4. Static Inner class.
 * 

 */
package OOPSCONCEPTS;
class Outer
{
	class Inner
	{
		public void innerMethod()
		{
			System.out.println("inner class method");
		}
	}
	public void outerMethod()
	{
		System.out.println("method of outer class");
	}
	
}
public class Innerclassesdemo {

	public static void main(String[] args) 
	{
		Outer o=new Outer();
		o.outerMethod();
		
		Outer.Inner i=new Outer().new Inner();
		i.innerMethod();
		
		
	}

}
