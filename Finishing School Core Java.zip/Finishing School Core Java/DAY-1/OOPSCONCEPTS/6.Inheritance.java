/*
 * Inheritance:


 * 
 * 1. It is a process of creating new class by taking members of other class.
 * 2. It is implemented by means of extends keyword.
 * 
 * Terminology regarding Inheritance:
 * 
 * Super class/base class/Parent class:it is a class where the 
 * members are accessed by another class.
 * Child class/Sub class: it is a class where it acquires members
 * of parent class.
 * 
 	Types of Inheritance:
 	1. Single Inheritance
 	2. Multi level Inheritance
 	3. Hierarchial Inheritance
 	
 	Other Inheritance:
 	4. Multiple Inheritance(not supported by java)
 *  5. Hybrid Inheritance(not supported by java)
 *  
 *  
 */
package OOPSCONCEPTS;
class Parent
{
	Parent()
	{
		System.out.println("Parent class constructor");
	}
}
class Child extends Parent
{
	Child()
	{
		System.out.println("child class constructor");
	}
}
public class Inheritance 
{

	public static void main(String[] args) 
	{
			Child c=new Child();
	}

}
