package OOPSCONCEPTS;
class Person10
{
	int id;
	String name;
	
	void setpdetails(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	void getpdetails()
	{
		System.out.println(this.id+" "+this.name);
	}
}
class Student20 extends Person10
{
	String branch;
	int semester;
	float marks;
	
	void setsdetails(String branch,int semester,float marks)
	{
		this.branch=branch;
		this.semester=semester;
		this.marks=marks;
	}
	void getsdetails()
	{
		System.out.println(this.branch+" "+this.semester+" "+this.marks);
	}
}
class Employee20 extends Person10
{
	float salary;
	String designation;
	
	void setedetails(float salary,String designation)
	{
		this.salary=salary;
		this.designation=designation;
	}
	void getedetails()
	{
		System.out.println(this.salary+" "+this.designation);
	}
}
public class Hierarchialnheritance {

	public static void main(String[] args) 
	{
			Student20 s=new Student20();
			s.setpdetails(123,"karthik");
			s.setsdetails("CSE",3,456);
			s.getpdetails();
			s.getsdetails();
			
			Employee20 e=new Employee20();
			e.setpdetails(1240,"rohan");
			e.setedetails(45000,"developer");
			e.getpdetails();
			e.getedetails();
	}

}
