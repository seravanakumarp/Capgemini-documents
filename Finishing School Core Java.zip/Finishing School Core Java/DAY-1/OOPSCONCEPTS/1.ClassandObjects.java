/* OOPS Concepts:


 * 1. Class
 * 2. Object
 * 3. Encapsulation
 * 4. Abstraction
 * 5. Inheritance
 * 6. Polymorphism
 * 
 */

/*Object: An entity which is physically existing in real world which
occupies some amount of memory.
2-> It contains some properties and some actions.
3-> Property is nothing but data or information which describes your
object and we represent in the form of variables.
4-> Actions is nothing but functions or tasks which are accomplished by
an action and represented in the form of methods.

Class: A class is a plan or blueprint for an object.
2-> it is a collection of common properties and common methods among group of objects.


Encapsulation: Binding up of variables and methods into a single unit.
2. It is achieved by means of a class.
3. it is protection barrier protecting from data and code of one class to another class.
4. POJO Rules:
	POJO stands for plain old java object.
	1. class must be public
	2. variables of class must be made as private.
	3. methods are class are made as public.
5. Security.

Abstraction: 
1. Hiding the implementation and displaying the functionality.
2. Hiding of irrelevant information and displaying of relevant information is called
abstraction.
3. it is achieved by abstract classes and interfaces.

Inheritance: 
1. It is a process of accessing the properties of one class by 
an another class.
2. Advantage: Reusability, Less line of code, Developing time is reduced.

Polymorphism:

1. An entity exhibiting many behaviors/tasks
2. Advantage: Flexibility: an entity able to perform many operations.
*/

/* Variables:
 * 1. instance variables
 * 2. static variables
 * 3. local variables
 * 
 * Instance variables: 
 * 
 * 1. A variable which is inside the class and outside the method
 * is called as instance variable.
 * 2. Memory for the instance variable is allocated during the creation of object.
 * 3. Memory for the instance variables is allocated in heap area.
 * 4. Memory for the instance variable is allocated every time a new object is created.
 * 
 *    int -0
 *    float 0.0
 *    short -0
 *    byte -0
 *    double -0.0
 *    long - 0
 *    char - space
 *    boolean - false
 *    String - null
 * 
 * 
 * static variables: 
 * 
 * 1. A variable inside the class and outside the method with static keyword
 * are static variables.
 * 
 * 2. Memory for the static variables are allocated during the class loading time.
 * 3. Scope of this static variable is at class level.
 * 4. Memory for the static variables are allocated in method area.
 * 5. Memory for the static variables is allocated only once for the entire class.
 * 6. Static variables are shared among all the objects of your class.
 * 
 *  NOTE: instance members are accessed by reference(object).
 *  	  static members are accessed by class name or reference(object).

 */
	
package OOPSCONCEPTS;
class Student
{
	int rollno=123;
	String name="sachin";
	float marks=456.0f;
	
	
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+marks);
	}
}

public class ClassandObjects 
{

	public static void main(String[] args) 
	{
	
			Student s=new Student();
			s.display();
			Student s1=new Student();
			s1.rollno=124;
			s1.name="rahul";
			s1.marks=556.0f;
			
			System.out.println(s1.rollno+" "+s1.name+" "+s1.marks);
	}

}
