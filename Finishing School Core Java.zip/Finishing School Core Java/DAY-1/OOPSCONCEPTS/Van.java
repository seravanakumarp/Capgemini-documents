package OOPSCONCEPTS;

public class Van 
{
	private String name;
	
	private Engine engine;
	
	public Van(String name,String type,float price)
	{
		engine=new Engine();
		this.name=name;
		engine.setType(type);
		engine.setPrice(price);
	}
	
	public Engine getEngine() {
		return engine;
	}

	@Override
	public String toString() {
		return "Van [name=" + name + ", engine=" + engine + "]";
	}

	public static void main(String[] args)
	{
		Van v=new Van("Mahindra","fourstroke",345000);
		Engine e=v.getEngine();
		
		System.out.println(v.name);
		System.out.println(e.getType()+" "+e.getPrice());
		
		System.out.println(v);
		
		v=null;
		
		System.out.println(v.getEngine());
	}

}
