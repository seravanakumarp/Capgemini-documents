/* Wrapper classes:
 * 
 * the process of converting primitive data types into
 * object type is done by means of Wrapper classes.
 * 
 * they belongs to the package called lang.
 * 
 * primitive data type                   wrapper class
 *       int                                 Integer
 *       float                               Float
 *       char                                Character
 *       double                              Double
 *       long                                Long
 *       short                               Short
 *       byte                                Byte
 *       boolean                             Boolean
 *       
 *Purpose: is to convert partial object oriented language to 
 *fully object oriented language.
 *
 *Six types of conversions w.r.t wrapper classes:
 *
 *1. primitive -> Object(Boxing)
 *2. Object    -> primitive(Unboxing)
 *3. primitive -> String
 *4. String    -> primitive
 *5. Object    -> String
 *6. String    -> Object
 * 
 */

package OOPSCONCEPTS;

public class Wrapperclasses {

	public static void main(String[] args) 
	{
		// primitive to Object
		
		   byte a=100;
		   Byte b=Byte.valueOf(a);
		   
		   System.out.println(b);
		   
		// Object to primitive
		   
		   int x=234;
		   Integer y=Integer.valueOf(x);
		   int z=y.intValue();
		   
		   System.out.println(z);
		   
		// primitive to String
		   
		   int p=200;
		   String s=Integer.toString(p);
		   
		   System.out.println(s);
		   
		 // String to primitive
		   
		   String s1="3456";
		   int q=Integer.parseInt(s1);
		   System.out.println(q);
		   
		 // String to Object
		   
		   String p1="raju";
		  // Object b1=String.valueOf(p1);
		   Object b1=p1;
		   
		   System.out.println(b1);
		   
		   // Object to String
		   
		   Object b2="kapil";
		   String p2=b2.toString();
		   
		   System.out.println(p2);
		   
		   
		  
	}

}
