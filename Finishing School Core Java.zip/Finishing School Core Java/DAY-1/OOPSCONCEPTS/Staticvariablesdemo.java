package OOPSCONCEPTS;

public class Staticvariablesdemo 
{
	int x;
	static int y;
	public static void main(String[] args) 
	{
		Staticvariablesdemo s=new Staticvariablesdemo();
		s.x++;
		s.y++;
		
		System.out.println(s.x);
		System.out.println(s.y);
		
		Staticvariablesdemo s1=new Staticvariablesdemo();
		
		s1.x++;
		s1.y++;
		
		System.out.println(s1.x);
		System.out.println(s1.y);
		
		Staticvariablesdemo s2=new Staticvariablesdemo();
		
		s2.x++;
		s2.y++;
		
		System.out.println(s2.x);
		System.out.println(s2.y);
		
	}

}
