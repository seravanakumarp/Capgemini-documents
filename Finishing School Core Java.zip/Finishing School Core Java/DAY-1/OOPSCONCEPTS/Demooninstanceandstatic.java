package OOPSCONCEPTS;

public class Demooninstanceandstatic 
{
	int x=10;
	static int y=20;
	public static void main(String[] args) 
	{
		Demooninstanceandstatic d=new Demooninstanceandstatic();
		
		System.out.println(d.x);
		System.out.println(Demooninstanceandstatic.y);
		System.out.println(d.y);
		
		
	}

}
