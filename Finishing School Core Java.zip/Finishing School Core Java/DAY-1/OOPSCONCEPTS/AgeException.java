package OOPSCONCEPTS;

import java.util.Scanner;

class InvalidAgeException extends Exception
{
	String name;
	public InvalidAgeException(String name) 
	{
		this.name=name;
	}
	public String message()
	{
		return this.name;
	}
	
}
class Person12
{
	public static void checkAge(int age) throws InvalidAgeException
	{
		if(age>=18)
		{
			System.out.println("eligible for voting");
		}
		else
		{
			InvalidAgeException i=new InvalidAgeException("Invalid age");
			throw i;
		}
	}
}
public class AgeException {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Person12 p=new Person12();
		int age;
		
		System.out.println("enter the age");
		age=sc.nextInt();
		
		try
		{
			p.checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message());
		}
	}

}
