package OOPSCONCEPTS;
class Outer1
{
	public void outerMethod()
	{
		class Inner
		{
			public void innerMethod()
			{
				System.out.println("inner class method");
			}
		}
		Inner i=new Inner();
		i.innerMethod();
	}
}
public class MethodlocalInnerclass {

	public static void main(String[] args) 
	{
			Outer1 o=new Outer1();
			o.outerMethod();
	}

}
