package OOPSCONCEPTS;
class Person4
{
	String name;
	int age;
	
	Person4(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	void pdetails()
	{
		System.out.println(this.name+" "+this.age);
	}
}
class Address
{
	String state;
	String city;
	int pincode;
	
	Address(String state,String city,int pincode)
	{
		this.state=state;
		this.city=city;
		this.pincode=pincode;
	}
	
	void adetails()
	{
		System.out.println(this.state+" "+this.city+" "+this.pincode);
	}
}
public class Manytomany {

	public static void main(String[] args)
	{
			Person4 p=new Person4("Rahul",45);
			Address a=new Address("AP","Vijaywada",5484554);
			
			p.pdetails();
			a.adetails();
			
			Person4 p1=new Person4("Ranjith",55);
			Address a1=new Address("AP","Vizag",5484550);
			
			p1.pdetails();
			a1.adetails();
			
	}

}
