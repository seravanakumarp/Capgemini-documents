package OOPSCONCEPTS;
class Demo201
{

	public static void main(String[] args) 
	{
		System.out.println("parameter is of String array");
	}
	public static void main(String args)
	{
		System.out.println("parameter is String");
	}
	public static void main(int[] a)
	{
		System.out.println("paramter is an int array");
	}
	public static void main(int a,int b)
	{
		System.out.println("two parameters of type integer");
	}
	
}
public class Mainmethodoverloading 
{

	public static void main(String[] args)
	{
			Demo201 d=new Demo201();
			d.main(new String[]{"sachin","rahul","dhoni"});
			d.main(new int[] {10,20,30,40,50});
			d.main("raju");
			d.main(10,20);
			//Anonymous Array: An array without name
			
	}

}
