package OOPSCONCEPTS;

public class Car 
{
	private String name;
	private String color;
	private float price;
	
	private Musicplayer mp;

	public Car(String name, String color, float price, Musicplayer mp) 
	{
		this.name = name;
		this.color = color;
		this.price = price;
		this.mp = mp;
	}
	
	
	
	@Override
	public String toString() {
		return "Car [name=" + name + ", color=" + color + ", price=" + price + ", mp=" + mp + "]";
	}



	public static void main(String args[])
	{
		Musicplayer mp=new Musicplayer("Sony",35000);
		//Musicplayer mp=null;
		Car c=new Car("Maruthi","white",600000, mp);
		
		System.out.println(c);
		
		
		
	}
	
	

}
