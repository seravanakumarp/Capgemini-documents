/*
 * Command Line Arguments:
 * 
 * Arguments which are passed during the execution of a program
 * at command prompt is called command line arguments.
 * 
 * 
 */
//count number of arguments passed during execution
package OOPSCONCEPTS;

public class Commandlinearguments {

	public static void main(String args[]) 
	{
			//System.out.println(args.length);
		
			/*for(int i=0;i<args.length;i++)
				System.out.println(args[i]);
			*/
		
			int x=Integer.parseInt(args[0]);
			int y=Integer.parseInt(args[1]);
		
			System.out.println(x+y);
			
			
			
	}

}

