package OOPSCONCEPTS;

public class Bank1 
{
	float bal,rate;
	
	Bank1(float bal,float rate)
	{
		this.bal=bal;
		this.rate=rate;
	}
	void display()
	{
		Interest i=new Interest();
		i.calculateInterest();
	}
	private class Interest
	{
		float interest;
		void calculateInterest()
		{
			interest=(bal*rate)/100;
			System.out.println("interest="+interest);
			bal=bal+interest;
			System.out.println("balance="+bal);
		}
	}
	public static void main(String[] args) 
	{
		Bank1 b1=new Bank1(30000,8.25f);
		b1.display();
	}

}
