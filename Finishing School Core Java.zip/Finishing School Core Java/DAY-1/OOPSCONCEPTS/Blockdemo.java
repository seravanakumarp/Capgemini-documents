/*
 * Block: It is a set of instructions without identity.
 * 1. static block
 * 2. instance block
 * 
 * static block: a set of statements defined with static keyword is
 * a static block
 * 			static
 * 			{
 * 				//statements
 * 			}
 *-> JVM executes the static block during class loading time.
 *
 *instance block: a set of statements without a static keyword is 
 *a instance block.
 *
 *			  {
 *				statements
 *		    	}
 *-> JVM executes the instance block during the object creation.
 * 
 * 
 *    block                                method
 *    1. set of instructions      1. set of instructions with identity
 *     without identity
 *    2. block are implicitly     2. Method are to called by the
 *    								programmer explicitly
 *    taken care by JVM
 *    
 *    3. no inputs                3. inputs
 *    4. no outputs               4. outputs
 *    5. initial information      5. perform a task
 *    for object to communicate
 */
package OOPSCONCEPTS;

public class Blockdemo 
{
	static
	{
		System.out.println("static block");
	}
	{
		System.out.println("instance block");
	}
	public static void main(String[] args) 
	{
		Blockdemo bd=new Blockdemo();
		System.out.println("main method");
	}

}
