package OOPSCONCEPTS;

public class Instancevariablesdemo 
{
	int a=10;
	float b=3.142f;
	char c='a';
	static int d=40;
	
	void display()
	{
		System.out.println(a+" "+b+" "+c);
		System.out.println(d);
	}
	public static void main(String[] args)
	{
		Instancevariablesdemo ivd=new Instancevariablesdemo();
		ivd.display();
		System.out.println(d);
		System.out.println(ivd.c);
		
	}

}
