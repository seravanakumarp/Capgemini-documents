package OOPSCONCEPTS;


public class ICICI_BANK extends Bank //child class
{
		String ifsccode;
		String address;
		
		ICICI_BANK(float savingsroi,float fdroi,float creditroi,String ifscode,String address) 
		{
			super(savingsroi,fdroi,creditroi);
			this.ifsccode=ifscode;
			this.address=address;
		}
		void getaddressdetails()
		{
			System.out.println(this.ifsccode+" "+this.address);
			System.out.println(super.savingroi);
			System.out.println(super.fdroi);
			System.out.println(super.creditroi);
		}
	
		public static void main(String args[])
		{
			ICICI_BANK ic=new ICICI_BANK(8.0f,9.0f,15.0f,"ICICI0001119","Ameerpet");
			ic.getaddressdetails();
			
			
		}
}

