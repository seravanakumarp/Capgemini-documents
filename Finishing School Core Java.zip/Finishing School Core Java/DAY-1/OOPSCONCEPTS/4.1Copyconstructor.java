class Student {
    String name;
    int age;

    // Parameterized constructor
    Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    Student(Student other) {
        this.name = other.name;
        this.age = other.age;
    }

    void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

public class Copyconstructor {
    public static void main(String[] args) {
        Student s1 = new Student("Kumar", 25);  // Original object
        Student s2 = new Student(s1);           // Copy object using copy constructor

        s1.display();
        s2.display();
    }
}
