// Base class
class Vehicle {
    void startEngine() {
        System.out.println("Engine started.");
    }
}

// Derived class from Vehicle
class Car extends Vehicle {
    void drive() {
        System.out.println("Car is driving.");
    }
}

// Derived class from Car
class ElectricCar extends Car {
    void chargeBattery() {
        System.out.println("Battery is charging.");
    }
}

// Main class to test the multilevel inheritance
public class VehicleTest {
    public static void main(String[] args) {
        ElectricCar myTesla = new ElectricCar();

        // Calling methods from all levels of inheritance
        myTesla.startEngine();   // From Vehicle class
        myTesla.drive();         // From Car class
        myTesla.chargeBattery(); // From ElectricCar class
    }
}
