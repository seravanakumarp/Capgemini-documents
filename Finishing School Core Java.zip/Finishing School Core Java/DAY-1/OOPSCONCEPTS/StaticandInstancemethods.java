package OOPSCONCEPTS;

public class StaticandInstancemethods
{
	void show(int a,int b)
	{
		System.out.println("product of integer numbers="+(a*b));
	}
	static void show(float a,float b)
	{
		System.out.println("product of floating numbers="+(a*b));
	}
	public static void main(String[] args) 
	{
		StaticandInstancemethods si=new StaticandInstancemethods();
		si.show(10,20);
		StaticandInstancemethods.show(2.0f,3.0f);
		
		
	}

}
