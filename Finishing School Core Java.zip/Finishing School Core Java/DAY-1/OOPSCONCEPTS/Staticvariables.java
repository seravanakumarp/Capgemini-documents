package OOPSCONCEPTS;
class Employee
{
	static String company_name="TCS";
	int empid=123;
	String name="kapil";
	float salary=45000;
	
	void display()
	{
		String address="hyderabad";//local variables
		System.out.println(company_name+" "+empid+" "+name+" "+salary+" "+address);
	}
}
public class Staticvariables 
{
	public static void main(String[] args)
	{
		Employee e=new Employee();
		
		e.display();
		
		Employee e1=new Employee();
		
		e1.empid=124;
		e1.name="karthik";
		e1.salary=55000;
		
		System.out.println(e1.company_name+" "+e1.empid+" "+e1.name+" "+e1.salary);
	}

}
