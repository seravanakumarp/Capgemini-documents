package OOPSCONCEPTS;
class Person2
{
	int id;
	String name;
	
	void setpdetails(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	void getpdetails()
	{
		System.out.println(this.id+" "+this.name);
	}
}
class Employee1 extends Person2
{
	float salary;
	String designation;
	
	void setedetails(float salary,String designation)
	{
		this.salary=salary;
		this.designation=designation;
	}
	void getedetails()
	{
		System.out.println(this.salary+" "+this.designation);
	}
}
class Manager1 extends Employee1
{
	String extraresponsibilities;
	float extraremuneration;
	
	void setmdetails(String extraresponsibilities,float extraremuneration)
	{
		this.extraresponsibilities=extraresponsibilities;
		this.extraremuneration=extraremuneration;
	}
	void getmdetails()
	{
		System.out.println(this.extraresponsibilities+" "+this.extraremuneration);
	}
}

public class ManagerInfo {

	public static void main(String[] args) 
	{
			Manager1 m=new Manager1();
			m.setpdetails(123,"rahul");
			m.setedetails(45000,"analyst");
			m.setmdetails("monitoring",15000);
			
			m.getpdetails();
			m.getedetails();
			m.getmdetails();
			
	}

}
