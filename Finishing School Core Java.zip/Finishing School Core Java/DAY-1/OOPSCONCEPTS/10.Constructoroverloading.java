/* 
 * Constructor overloading:
 *  1. It is a process of having more than one constructor with
 *     different parameterlist.
 *  
 *  Note: 1. number of parameters must be different.
 *  	  2. type of parameters must be different.
 *  	  3. sequence of parameters must be different.
 *  
 *  
 */

package OOPSCONCEPTS;
class Productdetails
{
	int id;
	String name;
	float price;
	
	Productdetails()
	{
		System.out.println(id+" "+name+" "+price);
	}
	Productdetails(int id)
	{
		this.id=id;
	}
	Productdetails(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	Productdetails(Productdetails p)
	{
		this.id=p.id;
		this.name=p.name;
		this.price=p.price;
	}
	Productdetails(int id,String name,float price)
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
	
	void display()
	{
		System.out.println(this.id+" "+this.name+" "+this.price);
	}
}
public class Constructoroverloading {

	public static void main(String[] args) 
	{
		/*Productdetails pd=new Productdetails();
		
		Productdetails pd1=new Productdetails(10);
		pd1.display();
		
		Productdetails pd2=new Productdetails(10,"Marker");
		pd2.display();
		
		Productdetails pd3=new Productdetails(10,"Marker",75);
		pd3.display();
		*/
		
		Productdetails pd=new Productdetails(102,"Scale",20);
		pd.display();
		
		//copy constructor
		
		Productdetails pd4=new Productdetails(pd);
		
		System.out.println(pd4.id+" "+pd4.name+" "+pd4.price);
	}

}
