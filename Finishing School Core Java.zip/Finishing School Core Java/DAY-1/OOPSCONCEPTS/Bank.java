package OOPSCONCEPTS;

public class Bank 
{
	float savingroi;
	float fdroi;
	float creditroi;
	
	Bank(float savingroi,float fdroi,float creditroi)
	{
		this.savingroi=savingroi;
		this.fdroi=fdroi;
		this.creditroi=creditroi;
	}
	void getroidetails()
	{
		System.out.println(this.savingroi+" "+this.fdroi+" "+this.creditroi);
	}
	
}
