//package OOPSCONCEPTS;
class Person1
{
	void work()
	{
		System.out.println("works in an organization");
	}
}
class Manager extends Person1
{
	void workforteam()
	{
		System.out.println("works himself and monitors the team");
	}
}
public class SingleInheritance 
{

	public static void main(String[] args) 
	{
		Manager m=new Manager();
		m.work();
		m.workforteam();
	}

}
