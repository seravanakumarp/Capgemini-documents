/* Access Rules of static and instance members
 * 
 * 1. Instance instance combination: An instance method can access
 * instance members directly provided they already belong to the same
 * class  otherwise they can accessed by using reference.
 * 
 * 2. Instance static combination: An instance method can access static
 * members directly if they belong to the same class otherwise they
 * can accessed by means of class name or reference(object).
 * 
 * 3. Static static combination: A static method can access static 
 * members directly if belongs to the same class otherwise they
 * are accessed by means of class name or reference(object).
 * 
 * 4. static instance combination: A static method can access instance
 * members only by means of reference(object) whether they are
 * within the class or outside the class.
 * 
 * 
 */

package OOPSCONCEPTS;
public class Staticdemo2 
{
	int x=10;
	static int y=20;
	
	void display()
	{
		System.out.println(x);
		System.out.println(y);
	}
	static void show()
	{
		
		System.out.println(y);
	}
	public static void main(String[] args) 
	{
		Staticdemo2 st=new Staticdemo2();
		st.display();
		st.show();
		
		System.out.println(st.x);
		
		
	}

}
