package OOPSCONCEPTS;

public class Manager_person {

	public static void main(String[] args) 
	{
		Person p=new Person();
		
		p.setPid(1324);
		p.setPname("karthik");
		p.setPsalary(55000);
		
		System.out.println(p.getPid()+" "+p.getPname()+" "+p.getPsalary());
	}

}
