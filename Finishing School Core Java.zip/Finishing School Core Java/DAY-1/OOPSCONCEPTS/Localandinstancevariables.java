package OOPSCONCEPTS;
class Student1
{
	int rollno;
	String name;
	float marks;
	
	void display(int rollno,String name,float marks) //called method
	{
		this.rollno=rollno; //local variable assigned to instance variable
		this.name=name;
		this.marks=marks;
		
		System.out.println(rollno+" "+name+" "+marks);
	}
}
public class Localandinstancevariables {

	public static void main(String[] args) 
	{
			Student1 s=new Student1();
			s.display(101,"arun",335); //calling method
			
			Student1 s1=new Student1();
			s1.display(102,"rohit",455);
			
	}

}
