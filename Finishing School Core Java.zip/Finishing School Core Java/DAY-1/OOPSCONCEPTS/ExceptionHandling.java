/*
 * Errors:
 * 1. Compile time Errors
 * 2. Logical Errors
 * 3. Runtime Errors
 * 
 * What Happen?
 * 1. Abnormal Termination of program
 * 2. Informal intimation to enduser
   3. Improper shutdown of resources.
   
   Possible Exceptions we come across during the execution of a
   program are:
   1. Arithmetic Exception.
   2. ArrayIndexOutOfBounds Exception
   3. NullPointer Exception
   4. NumberFormat Exception
   5. ClassCast Exception
   6. FileNotFound Exception
   7. SQLException
   8. UnknownHostException
  
  Java API provides five keywords for handling the exceptions in our program
  1.try
  2.catch
  3.throw
  4.throws
  5.finally
  
  try:
  1. It is a keyword in java.
  2. It is a block which contains a set of instructions.
  3. Any doubtful code which is suspected for possibly of 
  exception where incorporated in try block.
  4. if the exception is raised, an exception object gets
  generated and it is handed over to the catch block instead of
  JVM.
  
  catch:
  1. It is also a keyword in java.
  2. It contains exception handling code.
  
  Syntax:
  try
  {
  		doubtfulcode;
  }
  catch(Exception_type identifier)
  {
        exception handling code;
  }
   
 */

package OOPSCONCEPTS;
class Sample100
{
	void display()
	{
		
	}
}
class Parent100
{
	void display()
	{
		System.out.println("display method of Parent class");
	}
}
class Child100 extends Parent100
{
	void show()
	{
		System.out.println("show method of child class");
	}
}
public class ExceptionHandling {

	public static void main(String[] args) 
	{
		//static int a; compile time error
		
		/*int a=10,b=20;
		
		float c=a/b;  //logical errors
		
		System.out.println(c);
		*/
		 //ArrayIndexOutOfBounds Exception
		/*int a[]= {10,20,30,40,50};
		a[7]=100; //Run time errors
		System.out.println(a[7]);
		*/
		//Arithmetic Exception
		//int a=10,b=0;
		
		//System.out.println(a/b);
		
		//Nullpointer Exception
		
		/*String s=null;
		
		System.out.println(s.length());
		
		Sample100 s1=null;
		
		s1.display();
		*/
		//NumberFormat Exception
		//String s2="sachin";
		//int i=Integer.parseInt(s2);
		
		//System.out.println(i);
		//Classcast Exception
		
		Child100 c=(Child100)new Parent100();
		
	}

}
