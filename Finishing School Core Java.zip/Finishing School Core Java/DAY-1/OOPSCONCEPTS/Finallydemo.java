package OOPSCONCEPTS;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Finallydemo {

	public static void main(String[] args)
	{
		FileInputStream fis=null;
		try
		{
			fis=new FileInputStream("D:/j4.pdf");
			System.out.println("file opened successfully");
		}
		catch(FileNotFoundException fe)
		{
			System.out.println("file does not exist");
		}
		finally
		{
			try
			{
				fis.close();
				System.out.println("Connection is closed");
			}
			catch(IOException i)
			{
				System.out.println("io error");
			}
			catch(NullPointerException ne)
			{
				System.out.println("file is not able to get closed");
			}
			
		}
	}

}
