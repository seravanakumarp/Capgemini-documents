package OOPSCONCEPTS;
import java.util.*;
public class Demo1000 {

	public static void main(String[] args) 
	{
		Student1000 s=new Student1000();
		
		s.setRollno(123);
		s.setName("sachin");
		s.setMarks(456.0f);
		
		System.out.println(s.getRollno()+" "+s.getName()+" "+s.getMarks());
	}

}
