package OOPSCONCEPTS;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Exception2 {

	public static void main(String[] args) 
	{
			FileInputStream fis=null;
			try
			{
				fis=new FileInputStream("D:/380.pdf");
				System.out.println("file opened successfully");
			}
			catch(FileNotFoundException fe)
			{
				System.out.println("file does not exist");
			}
	}

}
