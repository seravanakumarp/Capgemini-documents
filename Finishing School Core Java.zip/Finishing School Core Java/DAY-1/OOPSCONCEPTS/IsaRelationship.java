//Method overloading with IS-A Relationship
package OOPSCONCEPTS;
class Sample1
{
	int a;
	int b;
	static float c;
	static float d;
	
	void display(int a,int b)
	{
		System.out.println("subtraction of two integer numbers="+(a-b));
	}
	void display(float c,float d)
	{
		System.out.println("Product of two float numbers="+(c*d));
	}
}
class Sample2 extends Sample1
{
	long a;
	long b;
	static short c;
	static short d;
	
	void display(long a,long b)
	{
		System.out.println("Addition of two long numbers="+(a+b));
	}
	static void display(short c,short d)
	{
		System.out.println("Subtraction of two short numbers="+(c-d));
	}
}
public class IsaRelationship {

	public static void main(String[] args) 
	{
	     
	     Sample2 s=new Sample2();
	     s.display(10,20);
	     s.display(2.3f, 3.4f);
	     s.display(123L, 345L);
	     s.display(1000, 2000);
	     
	}

}
