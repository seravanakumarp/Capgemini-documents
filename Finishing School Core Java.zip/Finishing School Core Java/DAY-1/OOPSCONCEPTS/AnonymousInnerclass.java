package OOPSCONCEPTS;
class Demo23
{
	public void display()
	{
		System.out.println("display method of Demo class");
	}
}
public class AnonymousInnerclass {

	public static void main(String[] args) 
	{
			Demo23 d=new Demo23();
			d.display();
			
			Demo23 d1=new Demo23()
					{
						public void display()
						{
							System.out.println("display method of anonymous class");
						}
					};
			d1.display();
	}

}
