package OOPSCONCEPTS;
class Shape
{
	public float area()
	{
		return 0.0f;
	}
}
class Square extends Shape
{
	float side;
	
	Square(float side)
	{
		this.side=side;
	}
	public float area()
	{
		return side*side;
	}
}
class Rectangle extends Shape
{
	float length;
	float breadth;
	
	Rectangle(float length,float breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	
	public float area()
	{
		return length*breadth;
	}
}
class Triangle extends Shape
{
	float base;
	float height;
	
	Triangle(float base,float height)
	{
		this.base=base;
		this.height=height;
	}
	public float area()
	{
		return 0.5f*base*height;
	}
}
public class Geometricalshapes {

	public static void main(String[] args) 
	{
		Square s=new Square(2.3f);
		float sarea=s.area();
		System.out.println("area of square="+sarea);
		
		Rectangle r=new Rectangle(2.3f,3.4f);
		float rarea=r.area();
		System.out.println("area of rectangle="+rarea);
		
		Triangle t=new Triangle(4.5f,5.5f);
		float tarea=t.area();
		System.out.println("area of triangle="+tarea);
		
	}

}
