package OOPSCONCEPTS;

public class Staticvariabledemo 
{
	int x;
	static int y;
	public static void main(String[] args)
	{
		Staticvariabledemo svd0=new Staticvariabledemo();
		System.out.println(svd0.x+" "+svd0.y);
		
		Staticvariabledemo svd=new Staticvariabledemo();
		
		svd.x++;
		svd.y++;
		System.out.println(svd.x+" "+svd.y);
		Staticvariabledemo svd1=new Staticvariabledemo();
		svd1.x++;
		svd1.y++;
		System.out.println(svd1.x+" "+svd1.y);
		Staticvariabledemo svd2=new Staticvariabledemo();
		svd2.x++;
		svd2.y++;
		System.out.println(svd2.x+" "+svd2.y);
		
		
	}

}
