package OOPSCONCEPTS;
//POJO class
public class Person 
{
	private int pid;
	private String pname;
	private float psalary;
	public int getPid() 
	{
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public float getPsalary() {
		return psalary;
	}
	public void setPsalary(float psalary) {
		this.psalary = psalary;
	}
	
	
	
}
