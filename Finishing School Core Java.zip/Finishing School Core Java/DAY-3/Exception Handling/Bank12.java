package OOPSCONCEPTS;
class InsufficientFundsException extends Exception
{
	int needs;
	InsufficientFundsException(int needs)
	{
		this.needs=needs;
	}
	public int message()
	{
		return this.needs;
	}
}
class Account1 
{
	int balance;
	Account1(int balance)
	{
		this.balance=balance;
	}
	public int getbalance()
	{
		return this.balance;
	}
	public void withdraw(int amount) throws InsufficientFundsException
	{
		if(amount<this.balance)
		{
			this.balance=this.balance-amount;
		}
		else
		{
			int needs=amount-this.balance;
			InsufficientFundsException i=new InsufficientFundsException(needs);
			throw i;
		}
	}
}
public class Bank12 {

	public static void main(String[] args)
	{
		Account1 a=new Account1(30000);
		try
		{
			a.withdraw(20000);
			System.out.println(a.getbalance()); //10000
			a.withdraw(20000);
				
		}
		catch(InsufficientFundsException ife)
		{
			System.out.println("insufficent funds:Unable to withdraw");
			
			System.out.println("needs:"+ife.message()); //10000
		}
	}

}
