package OOPSCONCEPTS;

public class Trywithmultiplecatches {

	public static void main(String[] args) 
	{
		try
		{
			String s=args[0];
			
			int i=Integer.parseInt(s);
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			//System.out.println("no input task failed");
			//System.out.println(aie.getMessage());
			aie.printStackTrace();
		}
		catch(NumberFormatException ne)
		{
			//System.out.println("invalid input task failed");
			//System.out.println(ne.getMessage());
			ne.printStackTrace();
		}
	}

}
