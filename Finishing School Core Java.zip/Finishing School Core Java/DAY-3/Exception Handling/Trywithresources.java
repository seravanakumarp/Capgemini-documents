package OOPSCONCEPTS;

import java.io.FileInputStream;


public class Trywithresources 
{

	public static void main(String[] args) throws Exception
	{
		try(FileInputStream fis=new FileInputStream("D:/SATYA/BATCH_P_11AM/Circle.java"))
		{
			int ch;
			
			while((ch=fis.read())!=-1)
			{
				System.out.print((char)ch);
			}
		}
	}

}
