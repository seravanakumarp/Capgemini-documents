/*
 *  MultiThreading:

 *  
 *  1. java.lang package contains the Thread class as well as
 *  Runnable interface.
 *  
 *  Two ways of creation of thread:
 *  1. By extending the Thread class.
 *  2. By implementing the Runnable interface.
 *  
 *  Every thread class, must override the public void run() method
 *  which is empty method definition.
 *  
 *  When do we need to go for an Thread class?
 *  
 *  Whenever we want to apply the thread behavior to both parent and child
 *  class which are in a IS-A Relationship. 
 *  
 *  When do we need to go for an Runnable Interface?
 *  
 *  Whenever we want to apply the thread behavior to only child class
 *  which is in IS-A relationship.
 *  
 *  Life Cycle of a Thread:
 *  
 *  1. Creation: Thread is created either by extending the Thread class
 *  or by implementing Runnable interface.
 *  2. Instantiation: Thread object is created for to communicate
 *  with other objects.
 *  3. Start: Thread is started in this state upon creation of thread object.
 *  4. Runnable state: Threads are moved to the Queue and they wait until
 *  the CPU scheduler allocate the address space for the execution 
 *  by the processor.
 *  
 *  5. Running state: Where thread starts executing the logic written 
 *  inside the thread.
 *  6. Waiting state: It is another queue where the thread enters from
 *  running state to waiting state due to certain reasons.
 *  
 *  7. End state: Where all the threads of a process finishes its task
 *  by entering into end state or by abnormal termination.
 *  
 *  
 *  
 *  
 */

package Multithreading;

public class ThreadBasics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
