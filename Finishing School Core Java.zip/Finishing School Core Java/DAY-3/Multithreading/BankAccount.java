package Multithreading;

public class BankAccount
{
	private int balance=1000;
	
	public synchronized void withdraw(int amount)
	{
		System.out.println(Thread.currentThread().getName()+amount);
		if(balance>=amount)
		{
			System.out.println(Thread.currentThread().getName());
			try
			{
				Thread.sleep(10000);
			}
			catch(Exception e)
			{
				
			}
			balance=balance-amount;
			System.out.println("remaining balance="+balance);
		}
		else
		{
			System.out.println(Thread.currentThread().getName()+"insufficient funds");
		}
		
	}
}
