//package Multithreading;
class Test extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println(Thread.currentThread().getName());
			Thread.yield();
		}
	}
}
public class Yielddemo {

	public static void main(String[] args)
	{
		Test t1=new Test();
		t1.start();
		
		Test t2=new Test();
		t2.start();
	}

}
