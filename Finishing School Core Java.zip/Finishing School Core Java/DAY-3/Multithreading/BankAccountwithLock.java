package Multithreading;

import java.util.concurrent.TimeUnit;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BankAccountwithLock 
{
	private int balance=1000;
	
	private Lock lock=new ReentrantLock();
	
	public void withdraw(int amount)
	{
		System.out.println(Thread.currentThread().getName()+amount);
		try
		{
		if(lock.tryLock(1000,TimeUnit.MILLISECONDS))
		{
			if(balance>=amount)
			{
				System.out.println(Thread.currentThread().getName());
				try
				{
					Thread.sleep(3000);
					balance=balance-amount;
					System.out.println("remaining balance="+balance);
				}
				catch(Exception e)
				{
					
				}
				finally
				{
					lock.unlock();
					
				}
				
			}
			else
			{

				System.out.println(Thread.currentThread().getName()+"insufficient funds");
			}
		}
		else
		{
			System.out.println("could not acquire the lock");
		}
		}
		catch(Exception e)
		{
			
		}
			
	}

}
