package Multithreading;


public class Anonymousclasswiththreads 
{

	public static void main(String[] args)
	{
		Runnable t1=new Runnable()
				{
						public void run()
						{
							for(int i=1;i<=5;i++)
							{
								try
								{
									Thread.sleep(1000);
								}
								catch(Exception e)
								{
									
								}
								System.out.println("Happy coding");
							}
								
						}
				};
		Runnable t2=new Runnable()
				{
					public void run()
					{
						for(int i=1;i<=5;i++)
						{
							try
							{
								Thread.sleep(1000);
							}
							catch(Exception e)
							{
								
							}
							System.out.println("Happy coding with java");
						}
							
					}
				};
		
		Thread t11=new Thread(t1);
		Thread t22=new Thread(t2);
		
		t11.start();
		try
		{
			Thread.sleep(100);
		}
		catch(Exception e)
		{
			
		}
		t22.start();
		
	}

}
