package Multithreading;

public class Mainwithlock {

	public static void main(String[] args) 
	{
		BankAccountwithLock icici=new BankAccountwithLock();
		Runnable r1=new Runnable()
				{
					public void run()
					{
						icici.withdraw(200);
					}
				};
		Thread t1=new Thread(r1);
		Thread t2=new Thread(r1);
		
		t1.start();
		t2.start();

	}

}
