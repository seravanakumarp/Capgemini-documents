/*
 * Types of Threads:
 * 1. Non-Daemon threads
 * 2. Daemon threads
 * 
 * Non-Daemon threads:
 * -> they are the threads created by the user for his multithread functionality.
 * -> All the user threads as well as main thread are treated as
 * Non-Daemon threads
 * -> These threads run as front end part of an application.
 * 
 * Daemon threads:
 * -> Daemon threads provide the services to the user defined threads.
 * -> They run at the background.
 * -> The lifetime of this Daemon threads purely depends on the mercy
 * of Non-Daemon threads.
 * -> If all the non-daemon threads comes to dead state the JVM automatically
 * terminates the Daemon threads.
 * -> There are many daemon threads comes in java such as gc, Finalizer.
 * 
 * Methods of Daemon thread:
 * 1. public void setDaemon(boolean status)
 * -> it is used to convert a non-daemon thread into an daemon thread
 * by making the argument as true inside the setDaemon.
 * 2. public boolean isDaemon()
 * -> It is used to check whether the thread is Deamon or not.
 * 
 * NOTE: A non-daemon thread can be converted into Daemon thread either
 * during defining the constructor or before the start method.
 * Once the thread is started, if we try to convert, it may cause
 * an exception called IllegalThreadStateException.

 */
package Multithreading;

public class Typesofthreadsdemo extends Thread
{
	public void run()
	{
		if(Thread.currentThread().isDaemon())
		{
			System.out.println("Daemon thread working");
		}
		else
		{
			System.out.println("Non Daemon thread working");
		}
	}
	
	public static void main(String[] args) 
	{
		Typesofthreadsdemo t1=new Typesofthreadsdemo();
		Typesofthreadsdemo t2=new Typesofthreadsdemo();
		Typesofthreadsdemo t3=new Typesofthreadsdemo();
		
		t1.setDaemon(true); //convert into Daemon thread
		
		t1.start();
		t2.start();
		t3.start();

	}

}
