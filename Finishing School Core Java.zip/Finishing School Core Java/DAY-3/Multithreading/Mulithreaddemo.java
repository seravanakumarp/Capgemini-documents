package OOPSCONCEPTS;
class A1 extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
		{
		System.out.println("good morning");
			try
			{
			Thread.sleep(1000);
			}
			catch(Exception e)
			{
				
			}
		}
	}
}
class B1 extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
		{
		System.out.println("good night");
		try
		{
		Thread.sleep(1000);
		}
		catch(Exception e)
		{
			
		}
		}
	}
}
public class Mulithreaddemo {

	public static void main(String[] args) 
	{
		A1 a=new A1();
		B1 b=new B1();
		
		a.start();
		try{Thread.sleep(500);}catch(Exception e) {}
		b.start();
		
		//a.show();
		//b.show();
	}

}
