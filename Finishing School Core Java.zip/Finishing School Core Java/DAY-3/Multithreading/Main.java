package Multithreading;

public class Main {

	public static void main(String[] args)
	{
		BankAccount icici=new BankAccount();
		Runnable r1=new Runnable()
				{
					public void run()
					{
						icici.withdraw(200);
					}
				};
		Thread t1=new Thread(r1);
		Thread t2=new Thread(r1);
		
		t1.start();
		t2.start();
		
				
	}

}
