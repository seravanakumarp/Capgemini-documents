package OOPSCONCEPTS;
class A11 implements Runnable
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("good morning");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				
			}
		}
	}
}
class B11 implements Runnable
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("good night");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				
			}
		}
	}

}
public class MultithreadingwithRunnable
{

	public static void main(String[] args) throws Exception//main thread
	{
		Runnable a=new A11();
		Runnable b=new B11();
		
		Thread t1=new Thread(a);
		Thread t2=new Thread(b);
		
		t1.setName("First Thread");
		t2.setName("Second Thread");
		
		System.out.println(t1.getName());
		System.out.println(t2.getName());
		
		t1.setPriority(2);
		t2.setPriority(10);
		
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);
		System.out.println(Thread.MAX_PRIORITY);
		
		System.out.println(t1.isAlive());
		t1.start();
		try
		{
			Thread.sleep(500);
		}
		catch(Exception e)
		{
			
		}
		System.out.println(t1.isAlive());
		
		t2.start();
		
		t1.join();
		t2.join();
		System.out.println(t1.isAlive()); //false
		
		System.out.println("good bye");// belongs to main thread
	}

}
