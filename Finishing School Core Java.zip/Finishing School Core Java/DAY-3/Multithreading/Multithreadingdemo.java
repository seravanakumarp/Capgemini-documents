//package Multithreading;
class Process1 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			try
			{
			Thread.sleep(2000);
			}
			catch(Exception e)
			{
				
			}
			System.out.println("Good Morning");
		}

	}
	
}
class Process2 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				
			}
			System.out.println("Good Evening");
		}
		
	}
	
}
public class Multithreadingdemo 
{

	public static void main(String[] args) throws Exception
	{
		Process1 p1=new Process1();
		Process2 p2=new Process2();
		
		p1.start();
	
		try
		{
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			
		}
		p2.start();
	}

}
