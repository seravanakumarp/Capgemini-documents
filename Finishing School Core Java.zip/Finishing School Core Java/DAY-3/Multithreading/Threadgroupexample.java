package Multithreading;

public class Threadgroupexample implements Runnable
{
	public void run()
	{
		System.out.println(Thread.currentThread().getName());
	}
	public static void main(String[] args) 
	{
			Threadgroupexample tge=new Threadgroupexample();
			
			ThreadGroup tg1=new ThreadGroup("Parent ThreadGroup");
			
			Thread t1=new Thread(tg1,tge,"one");
			t1.start();
			
			Thread t2=new Thread(tg1,tge,"two");
			t2.start();
			
			Thread t3=new Thread(tg1,tge,"three");
			t3.start();
			
			System.out.println("Thread group name:"+tg1.getName());
			
			tg1.list();
			
	}

}
