package IOstreams;
import java.io.*;
import java.util.StringTokenizer;
public class Numberofwords {

	public static void main(String[] args) throws IOException
	{
		FileReader fr=null;
		BufferedReader br=null;
		
		try
		{
			fr=new FileReader("D:sample.txt");
			br=new BufferedReader(fr);
			String str;
			int count=0;
			while((str=br.readLine())!=null)
			{
				StringTokenizer st=new StringTokenizer(str);
				while(st.hasMoreTokens())
				{
					System.out.println(st.nextToken());
					count++;
				}
			}
			System.out.println("number of words="+count);
		}
		catch(FileNotFoundException fne)
		{
			System.out.println(fne.getMessage());
		}
		finally
		{
			if(fr!=null)
				fr.close();
			if(br!=null)
				br.close();
		}
	}

}
