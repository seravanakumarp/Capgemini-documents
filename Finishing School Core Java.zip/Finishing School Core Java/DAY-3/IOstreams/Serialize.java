package IOstreams;
import java.io.*;
class Car implements Serializable 
{ 
	private Vehicle model_no; 
	private int bhp; 
	public Car(Vehicle model, int bhp ) 
	{ 
		model_no=model; 
		this.bhp=bhp; 
	}
} 
class Vehicle implements Serializable
{ 
	private int model_no; 
	public Vehicle(int model_no) 
	{ 
		this.model_no=model_no; 	
	} 
}
public class Serialize {

	public static void main(String[] args)
	{
		Vehicle v = new Vehicle(1134); 
		Car c= new Car( v, 256); 
		try 
		{ 
		FileOutputStream fs = new FileOutputStream( "D:Serialize.ser" ); 
		ObjectOutputStream os = new ObjectOutputStream( fs ); 
		os.writeObject( c ); 
		os.close(); 
		} 
		catch( FileNotFoundException fnf ) 
		{ 
		fnf.printStackTrace(); 
		} 
		catch( IOException i ) 
		{ 
		i.printStackTrace(); 
		}
	}

}
