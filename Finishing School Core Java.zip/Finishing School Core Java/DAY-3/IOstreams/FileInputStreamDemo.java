package IOstreams;
import java.io.*;
public class FileInputStreamDemo {

	public static void main(String[] args)throws IOException
	{
		FileInputStream fis=null;
		FileOutputStream fos=null;
		try
		{
			fis=new FileInputStream("D:/sample.txt");
			fos=new FileOutputStream("D:/sample200.txt",false);
			int ch;
			while((ch=fis.read())!=-1)
			{
				fos.write((char)ch);
			}
			System.out.println("file opened");
		}
		catch(FileNotFoundException fie)
		{
			fie.printStackTrace();
		}
		finally
		{
			if(fis!=null)
			{
				fis.close();
			}
			/*if(fos!=null)
			{
				fos.close();
			}*/
		}
	}

}
