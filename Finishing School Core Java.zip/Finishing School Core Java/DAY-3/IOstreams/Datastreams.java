package IOstreams;
import java.io.*;
public class Datastreams {

	public static void main(String[] args) throws IOException
	{
		String name="sachin";
		int roll=124;
		try
		{
			FileOutputStream fos=new FileOutputStream("D:/sample.txt");
			DataOutputStream dos=new DataOutputStream(fos);
			dos.writeInt(roll);
			dos.writeUTF(name);
			
			dos.close();
			FileInputStream fis=new FileInputStream("D:/sample.txt");
			DataInputStream dis=new DataInputStream(fis);
			
			int rollno=dis.readInt();
			String nm=dis.readUTF();
			
			System.out.println(rollno+" "+nm);
			dis.close();
		}
		catch(FileNotFoundException fne)
		{
			System.out.println(fne.getMessage());
		}
			}

}
