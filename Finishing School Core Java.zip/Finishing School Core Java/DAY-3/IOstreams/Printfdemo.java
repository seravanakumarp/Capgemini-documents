package IOstreams;
import java.io.*;
public class Printfdemo {

	public static void main(String[] args)
	{
		/* format specifiers
		%d - integer values
		%c - character values
		%s - string
		%f - float values
		%n - new line
		
		*/
		
		int a=10;
		System.out.printf("%d%n",a);
		
		float f=3.14243f;
		System.out.printf("%f%n",f);
		
		System.out.printf("%.2f%n",f);
		
		System.out.printf("%5.2f%n",f);
		
		System.out.printf("%-5.2f%n",f);
		
		char ch='c';
		System.out.printf("%c%n",ch);
		
		String s="hello";
		System.out.printf("%s%n",s);
		
		String s1="java";
		System.out.printf("%10s%n",s1);
		
		String s2="java";
		System.out.printf("%-10s%n",s2);
		
	}

}
