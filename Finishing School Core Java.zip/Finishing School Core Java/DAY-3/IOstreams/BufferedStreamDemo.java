package IOstreams;
import java.io.*;
public class BufferedStreamDemo {

	public static void main(String[] args) throws IOException
	{
		FileReader fr=null;
		FileWriter fw=null;
		BufferedWriter bw=null;
		try
		{
			fr=new FileReader("D:/sample.txt");
			fw=new FileWriter("D:/sample100.txt");
			bw=new BufferedWriter(fw);
			
			int ch;
			while((ch=fr.read())!=-1)
				bw.write((char)ch);
			
			
		}
		catch(FileNotFoundException fne)
		{
			System.out.println(fne.getMessage());
		}
		finally
		{
			if(bw!=null)
				bw.close();
			if(fr!=null)
				fr.close();
			if(fw!=null)
				fw.close();
			
			
		}
	}

}
